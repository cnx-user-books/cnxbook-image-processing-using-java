//34567890123456789012345678901234567890123456789012345678
/*Java346a
 * The purpose of this program is to illustrate the use
 * of property setter and getter methods of the
 * SimpleTurtle class.
 *
 * Draws two turtles in a World and sets property values
 * on each of them.
 */
import java.awt.Color;
public class Main{
  public static void main(String[] args){
    World mars = new World(300,500);
    Turtle joe = new Turtle(mars);
    joe.setShellColor(Color.RED);
    joe.setPenColor(Color.BLUE);
    joe.setPenWidth(2);
    joe.forward(90);
    joe.turn(-30);
    joe.forward();
    
    Turtle bill = new Turtle(mars);
    bill.moveTo(bill.getXPos()-100,bill.getYPos()+100);
    bill.setName("Bill");
    bill.setShowInfo(true);
    bill.setInfoColor(Color.RED);
    bill.setWidth(bill.getWidth() * 2);
    bill.setHeight(bill.getHeight() * 2);
  }//end main

}//end class
//34567890123456789012345678901234567890123456789012345678