//34567890123456789012345678901234567890123456789012345678
/*File Java2700b Copyright 2009 R.G.Baldwin
 *Revised 07/26/09

Illustrates modification of the World class to cause it to
accept a String constructor parameter and to use the
String as the name of an image file. The image file is
used to replace the default white background in the World
object with the image extracted from the image file.
*********************************************************/

public class Java2700b{
  public static void main(String[] args){
    //Note: The modified World class has been successfully
    // tested with all of the following instantiation
    // statements.
    //World mars = new World();
    //World mars = new World(true);
    //World mars = new World(200,250);
    World mars = new World("java2700bImg.jpg");

    //Add a turtle to the world and make it move.
    Turtle fred = new Turtle(mars);
    fred.forward();
  }//end main method
}//end class Java2700b

//34567890123456789012345678901234567890123456789012345678
