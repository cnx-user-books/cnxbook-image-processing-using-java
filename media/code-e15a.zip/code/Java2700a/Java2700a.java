//34567890123456789012345678901234567890123456789012345678
/*File Java2700a Copyright 2009 R.G.Baldwin
 *Revised 07/26/09

Illustrates the normal result of placing a turtle in a
World object and causing it to move forward. Note the
white background.
*********************************************************/

public class Java2700a{
  public static void main(String[] args){
    World mars = new World(200,250);
    Turtle fred = new Turtle(mars);
    fred.forward();
  }//end main method
}//end class Java2700a



//34567890123456789012345678901234567890123456789012345678
