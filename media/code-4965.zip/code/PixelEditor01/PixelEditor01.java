//34567890123456789012345678901234567890123456789012345678
/*File PixelEditor01 Copyright 2009 R.G.Baldwin

This program capitalizes on the availability of the
PictureExplorer class released under a Creative Commons
Attribution 3.0 United States License by Barb Ericson
at Georgia Institute of Technology. The program makes it
possible to edit the color of individual pixels in an
image.

More specificallyl, Ericson's PictureExplorer class was
modified to make certain internals of PictureExplorer
objects accessible to objects instantiated from other
classes. Then a Java GUI was written that makes it
possible to open an image file in a PictureExplorer
object and edit the colors of the individual pixels
in the image using the GUI.

Specify an input image file using only the file name and
extension if the file is in the current directory.
Specify the full path to the file if it is not in the
current directory.

Both jpg and bmp file types are supported as input files.
The output file is a bmp file with the letters BAK
inserted in the file name. It is written in the same
directory as the input file. The input file is not
modified.

The program starts with a GUI in the upper-left corner of
the screen. When the user enters the name of the input
image file, the image is opened in a PictureExplorer
object in the upper-left corner of the screen and the GUI
is moved to a location immediately below the
PictureExplorer object.

From that point on, the user can edit pixels in the image
using the buttons and text fields in the GUI. A Write
button is provided to allow the user to save intermediate
versions of the edited image. Note, however, that each
time the Write button is clicked, the previously written
output file is overwritten. The user should manually save
the intermediate versions if they will be needed later.

The final edited version of the image is automatically
written to the disk when the user clicks the Quit button
or clicks the X in the upper-right corner of the GUI.

Tested using Windows Vista Premium Home Edition,
Java v1.6, and the version of Ericson's multimedia library
contained in bookClasses10-1-07.zip.
*********************************************************/

import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowListener;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JColorChooser;
import javax.swing.WindowConstants;
import javax.swing.event.DocumentListener;
import javax.swing.event.DocumentEvent;
import javax.swing.border.LineBorder;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.io.File;

public class PixelEditor01 extends JFrame{

  public static void main(String[] args){
    new PixelEditor01();
  }//end main method
//------------------------------------------------------//

  //Declare a large number of working variables.
  // Initialize some of them.
  PixelEditor01 thisObj = null;
  JFrame explorerFrame = null;
  PictureExplorer explorer = null;
  Picture pix;

  JPanel controlPanel = new JPanel();
  JPanel topPanel = new JPanel();
  JPanel bottomPanel = new JPanel();

  JPanel oldColorPanel = new JPanel();
  JPanel newColorPanel = new JPanel();
  JPanel buttonPanel = new JPanel();

  JPanel swatchPanel = new JPanel();
  JPanel choosePanel = new JPanel();
  JPanel fileNamePanel = new JPanel();

  JPanel oldColorIndicatorPanel = new JPanel();
  JPanel newColorIndicatorPanel = new JPanel();


  JTextField oldRedField = new JTextField("000000");
  JTextField oldGreenField = new JTextField("000000");
  JTextField oldBlueField = new JTextField("000000");

  JTextField newRedField = new JTextField("000");
  JTextField newGreenField = new JTextField("000");
  JTextField newBlueField = new JTextField("000");

  //Pre-load the input file name field with the name of
  // a specific test file.
  JTextField inputFileNameField = new JTextField(
                                  "PixelEditor01.jpg",20);


  JButton getColorButton = new JButton("Get Color");
  JButton copyColorButton = new JButton("Copy Color");
  JButton updateColorButton = new JButton("Update Color");
  JButton writeButton = new JButton("Write File");
  JButton quitButton = new JButton("Quit");

  JButton redButton = new JButton("Red");
  JButton greenButton = new JButton("Green");
  JButton blueButton = new JButton("Blue");
  JButton whiteButton = new JButton("White");
  JButton blackButton = new JButton("Black");
  JButton chooseButton = new JButton("Choose Color");
  JButton darkerButton = new JButton("Darker Color");
  JButton brighterButton = new JButton("Brighter Color");


  //Integer representations of old and new colors
  int oldRedInt = 0;
  int oldGreenInt = 0;
  int oldBlueInt = 0;

  int newRedInt = 0;
  int newGreenInt = 0;
  int newBlueInt = 0;

  //Copies of properties of the PictureExplorer object
  int xIndex = 0;
  int yIndex = 0;
  double zoomFactor = 0;

  String fileName = "no file specified";
  String outputPath = null;
  //----------------------------------------------------//

  public PixelEditor01(){//constructor
    //Construct the GUI.
    controlPanel.setLayout(new BorderLayout());
    controlPanel.add(topPanel,BorderLayout.NORTH);
    controlPanel.add(bottomPanel,BorderLayout.SOUTH);

    topPanel.setLayout(new BorderLayout());
    topPanel.add(oldColorPanel,BorderLayout.NORTH);
    topPanel.add(newColorPanel,BorderLayout.CENTER);
    topPanel.add(buttonPanel,BorderLayout.SOUTH);

    bottomPanel.setLayout(new BorderLayout());
    bottomPanel.add(swatchPanel,BorderLayout.NORTH);
    bottomPanel.add(choosePanel,BorderLayout.CENTER);
    bottomPanel.add(fileNamePanel,BorderLayout.SOUTH);

    oldColorPanel.setBackground(Color.RED);
    oldColorPanel.add(new JLabel("Old Pixel Color"));
    oldColorPanel.add(oldRedField);
    oldColorPanel.add(oldGreenField);
    oldColorPanel.add(oldBlueField);
    oldColorPanel.add(oldColorIndicatorPanel);

    newColorPanel.setBackground(Color.GREEN);
    newColorPanel.add(new JLabel("New Pixel Color"));
    newColorPanel.add(newRedField);
    newColorPanel.add(newGreenField);
    newColorPanel.add(newBlueField);
    newColorPanel.add(newColorIndicatorPanel);

    buttonPanel.setBackground(Color.BLUE);
    buttonPanel.add(getColorButton);
    buttonPanel.add(copyColorButton);
    buttonPanel.add(updateColorButton);
    buttonPanel.add(writeButton);
    buttonPanel.add(quitButton);


    swatchPanel.setBackground(Color.YELLOW);
    swatchPanel.add(redButton);
    swatchPanel.add(greenButton);
    swatchPanel.add(blueButton);
    swatchPanel.add(whiteButton);
    swatchPanel.add(blackButton);


    choosePanel.setBackground(Color.CYAN);
    choosePanel.add(chooseButton);
    choosePanel.add(darkerButton);
    choosePanel.add(brighterButton);


    fileNamePanel.add(new JLabel(
                               "Enter file name here: "));
    fileNamePanel.add(inputFileNameField);


    oldColorIndicatorPanel.setBorder(new LineBorder(
                                          Color.black,1));
    oldColorIndicatorPanel.setPreferredSize(
                                    new Dimension(20,20));


    newColorIndicatorPanel.setBorder(new LineBorder(
                                          Color.black,1));
    newColorIndicatorPanel.setPreferredSize(
                                    new Dimension(20,20));
    paintNewColorIndicator();


    redButton.setBackground(Color.RED);
    greenButton.setBackground(Color.GREEN);
    blueButton.setForeground(Color.YELLOW);
    blueButton.setBackground(Color.BLUE);
    whiteButton.setBackground(Color.WHITE);
    blackButton.setForeground(Color.WHITE);
    blackButton.setBackground(Color.BLACK);


    //Add the controlPanel to the content pane, adjust to
    // the correct size, and set the title.
    getContentPane().add(controlPanel);
    pack();
    setTitle("Copyright 2008,R.G.Baldwin");

    //Disable all user controls except for the text field
    // where the user enters the name of the input file.
    //The user controls will be enabled when the user
    // enters the name of the input file.
    getColorButton.setEnabled(false);
    copyColorButton.setEnabled(false);
    updateColorButton.setEnabled(false);
    writeButton.setEnabled(false);
    quitButton.setEnabled(false);

    redButton.setEnabled(false);
    greenButton.setEnabled(false);
    blueButton.setEnabled(false);
    whiteButton.setEnabled(false);
    blackButton.setEnabled(false);
    chooseButton.setEnabled(false);
    darkerButton.setEnabled(false);
    brighterButton.setEnabled(false);

    oldRedField.setEnabled(false);
    oldGreenField.setEnabled(false);
    oldBlueField.setEnabled(false);

    newRedField.setEnabled(false);
    newGreenField.setEnabled(false);
    newBlueField.setEnabled(false);


    //Make the GUI visible, set the focus, and establish a
    // reference to the GUI object.
    setVisible(true);
    inputFileNameField.requestFocus();
    thisObj = this;

    //--------------------------------------------------//
    //Register listeners on the user input components.
    //--------------------------------------------------//
    getColorButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          oldRedField.setText(explorer.getRValue());
          oldGreenField.setText(explorer.getGValue());
          oldBlueField.setText(explorer.getBValue());

          String oldRedString = oldRedField.getText();
          String oldGreenString = oldGreenField.getText();
          String oldBlueString = oldBlueField.getText();
          oldRedInt = goParseInt(oldRedString.substring(
                            oldRedString.indexOf(':')+2));
          oldGreenInt = goParseInt(
                        oldGreenString.substring(
                          oldGreenString.indexOf(':')+2));
          oldBlueInt = goParseInt(oldBlueString.substring(
                           oldBlueString.indexOf(':')+2));

          oldColorIndicatorPanel.setBackground(
             new Color(oldRedInt,oldGreenInt,oldBlueInt));
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    copyColorButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          newRedField.setText("" + oldRedInt);
          newGreenField.setText("" + oldGreenInt);
          newBlueField.setText("" + oldBlueInt);
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    updateColorButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){

          xIndex = explorer.getXIndex();
          yIndex = explorer.getYIndex();
          zoomFactor = explorer.getZoomFactor();
          String zoomString = "100%";
          if(zoomFactor == 0.25){
            zoomString = "25%";
          }else if(zoomFactor == 0.50){
            zoomString = "50%";
          }else if(zoomFactor == 0.75){
            zoomString = "75%";
          }else if(zoomFactor == 1.0){
            zoomString = "100%";
          }else if(zoomFactor == 1.5){
            zoomString = "150%";
          }else if(zoomFactor == 2.0){
            zoomString = "200%";
          }else if(zoomFactor == 5.0){
            zoomString = "500%";
          }else{
            zoomString = "100%";//in case no match
          }//end else

          int newRedInt = goParseInt(
                                   newRedField.getText());
          int newGreenInt = goParseInt(
                                 newGreenField.getText());
          int newBlueInt = goParseInt(
                                  newBlueField.getText());

          if(!((newRedInt >= 0) && (newRedInt <= 255))){
            newRedInt = 0;
            newRedField.setText("Err");
          }//end if

          Color newColor = new Color(
                        newRedInt,newGreenInt,newBlueInt);
          pix.getPixel(xIndex,yIndex).setColor(newColor);

          //Dispose of the existing explorer and create a
          // new one.
          explorerFrame.dispose();

          explorer = new PictureExplorer(
                                        new Picture(pix));
          //Get ref to the new frame
          explorerFrame = explorer.getFrame();
          explorerFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

          //Now set the state of the new explorer.
          //Simulate a mouse pressed event in the picture
          // to set the cursor and the text in the
          // coordinate fields.
          explorer.mousePressed(new MouseEvent(
                           new JButton("dummy component"),
                           MouseEvent.MOUSE_PRESSED,
                           (long)0,
                           0,
                           xIndex,
                           yIndex,
                           0,
                           false));

          //Simulate an action event on the zoom menu to
          // set the zoom.
          explorer.actionPerformed(new ActionEvent(
                             explorer,
                             ActionEvent.ACTION_PERFORMED,
                             zoomString));


        }//end actionPerformed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    redButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          newRedField.setText("255");
          newGreenField.setText("000");
          newBlueField.setText("000");
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    greenButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          newRedField.setText("000");
          newGreenField.setText("255");
          newBlueField.setText("000");
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    blueButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          newRedField.setText("000");
          newGreenField.setText("000");
          newBlueField.setText("255");
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    whiteButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          newRedField.setText("255");
          newGreenField.setText("255");
          newBlueField.setText("255");
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    blackButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          newRedField.setText("000");
          newGreenField.setText("000");
          newBlueField.setText("000");
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    chooseButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          Color selColor = JColorChooser.showDialog(
                    chooseButton,"Choose color",new Color(
                       oldRedInt,oldGreenInt,oldBlueInt));
          if(selColor != null){
            //Don't change the color if the user cancels
            // out.
            newRedField.setText("" + selColor.getRed());
            newGreenField.setText(
                                "" + selColor.getGreen());
            newBlueField.setText("" + selColor.getBlue());
          }//end if
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    writeButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
            pix.write(outputPath);
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    darkerButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          Color color = new Color(
               newRedInt,newGreenInt,newBlueInt).darker();
          newRedField.setText("" + color.getRed());
          newGreenField.setText("" + color.getGreen());
          newBlueField.setText("" + color.getBlue());
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    brighterButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          Color color = new Color(
             newRedInt,newGreenInt,newBlueInt).brighter();
          newRedField.setText("" + color.getRed());
          newGreenField.setText("" + color.getGreen());
          newBlueField.setText("" + color.getBlue());
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Note that the Quit button and the JFrame close
    // button are designed to behave the same way: save
    // the file and terminate the program.
    quitButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          pix.write(outputPath);
          System.exit(0);
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    thisObj.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          pix.write(outputPath);
          System.exit(0);
        }//end windowClosing
      }//end new WindowAdapter
    );//end addWindowListener
    //--------------------------------------------------//

    inputFileNameField.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          fileName = inputFileNameField.getText();

          pix = new Picture(fileName);

          //Because color corruption can occur when
          // writing jpg files in Java, the following code
          // makes a copy of the input file as a bmp file.
          // All further processing and writing is done in
          // bmp format. The characters BAK are
          // inserted in the output file immediately
          // before the extension. The final output is a
          // bmp file, which can be converted back to a
          // jpg file using an image-utility program such
          // as Lview.
          String inputPath = new File(fileName).
                                        getAbsolutePath();
          int posDot = inputPath.lastIndexOf('.');
          outputPath = inputPath.substring(0,posDot)
                                              + "BAK.bmp";
          pix.write(outputPath);

          explorer =
                    new PictureExplorer(new Picture(pix));
          explorerFrame = explorer.getFrame();
          explorerFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);
          thisObj.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

          //Cause the GUI to be located immediately below
          // the PictureExplorer object.
          setLocation(0,explorerFrame.getHeight());

          getColorButton.setEnabled(true);
          copyColorButton.setEnabled(true);
          updateColorButton.setEnabled(true);
          writeButton.setEnabled(true);
          quitButton.setEnabled(true);

          redButton.setEnabled(true);
          greenButton.setEnabled(true);
          blueButton.setEnabled(true);
          whiteButton.setEnabled(true);
          blackButton.setEnabled(true);
          chooseButton.setEnabled(true);
          darkerButton.setEnabled(true);
          brighterButton.setEnabled(true);

          oldRedField.setEnabled(true);
          oldGreenField.setEnabled(true);
          oldBlueField.setEnabled(true);

          newRedField.setEnabled(true);
          newGreenField.setEnabled(true);
          newBlueField.setEnabled(true);

        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    newRedField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            newRedInt = Integer.parseInt(
                                   newRedField.getText());
            if((newRedInt >= 0) && (newRedInt <= 255)){
              paintNewColorIndicator();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            newRedInt = Integer.parseInt(
                                   newRedField.getText());
            if((newRedInt >= 0) && (newRedInt <= 255)){
              paintNewColorIndicator();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//

    newGreenField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            newGreenInt = Integer.parseInt(
                                 newGreenField.getText());
            if((newGreenInt >= 0) && (newGreenInt <= 255))
            {
              paintNewColorIndicator();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            newGreenInt = Integer.parseInt(
                                 newGreenField.getText());
            if((newGreenInt >= 0) && (newGreenInt <= 255))
            {
              paintNewColorIndicator();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//
    newBlueField.getDocument().addDocumentListener(
      new DocumentListener(){
        public void changedUpdate(DocumentEvent e){}

        public void removeUpdate(DocumentEvent e){
          try{
            newBlueInt = Integer.parseInt(
                                  newBlueField.getText());
            if((newBlueInt >= 0) && (newBlueInt <= 255)){
              paintNewColorIndicator();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end removeUpdate

        public void insertUpdate(DocumentEvent e){
          try{
            newBlueInt = Integer.parseInt(
                                  newBlueField.getText());
            if((newBlueInt >= 0) && (newBlueInt <= 255)){
              paintNewColorIndicator();
            }//end if
          }catch(Exception ex){
            //do nothing on exception
          }//end catch
        }//end insertUpdate

      }//end new DocumentListener
    );//end addDocumentListener
    //--------------------------------------------------//
  }//end constructor
  //----------------------------------------------------//

  //The purpose of this method is to color a swatch next
  // to the new RGB values.
  void paintNewColorIndicator(){
    newColorIndicatorPanel.setBackground(
             new Color(newRedInt,newGreenInt,newBlueInt));
  }//end paintNewColorIndicator

  //----------------------------------------------------//

  //The purpose of this method is to absorb exceptions
  // that may be thrown by the parseInt method. In the
  // event that an exception is thrown, this method simply
  // returns an int value of 0;
  private int goParseInt(String string){
    int result = 0;
    try{
      result = Integer.parseInt(string);
    }catch(Exception e){
      result = 0;
    }//end catch
    return result;
  }//end goParseInt
  //----------------------------------------------------//

}//end class PixelEditor01


//34567890123456789012345678901234567890123456789012345678
