//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//

//07/08/06 This program is ready to publish.


/*File ImgMod39.java
Copyright 2006, R.G.Baldwin

The purpose of this class is to illustrate a variety of 
different uses for the LookupOp class of the Java 2D API.
In each case, the program uses three data arrays to 
process the red, green, and blue color bands individually
on in combination.

See general comments in the class named ImgMod038.

This class is compatible with the use of the driver program
named ImgMod05.

The driver program named ImgMod05 displays the original and
the modified images.  It also writes the modified image 
into an output file in JPEG format.  The name of the output
file is junk.jpg and it is written into the current 
directory.

Image-processing programs such as this one may provide a 
GUI for user data input making it possible for the user to 
modify the behavior of the image-processing method each 
time the Replot button is clicked.  Such a GUI is provided
for this program.

Enter the following at the command line to run this 
program:

java ImgMod05 ImgMod39 ImageFileName

If the program is unable to load the image file within ten
seconds, it will abort with an error message.

This program creates a GUI consisting of a tabbed pane 
containing three pages.  The tabs on the pages are labeled:

Color Inversion
Posterizing
Custom Transforms

Each page contains a set of controls that make it possible
to process the image in a way that illustrates the 
processing concept indicated by the labels on the tabs.
Processing details for each page are provided in the 
comments in the code used to construct and process the 
individual pages.

Tested using J2SE 5.0 under WinXP.
**********************************************************/

import java.awt.image.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ImgMod39 extends Frame implements ImgIntfc05{
  //Primary container used to construct the GUI.
  JTabbedPane tabbedPane = new JTabbedPane();
  
  //Components used to construct the page in the
  // JTabbedPane that shows Color Inversion on the tab.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel page00 = new Panel();
  Checkbox page00RedCkBx = new Checkbox("Red");
  Checkbox page00GreenCkBx = new Checkbox("Green");
  Checkbox page00BlueCkBx = new Checkbox("Blue");

  //Components used to construct the Posterizing page in
  // the JTabbedPane. Components that require local access
  // only are defined locally.  Others are defined here as
  // instance variables.
  Panel page01 = new Panel();
  TextField page01TextField = new TextField("128",6);
  Checkbox page01RedCkBx = new Checkbox("Red");
  Checkbox page01GreenCkBx = new Checkbox("Green");
  Checkbox page01BlueCkBx = new Checkbox("Blue");
  
  //Components used to construct the Custom Transforms
  // page in the JTabbedPane.  Components that require
  // local access only are defined locally.  Others are
  // defined here as instance variables.
  Panel page02 = new Panel();
  TextField page02TextField = new TextField("1.0",6);
  Checkbox page02RedCkBx = new Checkbox("Red");
  Checkbox page02GreenCkBx = new Checkbox("Green");
  Checkbox page02BlueCkBx = new Checkbox("Blue");
  CheckboxGroup group = new CheckboxGroup();
  Checkbox page02LogRadioButton = 
                  new Checkbox("Log Transform",group,true);
  Checkbox page02LinearRadioButton = 
              new Checkbox("Linear Transform",group,false);
  
  //-----------------------------------------------------//
  
  //This is the primary constructor.  It calls other
  // methods to separate the construction of the GUI into
  // easily understandable units.  Each method that it
  // calls constructs one page in the tabbed pane.
  ImgMod39(){//constructor
  
    constructPage00();
    tabbedPane.add(page00);//Add page to the tabbedPane.
    
    constructPage01();
    tabbedPane.add(page01);//Add page to the tabbedPane.
    
    constructPage02();
    tabbedPane.add(page02);//Add page to the tabbedPane.
    
    add(tabbedPane);//Add tabbedPane to the Frame.

    setTitle("Copyright 2006, R.G.Baldwin");
    setBounds(555,0,470,300);
    setVisible(true);

    //Define a WindowListener to terminate the program.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(1);
        }//end windowClosing
      }//end windowAdapter
    );//end addWindowListener
  }//end constructor
  //-----------------------------------------------------//
  
  //This method constructs the page in the tabbed pane that
  // shows Color Inversion on the tab.  This method is
  // called from the primary constructor.  It illustrates
  // color inversion using three arrays, one for each of
  // the red, green, and blue color bands.
  void constructPage00(){
    page00.setName("Color Inversion");//Label on the tab.
    page00.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    // This text appears in a disabled text area at the
    // top of the page in the tabbed pane.
    String text ="COLOR INVERSION USING MULTIPLE ARRAYS\n"
      + "This page illustrates the use of the LookupOp "
      + "filter class for multiple lookup arrays.  By "
      + "checking the appropriate checkboxes below, you "
      + "can cause the program to invert the colors on "
      + "none, or on any combination of color bands.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,4,1,
                                 TextArea.SCROLLBARS_NONE);
    page00.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);

    //Construct the control panel and add it to the page.
    Panel page00ControlPanel = new Panel();
    page00ControlPanel.add(page00RedCkBx);
    page00ControlPanel.add(page00GreenCkBx);
    page00ControlPanel.add(page00BlueCkBx);
    page00.add(page00ControlPanel,BorderLayout.CENTER);
  }//end constructPage00
  //-----------------------------------------------------//

  //This method processes the image according to the
  // controls located on the page in the tabbed pane that
  // shows Color Inversion on the tab.
  //This method uses the LookupOp image-filtering class to
  // process the image using lookup data from three
  // separate arrays, one each for the red, green, and blue
  // color bands.
  //This method is called from within a switch statement in
  // the method named processImg, which is the primary
  // image-processing method in this program.
  //This method illustrates color inversion.  The effect of
  // color inversion is to produce an output in which the
  // image is similar to the negative of a color
  // photograph.
  BufferedImage processPage00(BufferedImage theImage){
    //Create array objects that will be populated with data
    // that is used later to populate the lookup table.
    short[] red = null;
    short[] green = null;
    short[] blue = null;
    
    //Create and populate arrays for straight (noInvert)
    // lookup data and inverted lookup data.
    short[] noInvert = new short[256];
    short[] invert = new short[256];
    for(int cnt = 0;cnt < 256;cnt++){
      invert[cnt] = (short)(255 - cnt);//inverted data
      noInvert[cnt] = (short)cnt;//straight lookup data
    }//end for loop
    
    //Point the three color arrays to the array containing
    // the data that doesn't invert the colors.  This is
    // the default case if no checkboxes are checked.
    red = noInvert;
    green = noInvert;
    blue = noInvert;
    
    //Examine the check boxes.  If any checkbox has been
    // checked, point the corresponding color array to the
    // array containing the inversion data.
    if(page00RedCkBx.getState() == true){
      red = invert;
    }//end if
    if(page00GreenCkBx.getState() == true){
      green = invert;
    }//end if
    if(page00BlueCkBx.getState() == true){
      blue = invert;
    }//end if

    //Use the LookupOp class from the Java 2D API along
    // with three separate data arrays to process the
    // color values in the selected color bands.  The
    // alpha value is not modified.
    return processImageForThePage(theImage,red,green,blue);

  }//end processPage00
  //-----------------------------------------------------//
  
  //This method constructs the page in the tabbed pane that
  // shows Posterizing on the tab.  This method is called
  // from the primary constructor.  It illustrates
  // posterizing.
  //Posterizing is a process of reducing the number of
  // colors in an image to a relatively small number.  The
  // effect is to cause the image to look similar to a
  // painting that was painted using a "paint by numbers"
  // set where the smooth transitions from one color to the
  // next have been eliminated.  This is accomplished by
  // limiting the number of different colors that appear
  // in the image.
  void constructPage01(){
    page01.setName("Posterizing");//Label on the tab.
    page01.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    String text = "POSTERIZING\n"
      + "The effect of posterizing is to cause the image "
      + "to look similar to a painting that was painted "
      + "using a \"paint by numbers\" set where the smooth"
      + "transitions from one color to the next have been "
      + "eliminated.  This is accomplished by limiting "
      + "the number of different colors that appear in "
      + "the image.\n\n"
      + "To posterize an image, decide how many levels "
      + "you want to see for each of the three colors, "
      + "red, green, and blue.  Enter that number in the "
      + "text field below.  Select the colors that you "
      + "want to mix by checking the matching check boxes "
      + "and click the Replot button.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,9,1,
                                 TextArea.SCROLLBARS_NONE);
    page01.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);
    
    //Construct the control panel and add it to the page.
    Panel page01ControlPanel = new Panel();
    page01ControlPanel.add(page01TextField);
    page01ControlPanel.add(page01RedCkBx);
    page01ControlPanel.add(page01GreenCkBx);
    page01ControlPanel.add(page01BlueCkBx);
    page01.add(page01ControlPanel,BorderLayout.CENTER);
    
  }//end constructPage01
  //-----------------------------------------------------//

  //This method processes the image according to the
  // controls located on the page in the tabbed pane that
  // shows Posterizing on the tab.  This method is called
  // from within a switch statement in the method named
  // processImg.  Note that this method processes the image
  // using three arrays.
  BufferedImage processPage01(BufferedImage theImage){

    int numberLevels = 1;
    try{//Get input value from the text field.
      numberLevels = 
               Integer.parseInt(page01TextField.getText());
    }catch(java.lang.NumberFormatException e){
      page01TextField.setText("Bad Input");
      numberLevels = 1;//Override bad user input.
    }//end catch
    
    //Guarantee that the number of levels falls within the
    // allowable range.  Don't allow divison by 0.
    if((numberLevels <= 0) || (numberLevels > 256)){
      page01TextField.setText("Bad Input");
      numberLevels = 1;//Override bad user input.
    }//end if
    
    //Compute the number of adjacent elements that will
    // specify the same color value.
    int binSize = 256/numberLevels;
    
    //Create array objects that will be populated with
    // data that is used to populate the lookup table.
    //Note that by default these arrays are populated with
    // all zero values.
    short[] red = new short[256];
    short[] green = new short[256];
    short[] blue = new short[256];
    
    //Create and populate an array object with master data
    // that will be used to populate the specific arrays
    // for the colors that are to be processed.
    short[] masterData = new short[256];
    for(int cnt = 0;cnt < 256;cnt++){
      short value = 
              (short)((cnt/binSize)*binSize + binSize - 1);
      //Clip the values at 0 and 255.
      if(value >= 256) value = 255;
      if(value < 0) value = 0;//Probably not possible.
      masterData[cnt] = value;
    }//end for loop

    //Examine the check boxes.  If any checkbox has been
    // checked, reset the corresponding array to point it
    // to the array containing the master data.  Otherwise,
    // it will contain all zero values by default.
    if(page01RedCkBx.getState() == true){
      red = masterData;
    }//end if
    if(page01GreenCkBx.getState() == true){
      green = masterData;
    }//end if
    if(page01BlueCkBx.getState() == true){
      blue = masterData;
    }//end if
    
    //Process the image and return the result.
    return processImageForThePage(theImage,red,green,blue);

  }//end processPage01
  //-----------------------------------------------------//
  
  //This method constructs the page in the tabbed pane that
  // shows Custom Transforms on the tab.  This method is
  // called from the primary constructor.  This page
  // illustrates the use of custom transformations of the
  // values in the color bands.
  void constructPage02(){
    page02.setName("Custom Transforms");//Tab label.
    page02.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    String text = "CUSTOM TRANSFORMS\n"
      + "This page illustrates the use of two different "
      + "custom transforms, one based on the log to the "
      + "base 10, and the other based on the equation of "
      + "a straight line.  Both transforms are designed "
      + "to boost the intensity of pixels with low color "
      + "values.\n\n"
      + "Specify the color bands that you want to process "
      + "by checking the checkboxes.\n\n"
      + "Select a radio button to select a transform.  "
      + "For the linear transform, enter a positive slope "
      + "that is <= 1.0.  Try a slope of 0.85 for "
      + "example\n\n"
      + "Then click the Replot button.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,9,1,
                                 TextArea.SCROLLBARS_NONE);
    page02.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);
    
    //Construct the control panel and add it to the page.
    Panel page02ControlPanel = new Panel();
    page02ControlPanel.setLayout(new GridLayout(3,1));
    
    Panel subControlPanel00 = new Panel();
    subControlPanel00.add(page02RedCkBx);
    subControlPanel00.add(page02GreenCkBx);
    subControlPanel00.add(page02BlueCkBx);
    page02ControlPanel.add(subControlPanel00);
    
    Panel subControlPanel01 = new Panel();
    subControlPanel01.setLayout(
                          new FlowLayout(FlowLayout.LEFT));
    subControlPanel01.add(page02LogRadioButton);
    page02ControlPanel.add(subControlPanel01);
    
    Panel subControlPanel02 = new Panel();
    subControlPanel02.setLayout(
                          new FlowLayout(FlowLayout.LEFT));
    subControlPanel02.add(page02LinearRadioButton);
    subControlPanel02.add(new Label("  Slope ="));
    subControlPanel02.add(page02TextField);
    subControlPanel02.add(
                   new Label("must be >= 0.0 and <= 1.0"));
    page02ControlPanel.add(subControlPanel02);
    
    page02.add(page02ControlPanel,BorderLayout.CENTER);
    
  }//end constructPage02
  //-----------------------------------------------------//

  //This method processes the image according to the
  // controls located on the page in the tabbed pane that
  // shows Custom Transforms on the tab.  This method is
  // called from within a switch statement in the method
  // named processImg.  Note that this method processes the
  // image using three arrays.  It transforms the values
  // in the color bands according to either a log
  // transform, or a linear transform, with the choice
  // being made by the user through the selection of a
  // radio button.  The net effect of both transforms is to
  // emphasize or boost the intensity of colors having low
  // values, thus causing the image to become brighter.
  // The two transforms achieve this effect in different
  // ways,however.
  BufferedImage processPage02(BufferedImage theImage){
    
    //Create array objects that will be populated with
    // data that is used to populate the lookup table.
    // Note that by default these arrays are populated with
    // all zero values.
    short[] red = new short[256];
    short[] green = new short[256];
    short[] blue = new short[256];
    
    //Create and populate an array object with master data
    // that will be used to populate the specific arrays
    // for the colors that are selected to be processed.
    short[] masterData = new short[256];
    for(int cnt = 0;cnt < 256;cnt++){
      short value = 0;
      //Select between log or linear transformation based
      // on the state of two radio buttons.      
      if(page02LogRadioButton.getState() == true){
        //Perform a log conversion
        if(cnt == 0){
          //Avoid computing the log of 0.  Substitute the
          // log of 1 instead.  (Note that with J2SE 5.0,
          // I could have used a static import directive
          // in order to eliminate the explicit reference
          // to the Math class in the following
          // expressions.)
          value =
              (short)(Math.log10(1.0)*255/Math.log10(255));
        }else{
          value = 
              (short)(Math.log10(cnt)*255/Math.log10(255));
        }//end else
      }else{//Linear conversion must have been selected
        //Perform a linear conversion
        double slope = 0;
        try{//Get the slope from the text field.
          slope = 
             Double.parseDouble(page02TextField.getText());
        }catch(java.lang.NumberFormatException e){
          page02TextField.setText("Bad Input");
          slope = 0.0;//Override user input on bad input.
        }//end catch

        //Guarantee that the slope is positive and <= 1.0.
        if((slope < 0.0) || (slope > 1.0)){
          page02TextField.setText("Bad Input");
          slope = 0.0;//Override user input on bad input.
        }//end if
        
        //Compute the intercept of a straight line with the
        // y-axis using the slope provided by the user. 
        // Cause the line to go through a y-value of 255
        // at an x-value of 255.
        int yIntercept = (int)(255.0 - 255.0*slope);
        
        //Compute the value of y for each value of x(cnt)
        // using the equation of a straight line, which
        // is, y = slope*x + yIntercept
        value = (short)(slope*cnt + yIntercept);
        
        //Guard against roundoff errors that might cause
        // the color values to go slightly outside their
        // allowed range of 0 through 255.
        if(value < 0) value = 0;
        if(value > 255) value = 255;
      }//end else

      masterData[cnt] = value;
    }//end for loop

    //Examine the check boxes.  If any checkbox has been
    // checked, reset the corresponding array to point it
    // to the array containing the master data.  Otherwise,
    // it will contain all zero values by default.
    if(page02RedCkBx.getState() == true){
      red = masterData;
    }//end if
    if(page02GreenCkBx.getState() == true){
      green = masterData;
    }//end if
    if(page02BlueCkBx.getState() == true){
      blue = masterData;
    }//end if
    
    //Process the image and return the processed result.
    return processImageForThePage(theImage,red,green,blue);

  }//end processPage02
  //-----------------------------------------------------//
  
  //Use the LookupOp class from the Java 2D API along
  // with three separate data arrays to process the
  // color values in the selected color bands.  The
  // alpha value is not modified.  This is a common method
  // that is called by the code that processes each
  // individual page in the tabbed pane.
  BufferedImage processImageForThePage(
                                    BufferedImage theImage,
                                    short[] red,
                                    short[] green,
                                    short[] blue){
    //Create and populate a 2D array with data for the
    // lookup table.  Note that this is a 2D array, rather
    // than a 1D array, which is the case when a single
    // data array is used to process all three color bands.
    short[][] lookupData = new short[][]{red,green,blue};

    //Create the lookup table.  The first parameter is an
    // offset for extracting data from the array object.
    //In this case, all of the data is extracted from the
    // array object beginning at an index of 0.
    ShortLookupTable lookupTable = 
                        new ShortLookupTable(0,lookupData);

    //Create the filter object. The second parameter
    // provides the opportunity to use RenderingHints.
    BufferedImageOp filterObject = 
                            new LookupOp(lookupTable,null);
                            
    //For illustration purposes only, work backwards from
    // the filterObject to get and display some data
    // from the lookup table.  Note that this is not an
    // image-processing requirement.
    displayTableData(filterObject);

    //Apply the filter to the incoming image and return
    // a reference to the resulting BufferedImage object.
    // The second parameter can optionally specify an
    // existing BufferedImage object to serve as a 
    // destination for the processed image.
    return filterObject.filter(theImage, null);
  }//end processImageForThePage
  //-----------------------------------------------------//

  //Print some column headers followed by data from the
  // lookup table.  Print every 32nd row beginning with
  // row 0.  Then print the data for row 255.
  void displayTableData(BufferedImageOp filterObject){
    
    //First, get a 2D array containing data from the lookup
    // table.
    ShortLookupTable theTable = ((ShortLookupTable)(
                       (LookupOp)filterObject).getTable());
    short[][] tableData = theTable.getTable();
    
    System.out.println("Row\tRed\tGreen\tBlue");
    for(int row = 0;
        row<tableData[0].length;
        row += 32){
        System.out.print((row) + "\t");
      for(int col = 0;
          col<tableData.length;
          col++){
        System.out.print(tableData[col][row] + "\t");
      }//end inner loop
      System.out.println();
    }//end outer loop
    System.out.println(255 + "\t" + tableData[0][255] 
                       + "\t" + tableData[1][255] + "\t" 
                       + tableData[2][255]);
    
  }//end displayTableData
  
  //-----------------------------------------------------//

  //The following method must be defined to implement the
  // ImgIntfc05 interface.  It is called by the framework
  // program named ImgMod05.
  public BufferedImage processImg(BufferedImage theImage){
    
    BufferedImage outputImage = null;
    
    //Process the page in the tabbed pane that has been
    // selected by the user.
    switch(tabbedPane.getSelectedIndex()){
      case 0:outputImage = processPage00(theImage);
             break;
      case 1:outputImage = processPage01(theImage);
             break;
      case 2:outputImage = processPage02(theImage);
             break;
    }//end switch

    return outputImage;
  }//end processImg

}//end class ImgMod39




