//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//
// Ready for publication 06/17/06

/*File ImgMod38.java
Copyright 2006, R.G.Baldwin

The purpose of this class is to provide a simple example of
an image processing class that is compatible with the use
of the program named ImgMod05, and which illustrates a 
single usage of the LookupOp class from the image
processing portion of the Java 2D API.  (Future programs
will illustrate other uses of the LookupOp class.)

A class that is compatible with ImgMod05 is required to 
implement the interface named ImgIntfc05. This, in turn, 
requires the class to define the method named processImg,
which receives one parameter of type BufferedImage and 
returns a reference of type BufferedImage.

The required signature for the processImg method is:

public BufferedImage processImg(BufferedImage input);

The processImg method receives a reference to a 
BufferedImage object containing the image that is to be
processed

The processImg method must return a reference to a
BufferedImage object containing the processed image.

In this example, the method named processImg is a color 
inverter method. 

The method named processImg as defined in this class 
receives an incoming reference to an image as a parameter 
of type BufferedImage.  The method returns a reference to 
an image as type BufferedImage where all of the color 
values in the pixels have been inverted by subtracting the 
color values from 255. 

The method has been demonstrated to work properly only for 
the case where the incoming BufferedImage object was 
constructed for image type BufferedImage.TYPE_INT_RGB.  
However, it may work properly for other image types as 
well. 

Note that this class does not define a constructor. 
However, if it did define a constructor, that constructor 
would not be allowed to receive parameters. This is because
the class named ImgMod05 instantiates an object of this 
class by invoking the newInstance method of the Class 
class passing the name of this class to the newInstance 
method as a String parameter.  That process does not allow 
for constructor parameters for the class being 
instantiated.

The driver program named ImgMod05 displays the original and
the modified images.  It also writes the modified image 
into an output file in JPEG format.  The name of the output
file is junk.jpg and it is written into the current 
directory.

The output GUI for the driver program named ImgMod05 
contains a Replot button.  At the beginning of the run, and
each time thereafter that the Replot button is clicked:
-The image processing method belonging to the image 
 processing object is invoked,
-The resulting modified image is displayed along with the 
 original image.

Image processing programs such as this one may provide a 
GUI for data input making it possible for the user to 
modify the behavior of the image processing method each 
time the Replot button is clicked.  However, no such GUI
is provided by this program and clicking the Replot
button is of no consequence.

The driver program named ImgMod05 reads gif and jpg input 
files and possibly some other input file types as well.  
The output file is always a JPEG file.

Usage:

Enter the following at the command line to run this 
program:

java ImgMod05 ImgMod38 ImageFileName

The image file must be provided by the user.  However, it 
doesn't have to be in the current directory if a path to 
the file is included along with the file name on the 
command line.

When the program is started, the original image and the
processed version of the image are displayed in a frame
with the original image above the processed image.

The driver program named ImgMod05 attempts to adjust the
size of the display frame to accommodate both images.  If
the processed image doesn't fit in the display, the user
can manually resize the display frame in order to view both
images.

If the program is unable to load the image file within ten
seconds, it will abort with an error message.

Tested using J2SE5.0 under WinXP.
**********************************************************/

import java.awt.image.*;

class ImgMod38 implements ImgIntfc05{

  //The following method must be defined to implement the
  // ImgIntfc05 interface.
  public BufferedImage processImg(BufferedImage theImage){

    //Use the LookupOp class from the Java 2D API to
    // invert all of the color values in the pixels.  The
    // alpha value is not modified.

    //Create the data for the lookup table.
    short[] lookupData = new short[256];
    for (int cnt = 0; cnt < 256; cnt++){
      lookupData[cnt] = (short)(255-cnt);
    }//end for loop
    
    //Create the lookup table
    ShortLookupTable lookupTable = 
                        new ShortLookupTable(0,lookupData);

    //Create the filter object.
    BufferedImageOp thresholdOp = 
                            new LookupOp(lookupTable,null);

    //Apply the filter to the incoming image and return
    // a reference to the resulting BufferedImage object.
    return thresholdOp.filter(theImage, null);
  }//end processImg

}//end class ImgMod38





