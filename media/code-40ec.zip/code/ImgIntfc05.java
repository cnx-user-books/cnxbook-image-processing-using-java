//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version.
//=======================================================//

/*File ImgIntfc05.java
Copyright 2006, R.G.Baldwin

The purpose of this interface is to declare the method 
required by image processing classes that are 
compatible with the program named ImgMod05.java.

Tested using J2SE 5.0 under WinXP
**********************************************************/

import java.awt.image.BufferedImage;

interface ImgIntfc05{
  public BufferedImage processImg(BufferedImage input);
}//end ImgIntfc05
//=======================================================//
