//34567890123456789012345678901234567890123456789012345678
//This is an update to Lasso01 that adds a circular lasso
// and also improves on the rectangle/ellipse lasso.
//02/04/09 Ready to publish

/*File Lasso02 Copyright 2009 R.G.Baldwin

This is a demonstration program that shows how to create
two different lasso styles by dragging a mouse in an image
in a Picture object.

The program begins by displaying a GUI in the upper left
corner of the screen. At that point, the GUI contains a
text field for entry of the name of the image file to be
processed and some other user-input components, which are
disabled.  If the file is in the current directory, only
the file name and extension must be entered. Otherwise,
the full path and name and extension for the file must be
entered. Files of types jpg, bmp, and png are supported.

When the user enters the name of the image file into the
text field, the file is loaded into a Picture object. The
Picture object is displayed in the upper left corner of
the screen and the GUI is moved to a location immediately
below the Picture object.  At this point, the text field
is disabled.  Two buttons and two radio buttons are
enabled.

One button is labeled Process Pixels and the other button
is labeled Write. One radio button is labeled Rect/Ellipse
and the other radio button is labeled Circle. The
Rect/Lasso button is initially selected by the program.

At this point with the Rect/Ellipse button selected, the
user can drag the mouse in the image to create a lasso
consisting of a rectangle with an inscribed ellipse.  The
rectangle and the ellipse can be created in any quadrant
relative to the anchor point. The anchor point is the
location at which the drag operation begins. One corner
of the rectangle will always touch the anchor point.

When the Circle button is selected, the user can drag the
mouse in the image to create a circular lasso. It can be
created in any direction from the anchor point.  The
diameter of the circular lasso is equal to the distance of
the mouse pointer from the anchor point.

Dragging the mouse outside the bounds of the picture
causes the size of the either lasso to continue to grow.
The lasso ends when the user releases the mouse button.

The lasso remains on the screen until the user clicks the
image with the mouse, clicks the Process Pixels button, or
does something else to cause the image to be repainted.

After the lasso has been drawn, the button labeled Process
Pixels can be clicked to cause a method to be called to
process the pixels in the image relative to the position
and size of the lasso. Different methods are called for
the two styles of lasso.

You can modify either or both of these methods to satisfy
your own pixel-processing needs.

For the Rect/Ellipse lasso, the method can be written to
process all of the pixels that are contained in the
rectangle, the ellipse, or a combination of the two. For
the Circle lasso, the method can be written to process
all of the pixels that are contained in the circle.
Another alternative would be to write methods to process
all of the pixels that are not contained in the lasso.

Clicking anywhere in the image will erase an existing
lasso and allow the user to start over with a clean image
to create a new lasso. Clicking the image also erases the
effects of having clicked the Process Pixels button.

Clicking the Write button causes a backup bmp file to be
written into the same directory from which the image file
was read. The five most recent backup files are saved.
The names of the backup file are the same as the name of
the original image file except that the characters BAKn
are inserted immediately before the extension. The
character n is replaced by a digit from 0 through 4.

Clicking the large X in the upper-right corner of the
image display does nothing. The button is disabled.

The program is terminated by clicking the large X in the
upper-right corner of the GUI. Before terminating, the
program writes an output file containing the final state
of the display in the same format as the input file. The
name of the output file is the same as the name of the
input file except that the word FINAL is inserted
immediately before the extension.

This program does not modify the contents of the original
input file.

Tested using Windows Vista Home Premium Edition,
Java 1.6x, and the version of Ericson's multimedia library
contained in bookClasses10-1-07.zip.
*********************************************************/

import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.Rectangle2D;

import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.WindowConstants;

import java.io.File;

public class Lasso02 extends JFrame{
  //Create the components that are used to construct the
  // GUI.
  private JPanel mainPanel = new JPanel();
  private JPanel northPanel = new JPanel();
  private JPanel centerPanel = new JPanel();
  private JPanel southPanel = new JPanel();

  private JButton processButton =
                            new JButton("Process Pixels");
  private JButton writeButton = new JButton("Write");
  private JTextField fileNameField =
                            new JTextField("Lasso02.jpg");
  private JLabel fileNameLabel = new JLabel("File Name:");

  private JRadioButton rectButton =
                    new JRadioButton("Rect/Ellipse",true);
  private JRadioButton circleButton =
                               new JRadioButton("Circle");
  private ButtonGroup buttonGroup = new ButtonGroup();

  //A reference to the original Picture object will be
  // stored here.
  private Picture picture = null;

  //A reference to a modified copy of the original
  // Picture object will be stored here.
  private Picture display = null;

  //Miscellaneous working variables. Many variables were
  // made instance variables instead of local variables
  // to improve responsiveness during a mouse drag
  // operation.
  private Graphics graphics = null;

  private Pixel pixel = null;
  private int writeCounter = 0;

  private String fileName = "NONE";
  private String outputPath = null;
  private String extension = null;

  private int pictureWidth = 0;
  private int pictureHeight = 0;

  private int anchorX = 0;
  private int anchorY = 0;

  private int deltaX = 0;
  private int deltaY = 0;

  private int diameter = 0;
  private double angle = 0;

  private BufferedImage theImage = null;
  private JFrame theFrame = null;

  private Rectangle2D.Double rectangle = null;
  private Ellipse2D.Double ellipse = null;

  private Graphics2D g2 = null;

  private final double pi = Math.PI;//convenience constant
  //----------------------------------------------------//

  public static void main(String[] args){
    new Lasso02();
  }//end main method
  //----------------------------------------------------//

  public Lasso02(){//constructor

    //All close operations are handled in a WindowListener
    // object.
    setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

    //Construct the GUI.
    mainPanel.setLayout(new BorderLayout());
    mainPanel.add(northPanel,BorderLayout.NORTH);
    mainPanel.add(centerPanel,BorderLayout.CENTER);
    mainPanel.add(southPanel,BorderLayout.SOUTH);

    northPanel.add(processButton);

    //Add radio buttons to the center panel and make them
    // mutually exclusive.
    centerPanel.add(rectButton);
    buttonGroup.add(rectButton);
    centerPanel.add(circleButton);
    buttonGroup.add(circleButton);

    //Add a button, a label, and a text field to the south
    // panel.
    southPanel.add(writeButton);
    southPanel.add(fileNameLabel);
    southPanel.add(fileNameField);

    //Disable the buttons until the user enters the file
    // name.
    writeButton.setEnabled(false);
    processButton.setEnabled(false);
    rectButton.setEnabled(false);
    circleButton.setEnabled(false);

    //Set the size of the GUI and display it in the upper-
    // left corner of the screen. It will be moved later
    // to a position immediately below the display of the
    // picture.
    getContentPane().add(mainPanel);
    pack();
    setVisible(true);

    //Request that the focus move to the text field where
    // the file name is to be entered.
    fileNameField.requestFocus();
    //--------------------------------------------------//

    //Register a listener on the text field. When the user
    // enters the file name in the text field, set
    // everything up properly so that the program will
    // function as an event-driven picture-manipulation
    // program until the user clicks the large X in the
    // upper-right of the GUI.
    fileNameField.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Disable the text field and its label to
          // prevent the user from entering anything else
          // into it and causing it to fire another event.
          fileNameField.setEnabled(false);
          fileNameLabel.setEnabled(false);

          //Get the file name from the text field and use
          // it to create a new Picture object. Display my
          // name in the image.
          fileName = fileNameField.getText();
          picture = new Picture(fileName);
          picture.addMessage("Dick Baldwin",10,20);

          //Get information that will be used to write the
          // output files.
          String inputPath = new File(fileName).
                                        getAbsolutePath();
          int posDot = inputPath.lastIndexOf('.');
          outputPath = inputPath.substring(0,posDot);
          //Write the first copy of the output backup
          // file.
          picture.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");

          //Get filename extension. It will be used later
          // to write the final output file.
          extension = inputPath.substring(posDot);

          //Decorate the GUI.
          setTitle("Copyright 2009, R.G.Baldwin");

          //Create the picture that will be used for
          // processing.
          //Note that the original image file is not
          // modified by this program.
          display = new Picture(picture);

          //Display the picture.
          display.show();

          //Save a reference to the image. Also save the
          // width and height of the picture.
          theImage = (BufferedImage)(picture.getImage());
          pictureWidth = picture.getWidth();
          pictureHeight = picture.getHeight();

          //Get and save a reference to the JFrame object
          // that contains the image.
          theFrame = display.getPictureFrame().frame;

          //Get the graphics context on which to draw a
          // lasso.
          g2 = (Graphics2D)(theFrame.getGraphics());

          //Adjust the width of the GUI to match the width
          // of the display if possible. Then relocate the
          // GUI to a position immediately below the
          // display.
          //Establish the preferred size now that the
          // input file name has been entered.
          pack();
          int packedHeight = getHeight();
          int packedWidth = getWidth();
          if((pictureWidth + 7) >= packedWidth){
            //Make the width of the GUI the same as the
            // width of the display.
            setSize(pictureWidth + 7,packedHeight);
          }//Else, just leave the GUI at its current size.
          //Put the GUI in its new location immediately
          // below the display.
          setLocation(0,pictureHeight + 30);

          //Enable the user input controls.
          writeButton.setEnabled(true);
          processButton.setEnabled(true);
          rectButton.setEnabled(true);
          circleButton.setEnabled(true);

          //Disable the X-button on the display.
          theFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

          //--------------------------------------------//
          /*
          Note that the following two anonymous listener
          registrations are actually inside the action
          listener that is registered on the text field.
          The code in these two listener registration
          blocks can't be executed when the GUI is first
          constructed because a Picture object does not
          exist at that point in time. This code is
          executed after the user enters the image file
          name, the file has been read, and the Picture
          object referred to by display has been
          constructed.

          Now that an image has been loaded, a mouse
          listener can be registered on the JFrame object
          that contains the image.
          */
          theFrame.addMouseListener(
            new MouseAdapter(){
              public void mousePressed(MouseEvent e){
                //Draw a new copy of the image on the
                // display each time the user clicks the
                // image with the mouse. This makes it
                // possible to erase an existing lasso
                // simply by clicking anywhere in the
                // image regardless of whether or not it
                // is intended to drag a new lasso.
                graphics = display.getGraphics();
                graphics.drawImage(
                             picture.getImage(),0,0,null);
                display.repaint();

                //Prepare the variables so that the
                // mouseDragged event handler can lasso an
                // area.
                //Note that the reported coordinates for
                // a mouse press on the upper-left corner
                // of the image will not be reported
                // as 0,0 due to the top and left insets
                // of the JFrame. This can lead to some
                // confusion when analyzing the code.
                anchorX = e.getX();
                anchorY = e.getY();
                deltaX = 0;
                deltaY = 0;
              }//end mousePressed
            }//end new MouseAdapter
          );//end addMouseListener
          //--------------------------------------------//

          //Register a MouseMotionListener object that
          // will call a method to draw a lasso when the
          // moude is dragged in the image.
          theFrame.addMouseMotionListener(
            new MouseMotionAdapter(){
              public void mouseDragged(MouseEvent e){
                //Call the method to draw the lasso on the
                // basis of which radio button has been
                // selected.
                if(rectButton.isSelected()){
                  makeRectLasso(e.getX(),e.getY());
                }else if(circleButton.isSelected()){
                  makeCircleLasso(e.getX(),e.getY());
                }//end else
              }//end mouseDragged
            }//end new MouseMotionAdapter
          );//end addMouseMotionListener
          //--------------------------------------------//
        //Now finish the action listener that is
        // registered on the text field.
        }//end actionPerformed
      }//end new ActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register an ActionListener on the writeButton.
    // Each time the user clicks the button, a backup bmp
    // file containing the current state of the display is
    // written into the directory from which the original
    // picture was read. The five most recent backup files
    // are saved. The names of the backup files are the
    // same as the name of the input file except that BAKn
    // is inserted immediately ahead of the extension
    // where n is a digit ranging from 0 to 4. The value
    // of n rolls over at 4 and starts back at 0.
    writeButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          display.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");
          //Reset the writeCounter if it exceeds 4 to
          // conserve disk space.
          if(writeCounter > 4){
            writeCounter = 0;
          }//end if
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register a WindowListener that will respond when the
    // user clicks the large X in the upper-right corner
    // of the GUI. This event handler will write the final
    // state of the display into an output file of the
    // same type as the original input file. The name will
    // be the same except that the word FINAL will be
    // inserted immediately ahead of the extension.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          display.write(outputPath + "FINAL" + extension);
          System.exit(0);
        }//end windowClosing
      }//end new WindowAdapter
    );//end addWindowListener
    //--------------------------------------------------//

    //Register an action listener on the processButton
    // that calls a method to process the lasso.
    processButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Get rid of the black lasso pixels
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          display.repaint();
          //Call a method to process the pixels on the
          // basis of which radio button is selected.
          if(rectButton.isSelected()){
            processRectPixels();
          }else if(circleButton.isSelected()){
            processCirclePixels();
          }//end else
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

  }//end constructor
  //----------------------------------------------------//

  /*
  This method is called each time the mouse fires a
  mouseDragged event if the radio button labeled Circle
  // is selected.

  This version of the method draws a lasso consisting of a
  circular ellipse that touches the anchor point at all
  times. The diameter of the circle is determined by the
  distance of the mouse from the anchor point. The
  location of the circle is determined by the angle that a
  line going through the anchor point and the mouse
  pointer location makes with a horizontal line going
  through the anchor point. The circle can be drawn at any
  angle, and with any diameter, even if the mouse goes
  outside the bounds of the image.

  The circle remains on the screen until the user
  clicks the image with the mouse, clicks the
  Process Pixels button, or does somethin else to cause
  the image to be repainted.
  */
  private void makeCircleLasso(int x,int y){

    //The parameters x and y contain the coordinates of
    // the mouse pointer when the event was fired. Update
    // the diameter of the circular lasso.
    deltaX = x - anchorX;
    deltaY = y - anchorY;
    diameter = (int)Math.hypot(deltaX,deltaY);

    //Copy the entire image from the backup picture stored
    // in memory to erase any lassos drawn earlier. Also
    // erases the effects of prior clicks on the Process
    // Pixels button.
    g2.drawImage(theImage,
                 theFrame.getInsets().left,
                 theFrame.getInsets().top,null);

    //Get the angle in radians that a line joining the
    // anchor point and the current mouse location makes
    // with a horizontal line going through the anchor
    // point. This is the angle that will be used in the
    // computations required to rotate the circular
    // ellipse around the anchor point while continually
    // touching the anchor point.
    angle = Math.atan2((double)deltaY,(double)deltaX);

    //Create and draw a circular ellipse that touches the
    // anchor point at all times.
    ellipse = new Ellipse2D.Double(
          //Compute and specify the coordinates of the
          // upper left corner of a box that will contain
          // the circular ellipse.
          anchorX-(diameter/2-Math.cos(angle)*diameter/2),
          anchorY-(diameter/2-Math.sin(angle)*diameter/2),
          //Specify the width and the height of the box.
          diameter,
          diameter);
    //Draw the ellipse.
    g2.draw(ellipse);

  }//end makeCircleLasso
  //----------------------------------------------------//

  //This is a demo method that shows how to process pixels
  // contained in a circular elliptical lasso. You can
  // modify this method to meet your own needs.
  //This demo method eliminates green from all pixels
  // inside the circle.
  private void processCirclePixels(){
    //Protect against clicking the button before drawing
    // a lasso.
    if(ellipse == null) return;

    for(int col = 0;col < pictureWidth;col++){
      for(int row = 0;row < pictureHeight;row++){
        //Change the color of the pixels inside the
        // ellipse.
        //Note: It is necessary to compensate for the top
        // and left insets of the JFrame.
        if(ellipse.contains(
                         col + theFrame.getInsets().left,
                         row + theFrame.getInsets().top)){
          //The pixel is inside the lasso. Change its
          // color.
          Pixel pixel = display.getPixel(col,row);
          pixel.setRed(0);
        }//end if

      }//end inner loop
    }//end outer loop
    display.repaint();
  }//end processCirclePixels
  //----------------------------------------------------//

  /*
  This method is called each time the mouse fires a
  mouseDragged event if the radio button labeled
  Rect/Ellipse is selected.

  This version of the method draws a lasso consisting of a
  rectangle with an inscribed ellipse. A corner of the
  rectangle touches the anchor point at all times.

  The dimensions of the rectangle are determined by the
  distance of the mouse from the anchor point. That
  distance is the diagonal length of the rectangle.

  The location of the rectangle is determined by the angle
  that a line going through the anchor point and the mouse
  pointer location makes with a horizontal line going
  through the anchor point.

  The rectangle can be drawn in any quadrant, and with any
  size, even if the mouse goes outside the bounds of the
  image.

  Pixels contained in the rectangle and pixels contained
  in the inscribed ellipse can be process separately or in
  combination.

  The rectangle remains on the screen until the user
  clicks the image with the mouse, clicks the
  Process Pixels button, or does somethin else to cause
  the image to be repainted.
  */
  private void makeRectLasso(int x,int y){

    //The parameters x and y contain the coordinates of
    // the mouse pointer when the event was fired. Update
    // the width and height of the rectangular lasso.
    deltaX = x - anchorX;
    deltaY = y - anchorY;

    //Copy the entire image from the backup picture stored
    // in memory to erase any lassos drawn earlier. This
    // also erases the effects of earlier clicks on the
    // Process Pixels button.
    g2.drawImage(theImage,
                 theFrame.getInsets().left,
                 theFrame.getInsets().top,null);

    //Get the angle in radians that a line joining the
    // anchor point and the current mouse location makes
    // with a horizontal line going through the anchor
    // point. This is the angle that will be used in the
    // computations required to draw the rectangle in the
    // correct quadrant.
    angle = Math.atan2((double)deltaY,(double)deltaX);

    //Create and draw a rectangle such that one of its
    // corners touches the anchor point at all times.
    if((angle >= 0) && (angle < pi/2)){
      //Create the rectangle in the lower-right quadrant.
      rectangle = new Rectangle2D.Double(
          //Compute and specify the coordinates of the
          // upper-left corner of the rectangle.
          anchorX,
          anchorY,
          //Specify the width and the height of the
          // rectangle.
          deltaX,
          deltaY);
      //Now inscribe an ellipse in the rectangle.
      ellipse = new Ellipse2D.Double(anchorX,
                                     anchorY,
                                     deltaX,
                                     deltaY);
    }else if((angle >= pi/2) && (angle < pi)){
      //Create the rectangle in the lower-left quadrant.
      rectangle = new Rectangle2D.Double(anchorX + deltaX,
                                         anchorY,
                                         -deltaX,
                                         deltaY);
      ellipse = new Ellipse2D.Double(anchorX + deltaX,
                                     anchorY,
                                     -deltaX,
                                     deltaY);
    }else if((angle >= -pi/2) && (angle < 0)){
      //Create the rectangle in the upper-right quadrant.
      rectangle = new Rectangle2D.Double(anchorX,
                                         anchorY + deltaY,
                                         deltaX,
                                         -deltaY);
      ellipse = new Ellipse2D.Double(anchorX,
                                     anchorY + deltaY,
                                     deltaX,
                                     -deltaY);
    }else{
      //Create the rectangle in the upper-left quadrant.
      rectangle = new Rectangle2D.Double(anchorX + deltaX,
                                         anchorY + deltaY,
                                         -deltaX,
                                         -deltaY);
      ellipse = new Ellipse2D.Double(anchorX + deltaX,
                                     anchorY + deltaY,
                                     -deltaX,
                                     -deltaY);
    }//end else

    //Draw the rectangle and the ellipse.
    g2.draw(rectangle);
    g2.draw(ellipse);
  }//end makeRectLasso
  //----------------------------------------------------//

  //This is a demo method that shows how to process pixels
  // contained in a rectangular lasso and an elliptical
  // lasso. You can modify this method to meet your own
  // needs.
  //This demo method eliminates red from all pixels inside
  // the rectangle but outside the ellipse. It eliminates
  // green from all pixels inside the ellipse.
  private void processRectPixels(){
    //Protect against clicking the button before drawing
    // a lasso.
    if(rectangle == null)return;

    for(int col = 0;col < pictureWidth;col++){
      for(int row = 0;row < pictureHeight;row++){

        //Change the color of the pixels inside the
        // rectangle and outside the ellipse.
        //Note: It is necessary to compensate for the top
        // and left insets of the JFrame.
        if((rectangle.contains(
                       col + theFrame.getInsets().left,
                       row + theFrame.getInsets().top)) &&
           !((ellipse.contains(
                       col + theFrame.getInsets().left,
                       row + theFrame.getInsets().top)))){
          pixel = display.getPixel(col,row);
          pixel.setRed(0);
        }//end if

        //Change the color of the pixels inside the
        // ellipse.
        if(ellipse.contains(
                         col + theFrame.getInsets().left,
                         row + theFrame.getInsets().top)){
          Pixel pixel = display.getPixel(col,row);
          pixel.setGreen(0);
        }//end if

      }//end inner loop
    }//end outer loop
    display.repaint();
  }//end processRectPixels
  //----------------------------------------------------//
}//end class Lasso02



//34567890123456789012345678901234567890123456789012345678


