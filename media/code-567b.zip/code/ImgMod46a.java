//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//
//Published in Java456.htm

/*File ImgMod46a.java

Copyright 2006, R.G.Baldwin

The purpose of this program is to scramble an image using 
a random number generator and to write the scrambled image 
into an output png file named junk.png.  The random seed 
value and the name of the image file are specified by the 
user on the command line.  The program defaults to a fixed 
seed value and to an image file named imgmod46test.jpg if
the user fails to specify both the seed value and the image
file name on the command line.

A png file is used as the output file because it is 
necessary to avoid lossy compression in the output file.
For example, if the output file were a JPEG file, which is
a lossy compression scheme, it would not be possible to
unscramble the image later.

Usage:  Enter the following at the command-line:

java ImgMod46a RandomSeedValue ImageFileName

The first parameter is a long value that is used to seed
the random number generator.  The same seed value must
be used to scramble and to unscramble the image.  The seed 
is a long integer, which may range from 
-9223372036854775808 to 9223372036854775807

Can read jpg, gif, and png image files, and possibly some 
other file types as well.  Note, however, that because of
the relatively small number of actual colors in a gif
image, scrambling a gif image often results in a scrambled
image in which the shapes of the items in the image can
be easily seen.

Use the program named ImgMod46b to read the png file 
produced by this program and to unscramble the image that
it contains.  The program named ImgMod46b writes the
unscrambled image into a a JPEG output file named junk.jpg.

The program named ImgMod47 can be used to display the
scrambled image along with the unscrambled image for
comparison purposes.

Tested using J2SE 5.0 under WinXP.  A batch file containing
the following commands was used to test this program and
its companion programs named ImgMod46b and ImgMod47:

echo off
echo Usage: enter ImgMod46 followed by a space 
echo and the name of the image file.
java ImgMod46a -9223372036854775808 %1
java ImgMod46b -9223372036854775808
java ImgMod47 junk.png junk.jpg
**********************************************************/

import java.awt.*;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;
import java.util.Random;
import java.util.ArrayList;

class ImgMod46a{
  BufferedImage rawBufferedImage;
  BufferedImage processedImage;
  static String defaultImgFile = "imgmod46test.jpg";
  static String theImgFile = null;//Input image file
  static long defaultSeed = 1234567890;//Default seed
  static long seed;
  MediaTracker tracker;

  //-----------------------------------------------------//

  public static void main(String[] args){

    //Get the seed and the input image file name from the
    // command line, or use the default seed and image
    // file name instead.
    if(args.length == 2){
      //Get the seed value.
      seed = Long.parseLong(args[0]);
      //Get the input file name
      theImgFile = args[1];
    }else{
      seed = defaultSeed;
      theImgFile = defaultImgFile;
    }//end else
    
    System.out.println("Scrambling Key: " + seed);

    //Instantiate an object of this class.
    ImgMod46a obj = new ImgMod46a();
  }//end main
  //-------------------------------------------//

  public ImgMod46a(){//constructor
    //Get an image from the specified image file.
    rawBufferedImage = getTheImage();

    //Process the image.
    processedImage = processImg(rawBufferedImage);
    
    //Write the modified image into a file named
    // junk.png.
    writeOutputFile(processedImage);

  }//end ImgMod46a constructor
  //=====================================================//

  //Use the LookupOp class from the Java 2D API to
  // scramble all of the color values in the pixels.  The
  // alpha value is not modified.
  public BufferedImage processImg(BufferedImage theImage){

    //Create three ArrayList objects, each containing 256
    // unique unsigned 8-bit values.  It is required that
    // the same seed value be used to scramble the image
    // and to unscramble the image.
    Random randomGenerator = new Random(seed);
    ArrayList <Short>redList = new ArrayList<Short>(256);
    ArrayList <Short>greenList = new ArrayList<Short>(256);
    ArrayList <Short>blueList = new ArrayList<Short>(256);
    
    for(int cnt = 0;cnt < 256;cnt++){
      //Get a priming value for the redList.
      short value = 
                 (short)(randomGenerator.nextInt() & 0xFF);
      while(redList.contains(value)){
        //Try another value.  This one was already used.
        value = (short)(randomGenerator.nextInt() & 0xFF);
      }//end while
      redList.add(value);//Add unique value to the list.
      
      //Get a priming value for the greenList.
      value = (short)(randomGenerator.nextInt() & 0xFF);
      while(greenList.contains(value)){
        //Try another value.  This one was already used.
        value = (short)(randomGenerator.nextInt() & 0xFF);
      }//end while
      greenList.add(value);//Add unique value to the list.
      
      //Get a priming value for the blueList.
      value = (short)(randomGenerator.nextInt() & 0xFF);
      while(blueList.contains(value)){
        //Try another value.  This one was already used.
        value = (short)(randomGenerator.nextInt() & 0xFF);
      }//end while
      blueList.add(value);//Add unique value to the list.
      
    }//end for loop
    
    //Create the data for the lookup table.
    short[] red = new short[256];
    short[] green = new short[256];
    short[] blue = new short[256];
    
    for (int cnt = 0; cnt < 256; cnt++){
      red[cnt] = redList.get(cnt);
      green[cnt] = greenList.get(cnt);
      blue[cnt] = blueList.get(cnt);
    }//end for loop

    //Create the 2D array that will be used to create the
    // lookup table.
    short[][] lookupData = new short[][]{red,green,blue};
    
    //Create the lookup table
    ShortLookupTable lookupTable = 
                        new ShortLookupTable(0,lookupData);

    //Create the filter object.
    BufferedImageOp filterObj = 
                            new LookupOp(lookupTable,null);

    //Apply the filter to the incoming image and return
    // a reference to the resulting BufferedImage object.
    return filterObj.filter(theImage, null);

  }//end processImg
  //=====================================================//

  //Write the contents of a BufferedImage object to a 
  // file named junk.png.
  void writeOutputFile(BufferedImage img){
    try{
      //Get a file output stream.
      FileOutputStream outStream = 
                          new FileOutputStream("junk.png");
      //Call the write method of the ImageIO class to write
      // the contents of the BufferedImage object to an
      // output file in png format.
      ImageIO.write(img,"png",outStream);
      outStream.close();
    }catch (Exception e) {
      e.printStackTrace();
    }//end catch
  }//end writeOutputFile
  //-----------------------------------------------------//
  
  //This method reads an image from a specified image file,
  // writes it into a BufferedImage object, and returns a
  // reference to the BufferedImage object.
  //The name of the image file is contained in an instance
  // variable of type String named theImgFile.
  BufferedImage getTheImage(){
    Image rawImage = Toolkit.getDefaultToolkit().
                                      getImage(theImgFile);

    //Use a MediaTracker object to block until the image is
    // loaded or ten seconds has elapsed.  Terminate and
    // display an error message if ten seconds elapse
    // without the image having been loaded.  Note that the
    // constructor for the MediaTracker requires the
    // specification of a Component "on which the images
    // will eventually be drawn" even if there is no
    // intention for the program to actually display the 
    // image.  It is useful to have a media tracker with a
    // timeout even if the image won't be drawn by the
    // program.  Also, the media tracker is needed to delay
    // execution until the image is fully loaded.
    tracker = new MediaTracker(new Frame());
    tracker.addImage(rawImage,1);

    try{
      if(!tracker.waitForID(1,10000)){
        System.out.println("Timeout or Load error.");
        System.exit(1);
      }//end if
    }catch(InterruptedException e){
      e.printStackTrace();
      System.exit(1);
    }//end catch

    //Make certain that the file was successfully loaded.
    if((tracker.statusAll(false)
                             & MediaTracker.ERRORED
                             & MediaTracker.ABORTED) != 0){
      System.out.println("Load errored or aborted");
      System.exit(1);
    }//end if

    //Create an empty BufferedImage object.  Note that the
    // specified image type is critical to the correct
    // operation of the image processing method. The method
    // may work correctly for other image types, but has
    // been been tested only for TYPE_INT_RGB.  The
    // parameters to the getWidth and getHeight methods are
    // references to ImageObserver objects, or references
    // to "an object waiting for the image to be loaded."

    BufferedImage buffImage = new BufferedImage(
                              rawImage.getWidth(null),
                              rawImage.getHeight(null),
                              BufferedImage.TYPE_INT_RGB);

    // Draw Image into BufferedImage
    Graphics g = buffImage.getGraphics();
    g.drawImage(rawImage, 0, 0, null);

    return buffImage;
  }//end getTheImage
  //-----------------------------------------------------//
}//end ImgMod46a.java class
//=======================================================//
