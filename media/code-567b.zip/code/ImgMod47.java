//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//
//Published in Java456.htm

/*File ImgMod47.java
Copyright 2006, R.G.Baldwin

This program reads and displays two image files, one above 
the other for comparison purposes.  The images do not have
to be the same size or the same type.

The program will read gif, jpg, and png files and possibly 
some other input file types as well.

Typical usage is as follows:

java ImgMod47 TopImageFileName BottomImageFileName

If the command-line parameters are omitted, the program 
will search for an image file in the current directory 
named ImgMod47Test.jpg and will display it in both the
top and bottom display locations.  This file must be 
provided in the current directory if it will be needed.

The image files must be provided by the user in all cases.
However, they don't have to be in the current directory if
a path to the files is specified on the command line.

The two images are displayed in a frame with one above the 
other.  The program attempts to set the size of the display
so as to accommodate both images.  If both images are not 
totally visible, the user can manually resize the display 
frame.

If the program is unable to load either image file within 
ten seconds, it will abort with an error message.

Tested using J2SE5.0 under WinXP.  Requires J2SE 5.0 or 
later version due to the use of generics.
**********************************************************/

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

class ImgMod47 extends Frame{
  //References to top and bottom images.
  BufferedImage topImage;
  BufferedImage bottomImage;
  
  Frame displayFrame;//Frame to display the images.
  int inLeft;//left inset
  int inTop;//top inset
  int inBottom;//bottom inset

  //This is the name of the default image file.  This image
  // file will be displayed in both the top and bottom 
  // locations if the user fails to enter two command-line 
  // parameters.  You must provide this file in the current
  // directory if it will be needed.
  static String topFile = "ImgMod47Test.jpg";
  static String bottomFile = "ImgMod47Test.jpg";

  MediaTracker tracker;
  Display display = new Display();//A Canvas object
  //-----------------------------------------------------//

  public static void main(String[] args){
    //Get input file names.  Program reads gif, png, and
    // jpg files and possibly some other file types as
    // well.
    if(args.length == 0){
      //Use default image file specified above.
    }else if(args.length == 2){
      topFile = args[0];
      bottomFile = args[1];
    }else{
      System.out.println("Invalid args");
      System.exit(1);
    }//end else

    //Display names of top and bottom image files.
    System.out.println("Top File: " + topFile);
    System.out.println("Bottom File: " + bottomFile);

    //Instantiate an object of this class.
    ImgMod47 obj = new ImgMod47();
  }//end main
  //-------------------------------------------//

  public ImgMod47(){//constructor
    //Get the top image from the specified image file.  Can
    // be in a different directory if the path was entered
    // with the file name on the  command line.
    topImage = getTheImage(topFile);
    
    //Get the bottom image from the specified image file.
    bottomImage = getTheImage(bottomFile);
  
    //Construct the display object.
    this.setTitle("Copyright 2006, Baldwin");
    this.setBackground(Color.YELLOW);
    this.add(display);
    
    //Make the frame visible so as to make it possible to
    // get insets.
    setVisible(true);
    //Get and store inset data for the Frame.
    inTop = this.getInsets().top;
    inLeft = this.getInsets().left;
    inBottom = this.getInsets().bottom;
    setVisible(false);
    
    //Save a reference to this Frame object for use in
    // setting the size of the Frame later.
    displayFrame = this;

    //Set the display size to accommodate the top and
    // bottom images. Set the size such that  a tiny amount
    // of the background color shows between the two
    // images, to the right of the larger image, and below
    // the bottom image.
    int maxWidth = 0;
    //Get max image width.
    if(bottomImage.getWidth() > topImage.getWidth()){
      maxWidth = bottomImage.getWidth();
    }else{
      maxWidth = topImage.getWidth();
    }//end else
    int totalWidth = 2*inLeft + maxWidth + 2;

    //Get height of two images.
    int height = topImage.getHeight() 
                                 + bottomImage.getHeight();
    int totalHeight = inTop + inBottom + height + 4;
    displayFrame.setSize(totalWidth,totalHeight);
    
    //Repaint the image display frame.
    display.repaint();

    //Cause the composite of the frame and the canvas to
    // become visible.
    this.setVisible(true);

    //===================================================//

    //Anonymous inner class listener to terminate
    // program.
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //===================================================//

  }//end ImgMod47 constructor
  //=====================================================//

  //Inner class for canvas object on which to display the
  // two images.
  class Display extends Canvas{
    //Override the paint method to display two images on
    // the same Canvas object, separated by a couple of
    // rows of pixels in the background color.
    public void paint(Graphics g){
      //First confirm that the image has been completely
      // loaded and that none of the image references are
      // null.
      if (tracker.statusID(1,false) ==
                                    MediaTracker.COMPLETE){
        if((topImage != null) && (bottomImage != null)){
            
          //Draw the top image.  Terminate if the pixels
          // are changing.
          boolean success = false;
          success = g.drawImage(topImage,0,0,this);
          if(!success){
            System.out.println("Unable to draw top image");
            System.exit(1);
          }//end if
          
          //Draw the bottom image.
          success = g.drawImage(bottomImage,0,
                            topImage.getHeight() + 2,this);
          if(!success){
            System.out.println(
                            "Unable to draw bottom image");
            System.exit(1);
          }//end if
        }//end if
      }//end if
    }//end paint()
  }//end class myCanvas
  //=====================================================//
  
  //This method reads an image from a specified image file,
  // writes it into a BufferedImage object, and returns a
  // reference to the BufferedImage object.
  //The name of the image file is received as an incoming
  // parameter.
  BufferedImage getTheImage(String fileName){
    Image rawImage = Toolkit.getDefaultToolkit().
                                        getImage(fileName);

    //Use a MediaTracker object to block until the image is
    // loaded or ten seconds has elapsed.  Terminate and
    // display an error message if ten seconds elapse
    // without the image having been loaded.
    tracker = new MediaTracker(this);
    tracker.addImage(rawImage,1);

    try{
      if(!tracker.waitForID(1,10000)){
        System.out.println("Load error.");
        System.exit(1);
      }//end if
    }catch(InterruptedException e){
      e.printStackTrace();
      System.exit(1);
    }//end catch

    //Make certain that the file was successfully loaded.
    if((tracker.statusAll(false)
                             & MediaTracker.ERRORED
                             & MediaTracker.ABORTED) != 0){
      System.out.println("Load errored or aborted");
      System.exit(1);
    }//end if

    //Create an empty BufferedImage object.  This program
    // may work correctly for other image types, but has
    // been tested only for TYPE_INT_RGB.
    BufferedImage buffImage = new BufferedImage(
                              rawImage.getWidth(this),
                              rawImage.getHeight(this),
                              BufferedImage.TYPE_INT_RGB);

    // Draw Image into BufferedImage
    Graphics g = buffImage.getGraphics();
    g.drawImage(rawImage, 0, 0, null);

    return buffImage;
  }//end getTheImage
  //-----------------------------------------------------//
}//end ImgMod47.java class
//=======================================================//





