//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//
//Published in Java456.htm

/*File ImgMod46b.java
Copyright 2006, R.G.Baldwin

See comments in the companion program named ImgMod46a.

The purpose of this program is to unscramble the image in 
a png file that was scrambled and written by the program 
named ImgMod46a, and to write the unscrambled image into an
output JPEG file.

This program reads a scrambled image from a file named 
junk.png, unscrambles the image, and writes the unscrambled
image into an output JPEG file named junk.jpg.

The program named ImgMod47 can be used to display the
scrambled image along with the unscrambled image for
comparison purposes.

A random seed value is required to unscramble the image.
The same seed value must be used to unscramble the image
as was used to scramble the image.  The seed value is 
specified by the user on the command line.  The program 
defaults to the same fixed seed value as the default seed 
value used in the program named ImgMod46a if the user fails
to specify the seed value on the command line.

Usage:  Enter the following at the command-line:

java ImgMod46b RandomSeedValue

The parameter is a long integer that is used to seed the 
random number generator.  The same seed value must be used
to unscramble the image as was used by the program named 
ImgMod46a to scramble the image.  As a long integer, the
value of the seed may range from -9223372036854775808 
to 9223372036854775807

Tested using J2SE 5.0 under WinXP.  A batch file containing
the following commands was used to test this program and
its companion programs named ImgMod46a and ImgMod47:

echo off
echo Usage: enter ImgMod46 followed by a space 
echo and the name of the image file.
java ImgMod46a -9223372036854775808 %1
java ImgMod46b -9223372036854775808
java ImgMod47 junk.png junk.jpg
**********************************************************/

import java.awt.*;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;
import java.util.Random;
import java.util.ArrayList;

class ImgMod46b{
  BufferedImage rawBufferedImage;
  BufferedImage processedImage;
  static String theImgFile = "junk.png";
  static long defaultSeed = 1234567890;//Default seed
  static long seed;
  MediaTracker tracker;

  //-----------------------------------------------------//

  public static void main(String[] args){
    //Get the seed value from the command line, or use the
    // default seed value instead.
    if(args.length == 1){
      //Get the seed value.
      seed = Long.parseLong(args[0]);
    }else{
      seed = defaultSeed;
    }//end else
    
    System.out.println("Unscrambling Key: " + seed);
    
    //Instantiate an object of this class.
    ImgMod46b obj = new ImgMod46b();
  }//end main
  //-------------------------------------------//

  public ImgMod46b(){//constructor
    //Get an image from the specified image file.
    rawBufferedImage = getTheImage();

    //Process the image.
    processedImage = processImg(rawBufferedImage);
    
    //Write the modified image into a file named
    // junk.jpg.
    writeOutputFile(processedImage);

  }//end ImgMod46b constructor
  //=====================================================//

  //Use the LookupOp class from the Java 2D API to
  // unscramble the color values in the pixels.  The
  // alpha value is not modified.
  public BufferedImage processImg(BufferedImage theImage){

    //Create three ArrayList objects, each containing 256
    // unique unsigned 8-bit values.  It is required that
    // the same seed value be used to unscramble the image
    // as was originally used to scramble the image.
    Random randomGenerator = new Random(seed);
    ArrayList <Short>redList = new ArrayList<Short>(256);
    ArrayList <Short>greenList = new ArrayList<Short>(256);
    ArrayList <Short>blueList = new ArrayList<Short>(256);
    
    for(int cnt = 0;cnt < 256;cnt++){
      //Get a priming value for the red list.
      short value = 
                 (short)(randomGenerator.nextInt() & 0xFF);
      while(redList.contains(value)){
        //This value was used earlier. Try another value.
        value = (short)(randomGenerator.nextInt() & 0xFF);
      }//end while
      redList.add(value);//Add unique value to the list.
      
      //Get a priming value for the green list.
      value = (short)(randomGenerator.nextInt() & 0xFF);
      while(greenList.contains(value)){
        //Try another value
        value = (short)(randomGenerator.nextInt() & 0xFF);
      }//end while
      greenList.add(value);//Add unique value to the list.
      
      //Get a priming value for the blue list.
      value = (short)(randomGenerator.nextInt() & 0xFF);
      while(blueList.contains(value)){
        //Try another value
        value = (short)(randomGenerator.nextInt() & 0xFF);
      }//end while
      blueList.add(value);//Add unique value to the list.
      
    }//end for loop
    
    //Create the data for the lookup table.
    short[] red = new short[256];
    short[] green = new short[256];
    short[] blue = new short[256];
    for (int cnt = 0; cnt < 256; cnt++){
      red[cnt] = 
           (short)(redList.indexOf(new Short((short)cnt)));
      green[cnt] = 
         (short)(greenList.indexOf(new Short((short)cnt)));
      blue[cnt] = 
          (short)(blueList.indexOf(new Short((short)cnt)));
    }//end for loop

    //Create the 2D array that will be used to create the
    // lookup table.
    short[][] lookupData = new short[][]{red,green,blue};
    
    //Create the lookup table
    ShortLookupTable lookupTable = 
                        new ShortLookupTable(0,lookupData);

    //Create the filter object.
    BufferedImageOp filterObj = 
                            new LookupOp(lookupTable,null);

    //Apply the filter to the incoming image and return
    // a reference to the resulting BufferedImage object.
    return filterObj.filter(theImage, null);

  }//end processImg
  //=====================================================//

  //Write the contents of a BufferedImage object to a 
  // file named junk.jpg.
  void writeOutputFile(BufferedImage img){
    try{
      //Get a file output stream.
      FileOutputStream outStream = 
                          new FileOutputStream("junk.jpg");
      //Call the write method of the ImageIO class to write
      // the contents of the BufferedImage object to an
      // output file in jpg format.
      ImageIO.write(img,"jpeg",outStream);
      outStream.close();
    }catch (Exception e) {
      e.printStackTrace();
    }//end catch
  }//end writeOutputFile
  //-----------------------------------------------------//
  
  //This method reads an image from a specified image file,
  // writes it into a BufferedImage object, and returns a
  // reference to the BufferedImage object.
  //The name of the image file is contained in an instance
  // variable of type String named theImgFile.
  BufferedImage getTheImage(){
    Image rawImage = Toolkit.getDefaultToolkit().
                                      getImage(theImgFile);

    //Use a MediaTracker object to block until the image is
    // loaded or ten seconds has elapsed.  Terminate and
    // display an error message if ten seconds elapse
    // without the image having been loaded.  Note that the
    // constructor for the MediaTracker requires the
    // specification of a Component "on which the images
    // will eventually be drawn" even if there is no
    // intention for the program to actually display the 
    // image.  It is useful to have a media tracker with a
    // timeout even if the image won't be drawn by the
    // program.  Also, the media tracker is needed to delay
    // execution until the image is fully loaded.
    tracker = new MediaTracker(new Frame());
    tracker.addImage(rawImage,1);

    try{
      if(!tracker.waitForID(1,10000)){
        System.out.println("Timeout or Load error.");
        System.exit(1);
      }//end if
    }catch(InterruptedException e){
      e.printStackTrace();
      System.exit(1);
    }//end catch

    //Make certain that the file was successfully loaded.
    if((tracker.statusAll(false)
                             & MediaTracker.ERRORED
                             & MediaTracker.ABORTED) != 0){
      System.out.println("Load errored or aborted");
      System.exit(1);
    }//end if

    //Create an empty BufferedImage object.  Note that the
    // specified image type is critical to the correct
    // operation of the image processing method. The method
    // may work correctly for other image types, but has
    // been been tested only for TYPE_INT_RGB.  The
    // parameters to the getWidth and getHeight methods are
    // references to ImageObserver objects, or references
    // to "an object waiting for the image to be loaded."

    BufferedImage buffImage = new BufferedImage(
                              rawImage.getWidth(null),
                              rawImage.getHeight(null),
                              BufferedImage.TYPE_INT_RGB);

    // Draw Image into BufferedImage
    Graphics g = buffImage.getGraphics();
    g.drawImage(rawImage, 0, 0, null);

    return buffImage;
  }//end getTheImage
  //-----------------------------------------------------//
}//end ImgMod46b.java class
//=======================================================//
