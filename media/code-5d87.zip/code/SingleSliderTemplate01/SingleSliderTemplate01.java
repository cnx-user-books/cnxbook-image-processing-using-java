//34567890123456789012345678901234567890123456789012345678
//Ready for publication, 1/8/09.


/*File SingleSliderTemplate01 Copyright 2009 R.G.Baldwin

This is a template program, designed to show you how to
structure a program in which some attribute of a digital
image is varied through a range of values using a slider.

The main purpose of this template program is to make it
possible for you to write image processing programs with a
minimum of effort. Ideally, by using this template, you
will be able to concentrate on the image-processing logic
and not have to deal with the logistics involved in
the overall program.

The template program requires access to Ericson's
multimedia library.

The speed and smoothness of programs that you write using
this template program will depend on a combination of your
programming skills and the speed of your computer. This
template program is intended to teach programming and
image processing concepts. It is not intended to make it
possible for you to write programs that will compete on a
speed basis with commercially-available photograph
processing programs.

The screen output produced by the template program
consists of two parts: a display of the picture being
processed and a GUI.

The GUI consists of the following components:
~A JLabel object that briefly describes the purpose of the
slider.
~The slider itself.
~A JButton that can be used to write backup copies of the
current state of the display into the same directory from
which the original image file was read. The five most
recent backup files are saved. The backup files are
written in bmp format regardless of the format of the
original image file in order to avoid the color corruption
that can occur when images are compressed into JPEG
format. The names of the backup files are the same as the
name of the original image file except that BAKn is
inserted immediately ahead of the extension where n is a
digit ranging from 0 to 4. The value of n rolls over and
starts back at 0 when it exceeds 4.
~A JTextField into which the user enters the name of the
input file. Files of type jpg, bmp, png are supported.
Other file types may be supported as well but the program
hasn't been tested for types other than those listed
above.

The GUI originally appears in the upper-left corner of the
screen. At this point, both the slider and the button are
disabled. When the user enters the name of the input file,
a display of the image contained in that file appears in
the upper-left corner of the screen and the GUI is
relocated to a position immediately below the display. If
the input file is not in the current directory, a complete
path and file name must be entered by the user.

When the GUI is relocated to the position immediately
below the display, the slider and the button are enabled
and the text field is disabled. The width of the GUI is
changed to match the width of the display unless the width
of the display is less than the preferred width of the
GUI. In that case, the GUI appears at its preferred width.

For this demonstration template program, the slider ranges
from 0 to 100 with the initial position of the slider at
100. As the slider is moved toward zero, the value of the
red color component for every pixel in the image is
reduced linearly and the display changes to reflect that
change in the value of the red color component. The
smoothness, or lack thereof of the operation will depend
on the speed of the computer. When the slider is at the 0
position, the pixels in the image are completely devoid of
red color.

Positioning the slider at some point along its range and
clicking the Write button causes a backup file to be
written containing the current state of the display.

Clicking the large X in the upper-right corner of the
display simply hides the display and is of no practical
value.

The program is terminated by clicking the large X in the
upper-right corner of the GUI. Before terminating, the
program writes an output file containing the final state
of the display in the same format as the input file. The
name of the output file is the same as the name of the
original input file except that the word FINAL is inserted
immediately ahead of the extension.

This program does not modify the contents of the original
input file.

A change listener is registered on the slider. Each time
the slider fires a ChangeEvent, the event handler creates
a new display as a copy of the original picture and calls
a method named processThePicture.

The main purpose of this template program is to make it
possible for you to write image processing programs with a
minimum of effort. For many different kinds of image
processing programs, you should be able to confine your
programming effort to rewriting the method named
processThePicture (and change the text in the JLabel
referred to by purposeLabel) and leave the remainder of
the template program intact.

Tested using Windows Vista Home Premium Edition,
Java 1.6x, and the version of Ericson's multimedia library
contained in bookClasses10-1-07.zip.
*********************************************************/

import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.WindowConstants;

import java.io.File;

public class SingleSliderTemplate01 extends JFrame{
  private JPanel mainPanel = new JPanel();
  private JPanel southPanel = new JPanel();

  private JLabel purposeLabel =
                new JLabel("Purpose of Slider goes Here");
  private JButton writeButton = new JButton("Write");
  private JTextField fileNameField =
             new JTextField("SingleSliderTemplate01.jpg");
  //This slider will extend from 0 to 100 with the initial
  // position at 100. See the documentation to learn how
  // to configure it differently.
  private JSlider slider = new JSlider(0,100,100);

  //A reference to the original Picture object will be
  // stored here.
  private Picture picture = null;
  //A reference to a modified copy of the original
  // Picture object will be stored here.
  private Picture display = null;

  //Miscellaneous working variables.
  private Image image = null;
  private Graphics graphics = null;

  private Pixel pixel = null;
  private int red = 0;
  private int writeCounter = 0;

  private Pixel[] pixels = null;

  private String fileName = "NONE";
  private String outputPath = null;
  private String extension = null;
  //----------------------------------------------------//

  public static void main(String[] args){
    new SingleSliderTemplate01();
  }//end main method
  //----------------------------------------------------//

  public SingleSliderTemplate01(){//constructor

    //All close operations are handled in a WindowListener
    // object.
    setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

    //Put the decorations on the slider. See the
    // documentation to learn how to decorate the slider
    // differently.
    slider.setMajorTickSpacing(10);
    slider.setMinorTickSpacing(5);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);

    //Construct the GUI.
    mainPanel.setLayout(new BorderLayout());

    mainPanel.add(purposeLabel,BorderLayout.NORTH);
    mainPanel.add(slider,BorderLayout.CENTER);

    southPanel.add(writeButton);
    southPanel.add(new JLabel("File Name:"));
    southPanel.add(fileNameField);
    mainPanel.add(southPanel,BorderLayout.SOUTH);

    //Disable the slider and the writeButton until the
    // user enters the file name. Put the focus on the
    // text field where the user will enter the file
    // name.
    slider.setEnabled(false);
    writeButton.setEnabled(false);
    fileNameField.requestFocus();

    //Set the size of the GUI and display it in the upper-
    // left corner of the screen. It will be moved later
    // to a position immediately below the display of the
    // picture.
    getContentPane().add(mainPanel);
    pack();
    setVisible(true);
    //--------------------------------------------------//

    //Register a listener on the text field. When the user
    // enters the file name in the text field, set
    // everything up properly so that the program will
    // function as an event-driven picture-manipulation
    // program until the user clicks the large X in the
    // upper-right of the GUI.
    fileNameField.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Disable the text field to prevent the user
          // from entering anything else in it.
          fileNameField.setEnabled(false);

          //Get the file name from the text field and use
          // it to create a new Picture object. Display my
          // name in the image.
          fileName = fileNameField.getText();
          picture = new Picture(fileName);
          picture.addMessage("Dick Baldwin",10,20);

          //Get information that will be used to write the
          // output files.
          String inputPath = new File(fileName).
                                        getAbsolutePath();
          int posDot = inputPath.lastIndexOf('.');
          outputPath = inputPath.substring(0,posDot);
          //Write the first copy of the output backup
          // file.
          picture.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");

          //Get filename extension. It will be used later
          // to write the final output file.
          extension = inputPath.substring(posDot);

          //Decorate the GUI.
          setTitle("Copyright 2009, R.G.Baldwin");

          //Create the picture that will be processed.
          // Note that the original image file is not
          // modified by this program.
          int pictureWidth = picture.getWidth();
          int pictureHeight = picture.getHeight();
          display = new Picture(
                              pictureWidth,pictureHeight);

          //Draw the initial display.
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          display.show();

          //Adjust the width of the GUI to match the width
          // of the display if possible. Then relocate the
          // GUI to a position immediately below the
          // display.
          //Establish the preferred size now that the
          // input file name has been entered.
          pack();
          int packedHeight = getHeight();
          int packedWidth = getWidth();
          if((pictureWidth + 7) >= packedWidth){
            //Make the width of the GUI the same as the
            // width of the display.
            setSize(pictureWidth + 7,packedHeight);
          }//Else, just leave the GUI at its current size.
          //Put the GUI in its new location immediately
          // below the display.
          setLocation(0,pictureHeight + 30);

          //Enable the user input controls.
          slider.setEnabled(true);
          writeButton.setEnabled(true);

        }//end actionPerformed
      }//end new ActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register an ActionListener on the writeButton.
    // Each time the user clicks the button, a backup bmp
    // file containing the current state of the display is
    // written into the directory from which the original
    // picture was read. The five most recent backup files
    // are saved. The names of the backup files are the
    // same as the name of the input file except that BAKn
    // is inserted immediately ahead of the extension
    // where n is a digit ranging from 0 to 4. The value
    // of n rolls over at 4 and starts back at 0.
    writeButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          display.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");
          //Reset the writeCounter if it exceeds 4 to
          // conserve disk space.
          if(writeCounter > 4){
            writeCounter = 0;
          }//end if
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register a WindowListener that will respond when the
    // user clicks the large X in the upper-right corner
    // of the GUI. This event handler will write the final
    // state of the display into an output file of the
    // same type as the original input file. The name will
    // be the same except that the word FINAL will be
    // inserted immediately ahead of the extension.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          display.write(outputPath + "FINAL" + extension);
          System.exit(0);
        }//end windowClosing
      }//end new WindowAdapter
    );//end addWindowListener
    //--------------------------------------------------//
    //Register a ChangeListener object on the slider.
    //Each time the slider fires a ChangeEvent, this event
    // handler creates a new display as a copy of the
    // original picture and calls a method named
    // processThePicture.
    slider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          //Draw a new copy of the picture on the display.
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          processThePicture();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//

  }//end constructor
  //----------------------------------------------------//

  //This version of the method named processThePicture is
  // designed for illustration purposes only. The method
  // is called each time the slider fires a stateChanged
  // event.
  //Immediately before this method is called, a new
  // display is created as a copy of the original picture.
  // This method operates only on the display. Each time
  // the method is called, it gets the value of the
  // slider and uses that value as a multiplicative factor
  // to reduce the red color component value in every
  // pixel in the current display. Thus, depending on the
  // position of the slider when the event is fired, the
  // red color component value for every pixel in the
  // current display will be set to a value ranging from
  // zero to 100 percent of its original value. Methods
  // that are written for this part of the program should
  // never access the original Picture object directly,
  // but should confine their operations to the Picture
  // object referred to by the variable named display.

  private void processThePicture(){
    //Adjust the value of the red color component on the
    // basis of the current value of the slider.
    pixels = display.getPixels();
    for(int cnt = 0;cnt < pixels.length;cnt++){
      red = (int)(pixels[cnt].getRed()
                               * slider.getValue()/100.0);
      pixels[cnt].setRed(red);
    }//end for loop

    display.repaint();

  }//end processThePicture
  //----------------------------------------------------//

}//end class SingleSliderTemplate01



//34567890123456789012345678901234567890123456789012345678


