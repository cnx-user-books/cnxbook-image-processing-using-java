//34567890123456789012345678901234567890123456789012345678
//01/08/09 Ready for publication.


/*File Blur02 Copyright 2009 R.G.Baldwin

This is an update to the program named Blur01 to make the
blurring algorithm more aggressive. The program named
Blur01 computes a weighted sum of a center pixel and its
eight closest neighbors. This program computes a weighted
sum of a center pixel and its 24 closest neighbors.

This program was created using the program named
SingleSliderTemplate01 as the starting point.

The purpose of this program is to teach you how to write a
slider-driven program to apply a blurring or softening
filter to your digital photos with the amount of softening
being controlled by a slider.

The  program requires access to Ericson's multimedia
library.

The speed and smoothness of programs that you write using
the template program will depend on a combination of your
programming skills and the speed of your computer. This
program was designed to emphasize an understanding of the
image blurring process and was not designed for speed.
Improving the speed would be a good project for the
student.

The screen output produced by the program consists of two
parts: a display of the picture being processed and a GUI.

See the comments at the beginning of the program named
SingleSliderTemplate01 for a detailed discussion of the
components in the GUI.

For this program, the slider ranges from 0 to 100 with the
initial position of the slider at 1.  The program applies
one of many possible blurring or softening algorithms to
an image that is read from an image file. The algorithm is
applied separately to the red, green, and blue color
components of the pixels.

A detailed description of the algorithm is provided in the
comments at the beginning of the method named
processThePicture. There is no blurring when the slider is
at the far left or 0 position.  Blurring increases non-
linearly as the slider is moved to the right. Maximum
blurring occurs when the slider is at the far right in the
100 position.

Positioning the slider at some point along its range and
clicking the Write button causes a backup file to be
written containing the current state of the display. See
the program named SingleSliderTemplate01 for information
regarding the number of sequential backup files that are
saved and the names of those files.

Clicking the large X in the upper-right corner of the
display simply hides the display and is of no practical
value.

The program is terminated by clicking the large X in the
upper-right corner of the GUI. Before terminating, the
program writes an output file containing the final state
of the display in the same format as the input file. The
name of the output file is the same as the name of the
input file except that the word FINAL is inserted
immediately ahead of the extension.

This program does not modify the contents of the original
input file.

Tested using Windows Vista Home Premium Edition,
Java 1.6x, and the version of Ericson's multimedia library
contained in bookClasses10-1-07.zip.
*********************************************************/

import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import javax.swing.WindowConstants;

import java.io.File;

public class Blur02 extends JFrame{
  private JPanel mainPanel = new JPanel();
  private JPanel southPanel = new JPanel();

  private JLabel purposeLabel =
                   new JLabel("Apply a blurring filter.");
  private JButton writeButton = new JButton("Write");
  private JTextField fileNameField =
             new JTextField("Blur02.jpg");
  //This slider will extend from 0 to 100 with the initial
  // position at 100. See the documentation to learn how
  // to configure it differently.
  private JSlider slider = new JSlider(0,100,1);

  //A reference to the original Picture object will be
  // stored here.
  private Picture picture = null;
  //A reference to a modified copy of the original
  // Picture object will be stored here.
  private Picture display = null;

  //Miscellaneous working variables.
  private Image image = null;
  private Graphics graphics = null;

  private Pixel pixel = null;
  private int red = 0;
  private int writeCounter = 0;

  private Pixel[] pixels = null;

  private String fileName = "NONE";
  private String outputPath = null;
  private String extension = null;
  //----------------------------------------------------//

  public static void main(String[] args){
    new Blur02();
  }//end main method
  //----------------------------------------------------//

  public Blur02(){//constructor

    //All close operations are handled in a WindowListener
    // object.
    setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

    //Put the decorations on the slider. See the
    // documentation to learn how to decorate the slider
    // differently.
    slider.setMajorTickSpacing(10);
    slider.setMinorTickSpacing(5);
    slider.setPaintTicks(true);
    slider.setPaintLabels(true);

    //Construct the GUI.
    mainPanel.setLayout(new BorderLayout());

    mainPanel.add(purposeLabel,BorderLayout.NORTH);
    mainPanel.add(slider,BorderLayout.CENTER);

    southPanel.add(writeButton);
    southPanel.add(new JLabel("File Name:"));
    southPanel.add(fileNameField);
    mainPanel.add(southPanel,BorderLayout.SOUTH);

    //Disable the slider and the writeButton until the
    // user enters the file name. Put the focus on the
    // text field where the user will enter the file
    // name.
    slider.setEnabled(false);
    writeButton.setEnabled(false);
    fileNameField.requestFocus();

    //Set the size of the GUI and display it in the upper-
    // left corner of the screen. It will be moved later
    // to a position immediately below the display of the
    // picture.
    getContentPane().add(mainPanel);
    pack();
    setVisible(true);
    //--------------------------------------------------//

    //Register a listener on the text field. When the user
    // enters the file name in the text field, set
    // everything up properly so that the program will
    // function as an event-driven picture-manipulation
    // program until the user clicks the large X in the
    // upper-right of the GUI.
    fileNameField.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Disable the text field to prevent the user
          // from entering anything else in it.
          fileNameField.setEnabled(false);

          //Get the file name from the text field and use
          // it to create a new Picture object. Display my
          // name in the image.
          fileName = fileNameField.getText();
          picture = new Picture(fileName);
          picture.addMessage("Dick Baldwin",10,20);

          //Get information that will be used to write the
          // output files.
          String inputPath = new File(fileName).
                                        getAbsolutePath();
          int posDot = inputPath.lastIndexOf('.');
          outputPath = inputPath.substring(0,posDot);
          //Write the first copy of the output backup
          // file.
          picture.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");

          //Get filename extension. It will be used later
          // to write the final output file.
          extension = inputPath.substring(posDot);

          //Decorate the GUI.
          setTitle("Copyright 2009, R.G.Baldwin");

          //Create the picture that will be processed.
          // Note that the original image file is not
          // modified by this program.
          int pictureWidth = picture.getWidth();
          int pictureHeight = picture.getHeight();
          display = new Picture(
                              pictureWidth,pictureHeight);

          //Draw the initial display.
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          display.show();

          //Adjust the width of the GUI to match the width
          // of the display if possible. Then relocate the
          // GUI to a position immediately below the
          // display.
          //Establish the preferred size now that the
          // input file name has been entered.
          pack();
          int packedHeight = getHeight();
          int packedWidth = getWidth();
          if((pictureWidth + 7) >= packedWidth){
            //Make the width of the GUI the same as the
            // width of the display.
            setSize(pictureWidth + 7,packedHeight);
          }//Else, just leave the GUI at its current size.
          //Put the GUI in its new location immediately
          // below the display.
          setLocation(0,pictureHeight + 30);

          //Enable the user input controls.
          slider.setEnabled(true);
          writeButton.setEnabled(true);

        }//end actionPerformed
      }//end new ActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register an ActionListener on the writeButton.
    // Each time the user clicks the button, a backup bmp
    // file containing the current state of the display is
    // written into the directory from which the original
    // picture was read. The five most recent backup files
    // are saved. The names of the backup files are the
    // same as the name of the input file except that BAKn
    // is inserted immediately ahead of the extension
    // where n is a digit ranging from 0 to 4. The value
    // of n rolls over at 4 and starts back at 0.
    writeButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          display.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");
          //Reset the writeCounter if it exceeds 4 to
          // conserve disk space.
          if(writeCounter > 4){
            writeCounter = 0;
          }//end if
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register a WindowListener that will respond when the
    // user clicks the large X in the upper-right corner
    // of the GUI. This event handler will write the final
    // state of the display into an output file of the
    // same type as the original input file. The name will
    // be the same except that the word FINAL will be
    // inserted immediately ahead of the extension.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          display.write(outputPath + "FINAL" + extension);
          System.exit(0);
        }//end windowClosing
      }//end new WindowAdapter
    );//end addWindowListener
    //--------------------------------------------------//
    //Register a ChangeListener object on the slider.
    //Each time the slider fires a ChangeEvent, this event
    // handler creates a new display as a copy of the
    // original picture and calls a method named
    // processThePicture.
    slider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          //Draw a new copy of the picture on the display.
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          processThePicture();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//

  }//end constructor
  //----------------------------------------------------//

  //This version of the processThePicture method applies
  // one of many possible blurring or softening algorithms
  // to the image. In pure technical terms, this method
  // convolves the pixels in the image with a 25-point,
  // two-dimensional convolution filter having very
  // specific characteristics. The convolution filter is
  // applied separately to the red, green, and blue color
  // components of the pixels.
  //Using terminology that may be more familiar to you,
  // each color component value for each pixel is replaced
  // by a weighted sum of the color component value for
  // that pixel (referred to as the center pixel) and the
  // color component values for its 24 closest
  // neighbors. Equal weights are applied to each of the
  // 24 neighbors. The sum of the weights applied to
  // the center pixel and its 24 neighbors is 1.0.
  //The current value of the slider is used with a
  // logarithmic algorithm to compute the set of weights
  // that are applied to the pixel and its 24
  // neighbors. For example, when the slider value is 0 or
  // 1, a weight of 1.0 is applied to the center pixel and
  // weights of 0.0 are applied to the neighbors. For this
  // case, no blurring occurs.
  //There is no blurring when the slider is at the far
  // left or 0 position.  The farther to the right the
  // slider moves, the greater will be the relative
  // contribution of the 24 neighboring pixels to the
  // weighted sum, and the greater will be the blurring or
  // softening effect. Maximum blurring occurs when the
  // slider is at the far right in the 100 position.
  private void processThePicture(){
    //Compute the weights to be applied to the center
    // pixel and its 24 closest neighbors.
    double value = (double)(slider.getValue());
    double centerWeight = 0.0;

    //Convert the slider value to a scaled log value with
    // a maximum value of 1.0.
    if(value > 1.0){
      centerWeight = 1.0 - Math.log10(value)/2;
    }else{
      centerWeight = 1.0 - Math.log10(1.0)/2;
    }//end else

    //Compute the weight that is applied to each of the
    // twenty-four neighboring pixels.
    double neighborWeight = (1.0 - centerWeight)/24.0;

    //Declare some working varibles.
    int width = display.getWidth();
    int height = display.getHeight();
    int red = 0;
    int green = 0;
    int blue = 0;
    Pixel pixel = null;
    Pixel[] pixels = new Pixel[24];

    //Create a temporary copy of the display to serve as
    // input to the computations that follow. This will
    // prevent the processing of one row from having an
    // influence on the processing of the next row.
    Picture temp = new Picture(display);

    //Process each pixel.
    for(int col = 2;col < width - 2;col++){
      for(int row = 2;row < height - 2;row++){
        //Get and save the pixel at the center of the
        // current nine-pixel group.
        pixel = display.getPixel(col,row);

        //Get and save the 24 neighboring pixels.
        pixels[0] = temp.getPixel(col-2,row-2);
        pixels[1] = temp.getPixel(col-1,row-2);
        pixels[2] = temp.getPixel(col,row-2);
        pixels[3] = temp.getPixel(col+1,row-2);
        pixels[4] = temp.getPixel(col+2,row-2);

        pixels[5] = temp.getPixel(col-2,row-1);
        pixels[6] = temp.getPixel(col-1,row-1);
        pixels[7] = temp.getPixel(col,row-1);
        pixels[8] = temp.getPixel(col+1,row-1);
        pixels[9] = temp.getPixel(col+2,row-1);

        pixels[10] = temp.getPixel(col-2,row);
        pixels[11] = temp.getPixel(col-1,row);
        pixels[12] = temp.getPixel(col+1,row);
        pixels[13] = temp.getPixel(col+2,row);

        pixels[14] = temp.getPixel(col-2,row+1);
        pixels[15] = temp.getPixel(col-1,row+1);
        pixels[16] = temp.getPixel(col,row+1);
        pixels[17] = temp.getPixel(col+1,row+1);
        pixels[18] = temp.getPixel(col+2,row+1);

        pixels[19] = temp.getPixel(col-2,row+2);
        pixels[20] = temp.getPixel(col-1,row+2);
        pixels[21] = temp.getPixel(col,row+2);
        pixels[22] = temp.getPixel(col+1,row+2);
        pixels[23] = temp.getPixel(col+2,row+2);

        //Compute the weighted average of the red values.
        red = 0;
        //First compute the sum of the color values for
        // the 24 neighboring pixels.
        for(int cnt = 0;cnt < pixels.length;cnt++){
          red += pixels[cnt].getRed();
        }//end for loop
        //Now apply the weights and store the resulting
        // value in the center pixel of the nine-pixel
        // group in the display.
        red = (int)(red*neighborWeight
                           + pixel.getRed()*centerWeight);
        pixel.setRed(red);

        //Compute the weighted average of the green
        // values. This is essentially the same algorighm
        // as for the red values.
        green = 0;
        for(int cnt = 0;cnt < pixels.length;cnt++){
          green += pixels[cnt].getGreen();
        }//end for loop
        green = (int)(green*neighborWeight
                         + pixel.getGreen()*centerWeight);
        pixel.setGreen(green);

        //Compute the weighted average of the blue values.
        // This is essentially the same algorighm as for
        // the red values.
        blue = 0;
        for(int cnt = 0;cnt < pixels.length;cnt++){
          blue += pixels[cnt].getBlue();
        }//end for loop
        blue = (int)(blue*neighborWeight
                          + pixel.getBlue()*centerWeight);
        pixel.setBlue(blue);

      }//end inner loop
    }//end outer loop

    display.repaint();

  }//end processThePicture
  //----------------------------------------------------//

}//end class Blur02



//34567890123456789012345678901234567890123456789012345678


