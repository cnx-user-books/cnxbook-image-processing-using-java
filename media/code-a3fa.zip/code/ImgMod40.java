//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//
//07/10/06 Ready to publish.

/*File ImgMod40.java
Copyright 2006, R.G.Baldwin

The purpose of this class is to illustrate a variety of 
different uses for the AffineTransformOp filter class of 
the Java 2D API.

See general comments in the class named ImgMod038.

This class is compatible with the use of the driver program
named ImgMod05.

The driver program named ImgMod05 displays the original and
the modified images.  It also writes the modified image 
into an output file in JPEG format.  The name of the output
file is junk.jpg and it is written into the current 
directory.

Image-processing programs such as this one may provide a 
GUI for data input making it possible for the user to 
modify the behavior of the image-processing method each 
time the Replot button is clicked.  Such a GUI is provided
for this program.

Enter the following at the command line to run this 
program:

java ImgMod05 ImgMod40 ImageFileName

If the program is unable to load the image file within ten
seconds, it will abort with an error message.

This program creates a GUI consisting of a tabbed pane 
containing four pages.  The tabs on the pages are labeled:

Scaling
Translation
Rotation
Mirror Image

Each page contains a set of controls that makes it possible
to process the image in a way that illustrates the 
processing concept indicated by the label on the tab.
Processing details for each page are provided in the 
comments in the code used to construct and process the 
individual pages.

Tested using J2SE 5.0 under WinXP.
**********************************************************/

import java.awt.image.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.AffineTransform;

class ImgMod40 extends Frame implements ImgIntfc05{
  //Primary container used to construct the GUI.
  JTabbedPane tabbedPane = new JTabbedPane();
  
  //Components used to construct the Scaling page.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel page00 = new Panel();
  TextField page00TextFieldHorizontal = 
                                    new TextField("0.5",6);
  TextField page00TextFieldVertical = 
                                    new TextField("0.5",6);
  //Components for radio buttons
  CheckboxGroup Page00Group = new CheckboxGroup();
  Checkbox page00NearestNeighbor = new Checkbox(
       "Nearest Neighbor Interpolation",Page00Group,false);
  Checkbox page00Bilinear = new Checkbox(
               "Bilinear Interpolation",Page00Group,false);
  Checkbox page00Bicubic = new Checkbox(
                 "Bicubic Interpolation",Page00Group,true);
  
  //Components used to construct the Translation page.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel page01 = new Panel();
  TextField page01TextFieldHorizontal = 
                                      new TextField("5",6);
  TextField page01TextFieldVertical = 
                                     new TextField("10",6);

  //Components used to construct the Rotation page.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel page02 = new Panel();
  TextField page02TextField = new TextField("45.0",6);
  
  //Components used to construct the Mirror Image page.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel page03 = new Panel();
  
  //-----------------------------------------------------//
  
  //This is the primary constructor.  It calls other
  // methods to separate the construction of the GUI into
  // easily understandable units.  Each method that it
  // calls constructs one page in the tabbed pane.
  ImgMod40(){//constructor
  
    constructPage00();
    tabbedPane.add(page00);//Add page to the tabbedPane.
    
    constructPage01();
    tabbedPane.add(page01);//Add page to the tabbedPane.
    
    constructPage02();
    tabbedPane.add(page02);//Add page to the tabbedPane.
    
    constructPage03();
    tabbedPane.add(page03);//Add page to the tabbedPane.
    
    add(tabbedPane);//Add tabbedPane to the Frame.

    setTitle("Copyright 2006, R.G.Baldwin");
    setBounds(555,0,470,300);
    setVisible(true);

    //Define a WindowListener to terminate the program.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(1);
        }//end windowClosing
      }//end windowAdapter
    );//end addWindowListener
  }//end constructor
  //-----------------------------------------------------//
  
  //This method constructs the Scaling page.
  // This method is called from the primary constructor.
  void constructPage00(){
    page00.setName("Scaling");//Label on the tab.
    page00.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    // This text appears in a disabled text area at the
    // top of the page in the tabbed pane.
    String text ="IMAGE SCALING\n"
      + "This page illustrates the scaling of an image "
      + "using three different types of interpolation."
      + "\n\n"
      + "Enter a positive scale factor between 0.001 and "
      + "10.0 in each of the text fields, select an "
      + "interpolation type, and click the Replot button. "
      + "The best quality interpolation will probably be "
      + "achieved with the use of Bicubic Interpolation. "
      + "Nearest Neighbor Interpolation will probably "
      + "produce the poorest quality.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,7,1,
                                 TextArea.SCROLLBARS_NONE);
    page00.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);

    //Construct the control panel and add it to the page.
    Panel page00ControlPanel = new Panel();
    page00ControlPanel.setLayout(new GridLayout(5,1));
    
    //Construct and populate the panels that contain the
    // radio buttons, the labels, and the text fields.
    // Add each such panel an a new cell in the grid
    // layout going from the top of the grid to the bottom
    // of the grid.
    
    //Begin with the radio buttons.  The purpose of putting
    // the radio buttons on panels is to cause them to be
    // left justified in their cells.
    Panel subControlPanel00 = new Panel();
    subControlPanel00.setLayout(new FlowLayout(
                                         FlowLayout.LEFT));
    subControlPanel00.add(page00NearestNeighbor);
    page00ControlPanel.add(subControlPanel00);
    
    Panel subControlPanel01 = new Panel();
    subControlPanel01.setLayout(new FlowLayout(
                                         FlowLayout.LEFT));
    subControlPanel01.add(page00Bilinear);
    page00ControlPanel.add(subControlPanel01);
    
    Panel subControlPanel02 = new Panel();
    subControlPanel02.setLayout(new FlowLayout(
                                         FlowLayout.LEFT));
    subControlPanel02.add(page00Bicubic);
    page00ControlPanel.add(subControlPanel02);
    
    //Now create and populate panels that contain labels
    // and associated TextField objects
    Panel subControlPanel03 = new Panel();
    subControlPanel03.setLayout(new FlowLayout(
                                         FlowLayout.LEFT));
    subControlPanel03.add(new Label(
                               "Horizontal Scale Factor"));
    subControlPanel03.add(page00TextFieldHorizontal);
    page00ControlPanel.add(subControlPanel03);
    
    Panel subControlPanel04 = new Panel();
    subControlPanel04.setLayout(new FlowLayout(
                                         FlowLayout.LEFT));
    subControlPanel04.add(new Label(
                                 "Vertical Scale Factor"));
    subControlPanel04.add(page00TextFieldVertical);
    page00ControlPanel.add(subControlPanel04);
    
    page00.add(page00ControlPanel,BorderLayout.CENTER);
  }//end constructPage00
  //-----------------------------------------------------//

  //This method processes the image according to the
  // controls located on the Scaling page.
  //This method uses the AffineTransformOp filter class to
  // process the image.
  //The method is called from within the switch statement
  // in the method named processImg, which is the primary
  // image-processing method in this program.
  //This method illustrates image scaling, giving the user
  // a choice of three different interpolation schemes.
  //See the earlier lesson at
  // http://www.developer.com/java/other/article.php
  // /626051
  // for additional information on the use of a scaling
  // affine transform.
  BufferedImage processPage00(BufferedImage theImage){
    
    //Set a non-zero default value for the horizontal scale
    // factor.
    double horizontalScale = 0.001;
    try{//Get horizontalScale from the text field.
      horizontalScale = Double.parseDouble(
                      page00TextFieldHorizontal.getText());
    }catch(java.lang.NumberFormatException e){
      page00TextFieldHorizontal.setText("Bad Input");
      horizontalScale = 0.001; //Override bad user input.
    }//end catch
    
    //Guarantee reasonable values for horizontal scale
    if((horizontalScale < 0.001) || 
                                 (horizontalScale > 10.0)){
      page00TextFieldHorizontal.setText("Bad Input");
      horizontalScale = 0.001;//Override bad user input.
    }//end if
  
    //Set a non-zero default value for the vertical scale
    // factor.
    double verticalScale = 0.001;
    try{//Get verticalScale from the text field.
      verticalScale = Double.parseDouble(
                        page00TextFieldVertical.getText());
    }catch(java.lang.NumberFormatException e){
      page00TextFieldHorizontal.setText("Bad Input");
      verticalScale = 0.001; //Override bad user input.
    }//end catch
    
    //Guarantee reasonable values for verticalScale
    if((verticalScale < 0.001) || (verticalScale > 10.0)){
      page00TextFieldHorizontal.setText("Bad Input");
      verticalScale = 0.001;//Override bad user input.
    }//end if
    
    //Get the selected interpolation scheme from the radio
    // buttons and reflect that selection in an int value
    // corresponding to the selected button.
    int interpolationScheme;
    if(page00Bicubic.getState() == true){
      interpolationScheme = 
                            AffineTransformOp.TYPE_BICUBIC;
    }else if(page00Bilinear.getState() == true){
      interpolationScheme = 
                           AffineTransformOp.TYPE_BILINEAR;
    }else{//page00NearestNeighbor must be selected
      interpolationScheme = 
                   AffineTransformOp.TYPE_NEAREST_NEIGHBOR;
    }//end else
    
    //An AffineTransform object is required later to create
    // the filter object.  An examination of the
    // documentation for the AffineTransform class will
    // show that there are several different ways to create
    // such an object.  The following statement is probably
    // the simplest of those ways.
    //Create an AffineTransform object for scaling that
    // matches the user input from the control panel.
    AffineTransform transformObj = 
                         AffineTransform.getScaleInstance(
                            horizontalScale,verticalScale);
    
    //At this point, you could use the methods of the
    // AffineTransform class to get, modify, and restore
    // the transform matrix in order to modify the
    // behavior of the transformation process.  See the
    // earlier lesson at
    // http://www.developer.com/java/other/article.php
    // /626051
    // for additional information on this topic.
        
    //Use the AffineTransform object to create a filtering
    // object.
    AffineTransformOp filterObj = new AffineTransformOp(
                         transformObj,interpolationScheme);

    /*Note:  Normally, I would perform the filtering 
     *operation and return the filtered result simply by 
     *executing the following statement:
    
     *  return filterObj.filter(theImage, null);
      
     *However, for reasons that I am unable to explain, 
     *when I do that for the AffineTransformOp class, the
     *ColorModel of the BufferedImage object that is 
     *returned to the framework program named ImgMod05 is
     *not compatible with the method used by that program 
     *to write the output JPEG file.  This results in an 
     *output file in which the image data appears to be 
     *scrambled.  Therefore, it was necessary for me to
     *use the following alternative code instead.*/
    
    //Create a destination BufferedImage object to receive
    // the filtered image.  Force the ColorModel of the
    // destination object to match the ColorModel of the
    // incoming object.
    BufferedImage dest = 
                      filterObj.createCompatibleDestImage(
                        theImage,theImage.getColorModel());
    
    //Filter the image and save the filtered image in the
    // destination object.
    filterObj.filter(theImage, dest);
    
    //Return a reference to the destination object.
    return dest;

  }//end processPage00
  //-----------------------------------------------------//
  
  //This method constructs the Translation page.
  //The method is called from the primary constructor.
  void constructPage01(){
    page01.setName("Translation");//Label on the tab.
    page01.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    // This text appears in a disabled text area at the
    // top of the page in the tabbed pane.
    String text ="IMAGE TRANSLATION\n"
      + "This page illustrates the translation of an "
      + "image to a new location relative to the "
      + "upper-left corner of the container using Bicubic "
      + "Interpolation.\n\n"
      + "Enter the horizontal and vertical translation "
      + "distances in pixels into the text fields and "
      + "click the Replot button.\n\n"
      + "Note that the translation distances must be "
      + "between -1000 and +1000 pixels.  Also note that "
      + "negative translations may shift the image "
      + "completely out of the Frame on the top or the "
      + "left side of the image.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,9,1,
                                 TextArea.SCROLLBARS_NONE);
    page01.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);

    //Construct the control panel and add it to the page.
    Panel page01ControlPanel = new Panel();
    page01ControlPanel.setLayout(new GridLayout(3,1));
    
    //Place each label and its corresponding text field
    // on a panel.  Place the panels in the cells in the
    // grid layout from top to bottom.  Note that there
    // is an empty cell at the bottom for cosmetic
    // purposes.
    Panel subControlPanel00 = new Panel();
    subControlPanel00.setLayout(
                          new FlowLayout(FlowLayout.LEFT));
    subControlPanel00.add(new Label(
             "Horizontal Translation Distance in Pixels"));
    subControlPanel00.add(page01TextFieldHorizontal);
    page01ControlPanel.add(subControlPanel00);
    
    Panel subControlPanel01 = new Panel();
    subControlPanel01.setLayout(
                          new FlowLayout(FlowLayout.LEFT));
    subControlPanel01.add(new Label(
               "Vertical Translation Distance in Pixels"));
    subControlPanel01.add(page01TextFieldVertical);
    page01ControlPanel.add(subControlPanel01);
    
    page01.add(page01ControlPanel,BorderLayout.CENTER);
  }//end constructPage01
  //-----------------------------------------------------//

  //This method processes the image according to the
  // controls located on the Translation page.
  //This method uses the AffineTransformOp filter class
  // to process the image.  The method is called from
  // within the switch statement in the method
  // named processImg, which is the primary image
  // processing method in this program.
  //This method illustrates image translation using Bicubic
  // Interpolation.
  BufferedImage processPage01(BufferedImage theImage){
    
    double horizontalDistance = 0.0;
    try{//Get horizontalDistance from the text field.
      horizontalDistance = Double.parseDouble(
                      page01TextFieldHorizontal.getText());
    }catch(java.lang.NumberFormatException e){
      page01TextFieldHorizontal.setText("Bad Input");
      horizontalDistance = 0.0; //Override bad user input.
    }//end catch
   
    //Guarantee reasonable values for horizontalDistance
    if((horizontalDistance < -1000.0) || 
                            (horizontalDistance > 1000.0)){
      page01TextFieldHorizontal.setText("Bad Input");
      horizontalDistance = 0.0;//Override bad user input.
    }//end if

    double verticalDistance = 0.0;
    try{//Get verticalDistance from the text field.
      verticalDistance = Double.parseDouble(
                        page01TextFieldVertical.getText());
    }catch(java.lang.NumberFormatException e){
      page01TextFieldHorizontal.setText("Bad Input");
      verticalDistance = 0.0; //Override bad user input.
    }//end catch
    
    //Guarantee reasonable values for verticalDistance
    if((verticalDistance < -1000.0) || 
                              (verticalDistance > 1000.0)){
      page01TextFieldHorizontal.setText("Bad Input");
      verticalDistance = 0.0;//Override bad user input.
    }//end if
  
    //Set the interpolation scheme to the best available.
    // Note that this page doesn't allow the user to
    // select the interpolation scheme.
    int interpolationScheme = 
                            AffineTransformOp.TYPE_BICUBIC;

    //Create an AffineTransform object for translation that
    // matches the user input from the control panel.
    //Note that even though the actual translation is
    // performed in terms of integer pixels, the 
    // getTranslateInstance method requires the horizontal
    // and vertical distances to be provided as type
    // double.  A positive horizontal distance will cause
    // the image to appear to move to the right in its
    // container and a negative horizontal distance will
    // cause the image to appear to move to the left.
    // Similarly, a positive vertical distance will cause
    // the image to appear to move down and a negative
    // vertical distance will cause the image to appear to
    // move up.
    AffineTransform transformObj = 
                    AffineTransform.getTranslateInstance(
                      horizontalDistance,verticalDistance);
        
    //Use the AffineTransform object to create a filtering
    // object.
    AffineTransformOp filterObj = new AffineTransformOp(
                         transformObj,interpolationScheme);
    
    /*Note:  Normally, I would perform the filtering 
     *operation and return the filtered result simply by 
     *executing the following statement:
    
     *  return filterObj.filter(theImage, null);
      
     *However, for reasons that I am unable to explain, 
     *when I do that for the AffineTransformOp class, the
     *ColorModel of the BufferedImage object that is 
     *returned to the framework program named ImgMod05 is
     *not compatible with the method used by that program 
     *to write the output JPEG file.  This results in an 
     *output file in which the image data appears to be 
     *scrambled.  Therefore, it was necessary for me to
     *use the following alternative code instead.*/
    
    //Create a destination BufferedImage object to receive
    // the filtered image.  Force the ColorModel of the
    // destination object to match the ColorModel of the
    // incoming object.
    BufferedImage dest = 
                      filterObj.createCompatibleDestImage(
                        theImage,theImage.getColorModel());
    
    //Filter the image and save the filtered image in the
    // destination object.
    filterObj.filter(theImage, dest);
    
    //Return a reference to the destination object.
    return dest;

  }//end processPage01
  //-----------------------------------------------------//
  
  //This method constructs the Rotation page.
  //This method is called from the primary constructor. 
  // It illustrates the translation of an image followed by
  // rotation of the translated image.
  void constructPage02(){
    page02.setName("Rotation");//Label on the tab.
    page02.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    // This text appears in a disabled text area at the
    // top of the page in the tabbed pane.
    String text ="IMAGE Rotation\n"
      + "This page illustrates translation of an image "
      + "followed by Rotation of the same image using "
      + "Bicubic Interpolation.\n\n"
      + "The image is rotated around its center after "
      + "being translated to the right and down by a "
      + "distance that is sufficient to give it room to "
      + "rotate.\n\n"
      + "Enter the desired rotation angle in degrees and "
      + "click the Replot button.  Positive rotation "
      + "angles represent clockwise rotation and negative "
      + "rotation angles represent counter-clockwise "
      + "rotation.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,9,1,
                                 TextArea.SCROLLBARS_NONE);
    page02.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);

    //Construct the control panel and add it to the page.
    // Use a control panel with a GridLayout for 
    // cosmetic purposes.  Note that there are two empty
    // cells at the bottom of the grid.
    Panel page02ControlPanel = new Panel();
    page02ControlPanel.setLayout(new GridLayout(3,1));
    
    //Place the label and the text field on a panel and
    // place that panel in the top cell in the grid.
    Panel subControlPanel00 = new Panel();
    subControlPanel00.setLayout(new FlowLayout(
                                         FlowLayout.LEFT));
    //Note, a positive value in degrees represents
    // clockwise rotation.
    subControlPanel00.add(new Label(
                                   "Rotation in Degrees"));
    subControlPanel00.add(page02TextField);
    page02ControlPanel.add(subControlPanel00);
       
    page02.add(page02ControlPanel,BorderLayout.CENTER);
  }//end constructPage02
  //-----------------------------------------------------//

  //This method processes the image according to the
  // controls located on the Rotation page.
  //This method uses the AffineTransformOp filter class
  // to process the image.  The method is called from
  // within the switch statement in the method named
  // processImg, which is the primary image-processing
  // method in this program.
  //This method illustrates image Translation followed by 
  //image Rotation using Bicubic Interpolation.
  BufferedImage processPage02(BufferedImage theImage){
    
    //Get the rotation angle in degrees.  A positive angle
    // in degrees corresponds to clockwise rotation.
    double rotationAngleInDegrees = 0.0;
    try{//Get rotationAngleInDegrees from the text field.
      rotationAngleInDegrees = Double.parseDouble(
                                page02TextField.getText());
    }catch(java.lang.NumberFormatException e){
      page02TextField.setText("Bad Input");
      rotationAngleInDegrees = 0.0;//Override bad input.
    }//end catch
    
    //Compute the rotation angle in radians.
    double rotationAngleInRadians = 
                      rotationAngleInDegrees*Math.PI/180.0;
  
    //Set the interpolation scheme.
    int interpolationScheme = 
                            AffineTransformOp.TYPE_BICUBIC;
    
    //Translate the image down and to the right far enough
    // that the corners won't be chopped off by the top and
    // left edges of the container when the image is
    // rotated by 45 degrees.
    
    //Get the length of half the diagonal dimension of the
    // image using the formula for the hypotenuse of a
    // right triangle.
    int halfDiagonal = (int)(Math.sqrt(
         theImage.getWidth()*theImage.getWidth() + 
           theImage.getHeight()*theImage.getHeight())/2.0);
                                 
    //Set the horizontal and vertical translation
    // distances.
    int horizontalDistance = 
                      halfDiagonal - theImage.getWidth()/2;
    int verticalDistance = 
                     halfDiagonal - theImage.getHeight()/2;
    
    //Create an Affine Transform object that can be used
    // to translate the image by the distances computed
    // above.
    AffineTransform transformObj = 
                    AffineTransform.getTranslateInstance(
                      horizontalDistance,verticalDistance);
    
    //Get a translation filter object based on the
    // AffineTransform object.
    AffineTransformOp filterObj = new AffineTransformOp(
              transformObj,AffineTransformOp.TYPE_BICUBIC);
    
    //Perform the translation and save the modified image
    // as type BufferedImage.  This image will be the input
    // to the rotation transform.
    BufferedImage translatedImage = 
                          filterObj.filter(theImage, null);
    
    //Now rotate the image around a point that is at the
    // center of the original image.  Begin by getting a
    // rotation transform object.  The second and third
    // parameters specify the point about which the image
    // will be rotated.
    transformObj = AffineTransform.getRotateInstance(
                rotationAngleInRadians,
                horizontalDistance + theImage.getWidth()/2,
                verticalDistance + theImage.getHeight()/2);
                  
    //Now get a rotation filter object based on the
    // transform object and the specified interpolation
    // scheme.
    filterObj = new AffineTransformOp(
                         transformObj,interpolationScheme);

    /*Note:  Normally, I would perform the filtering 
     *operation and return the filtered result simply by 
     *executing the following statement:
    
     *  return filterObj.filter(translatedImage, null);
      
     *However, for reasons that I am unable to explain, 
     *when I do that for the AffineTransformOp class, the
     *ColorModel of the BufferedImage object that is 
     *returned to the framework program named ImgMod05 is
     *not compatible with the method used by that program 
     *to write the output JPEG file.  This results in an 
     *output file in which the image data appears to be 
     *scrambled.  Therefore, it was necessary for me to
     *use the following alternative code instead.*/
    
    //Create a destination BufferedImage object to receive
    // the filtered image.  Force the ColorModel of the
    // destination object to match the ColorModel of the
    // incoming object.
    BufferedImage dest = 
               filterObj.createCompatibleDestImage(
                 translatedImage,theImage.getColorModel());
    
    //Filter the image and save the filtered image in the
    // destination object.
    filterObj.filter(translatedImage, dest);
    
    //Return a reference to the destination object.
    return dest;  

  }//end processPage02
  //-----------------------------------------------------//
  
  //This method constructs the Mirror Image page.
  //This method is called from the primary constructor.
  void constructPage03(){
    page03.setName("Mirror Image");//Label on the tab.
    page03.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the page.
    //This text appears in a disabled text area at the
    // top of the page in the tabbed pane.
    String text ="Mirror Image\n\n"
      + "This page translates the image to the right by "
      + "an amount equal to its width, and then flips it "
      + "around its left edge to produce a mirror image "
      + "of the original image.\n\n"
      + "Click the Replot button to create the mirror "
      + "image.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,6,1,
                                 TextArea.SCROLLBARS_NONE);
    page03.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);

  }//end constructPage03
  //-----------------------------------------------------//

  //This method processes the image according to the
  // Mirror Image page.
  //This method uses the AffineTransformOp filter class to
  // process the image.  The method is called from within
  // the switch statement in the method named processImg,
  // which is the primary image processing method in this
  // program.
  //Note that unlike Scaling, Translation, and Rotation, 
  // there is no affine transform for Mirror Image. Rather,
  // this method illustrates the use of horizontal
  // translation followed by scaling with negative scale
  // factors to produce a mirror image of the original
  // image.
  BufferedImage processPage03(BufferedImage theImage){

    //Get an AffineTransform object that can be used to
    // shift the image to the right by an amount equal to
    // its width.
    AffineTransform transformObj = 
                      AffineTransform.getTranslateInstance(
                                    theImage.getWidth(),0);
    
    //Concatenate this transform with a scaling
    // transformation.
    transformObj.scale(-1.0, 1.0);
    
    //Display the six values in the transformation matrix.
    double[] theMatrix = new double[6];
    transformObj.getMatrix(theMatrix);
    
    //Display first row of values by displaying every
    // other element in the array starting with element
    // zero.
    for(int cnt = 0; cnt < 6; cnt+=2){
      System.out.print(theMatrix[cnt] + "\t");
    }//end for loop
    
    //Display second row of values displaying every
    // other element in the array starting with element
    // number one.
    System.out.println();//new line
    for(int cnt = 1; cnt < 6; cnt+=2){
      System.out.print(theMatrix[cnt] + "\t");
    }//end for loop
    System.out.println();//end of line
    System.out.println();//blank line

    //Get a translation filter object based on the
    // AffineTransform object.
    AffineTransformOp filterObj = new AffineTransformOp(
              transformObj,AffineTransformOp.TYPE_BICUBIC);
    
    /*Note:  Normally, I would perform the filtering 
     *operation and return the filtered result simply by 
     *executing the following statement:
    
     *  return filterObj.filter(theImage, null);
      
     *However, for reasons that I am unable to explain, 
     *when I do that for the AffineTransformOp class, the
     *ColorModel of the BufferedImage object that is 
     *returned to the framework program named ImgMod05 is
     *not compatible with the method used by that program 
     *to write the output JPEG file.  This results in an 
     *output file in which the image data appears to be 
     *scrambled.  Therefore, it was necessary for me to
     *use the following alternative code instead.*/
    
    //Create a destination BufferedImage object to receive
    // the filtered image.  Force the ColorModel of the
    // destination object to match the ColorModel of the
    // incoming object.
    BufferedImage dest = 
                      filterObj.createCompatibleDestImage(
                        theImage,theImage.getColorModel());
    
    //Filter the image and save the filtered imate in the
    // destination object.
    filterObj.filter(theImage, dest);
    
    //Return a reference to the destination object.
    return dest;

  }//end processPage03
  //-----------------------------------------------------//

  //The following method must be defined to implement the
  // ImgIntfc05 interface.  It is called by the framework
  // program named ImgMod05.
  public BufferedImage processImg(BufferedImage theImage){
    
    BufferedImage outputImage = null;
    
    //Process the page in the tabbed pane that has been
    // selected by the user.
    switch(tabbedPane.getSelectedIndex()){
      case 0:outputImage = processPage00(theImage);
             break;
      case 1:outputImage = processPage01(theImage);
             break;
      case 2:outputImage = processPage02(theImage);
             break;
      case 3:outputImage = processPage03(theImage);
             break;
    }//end switch

    return outputImage;
  }//end processImg
}//end class ImgMod40


