//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//
//Ready for publication, 06/17/06

/*File ImgMod05.java
Copyright 2006, R.G.Baldwin

This is an update of the class named ImgMod04a designed to
accommodate the use of the image processing operations of 
the Java 2D API.  When this class is run as a program, it 
sends and receives a BufferedImage object to an image 
processing method of a compatible image processing object 
instead of sending and receiving an array of pixel data as 
is the case in the class named ImgMod04a.

The purpose of this program is to make it easy to 
experiment with the modification of image data using the 
image processing operations of the Java 2D API and to 
display a modified version of the image along with the 
original image.

This program also writes the modified image into an output 
file in JPEG format.  The name of the output file is 
junk.jpg and it is written into the current directory.

The output GUI contains a Replot button.  At the beginning 
of the run, and each time thereafter that the Replot 
button is clicked:
-The image processing method belonging to the image 
 processing object is invoked,
-The resulting modified image is displayed along with the 
 original image.

The Replot button is located at the top of the display to
make it accessible when the display is too tall to fit
on the screen.  (For purposes of seeing the entire 
display in that case, it can be moved up and down on the
screen using the right mouse button and the up and down
arrow keys.)

The program will read gif and jpg input files and possibly 
some other input file types as well.  The output file is 
always a JPEG file.

This program provides a framework that is designed to 
invoke another program to process an input image.  This 
program reads the image from the input file and converts it
to type BufferedImage.  A second program is invoked to 
actually process the image.

Typically the image processing program is based on the 
image processing operations of the Java 2D API, but that is
not a requirement.  The only requirement is that the image 
processing program be capable of receiving the image as 
type BufferedImage and returning the processed image as 
type BufferedImage.

Typical usage is as follows:

java ImgMod05 ProcessingProgramName ImageFileName

For test and illustration purposes, the source code 
includes a class definition for a sample image processing 
program named ProgramTest.

If the command-line parameters are omitted, the program 
will search for an image file in the current directory 
named ImgMod05Test.jpg and will process it using the sample
image processing program named ProgramTest.  The sample 
program returns a reference to a BufferedImage object in 
which the colors in the modified image are inverted 
relative to the colors in the original image.

The image file must be provided by the user in all cases.
However, it doesn't have to be in the current directory if
a path to the file is specified on the command line.

When the program is started, the original image and the
processed version of the image are displayed in a frame
with the original image above the processed image.  The 
program attempts to set the size of the display so as to 
accommodate both images.  If both images are not totally
visible, the user can manually resize the display frame.

A Replot button appears at the top of the frame.  The 
behavior of the Replot button is as described above
causing a newly processed version of the original image to 
replace the earlier processed version in the display.

The processing program may provide a  GUI for data input 
making it possible for the user to modify the behavior of 
the image processing method each time the Replot button is 
clicked.  (The sample image processing program does not
provide that capability.)

The image processing program must implement the 
interface named ImgIntfc05.  That interface declares an
image processing method with the following signature:

public BufferedImage processImg(BufferedImage input);

The processing method receives a reference to a 
BufferedImage object containing the image that is to be
processed

The image processing method must return a reference to a
BufferedImage object containing the processed image.

If the image processing program has a main method, it will
be ignored.

If the program is unable to load the image file within ten
seconds, it will abort with an error message.

Tested using J2SE5.0 under WinXP.
**********************************************************/

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.imageio.*;
import java.awt.image.*;

class ImgMod05 extends Frame{
  BufferedImage rawBufferedImage;
  BufferedImage processedImage;
  
  Frame displayFrame;//Frame to display the images.
  int inLeft;//left inset
  int inTop;//top inset
  int inBottom;//bottom inset
  int buttonHeight;//Height of Replot button

  //This is the name of the default image processing
  // program.  This class will be executed to process the
  // image if there aren't two command-line parameters. 
  // The source code for this class file is included in
  // this source code file.
  static String theProcessingClass = "ProgramTest";

  //This is the name of the default image file.  This image
  // file will be processed if there aren't two command-
  // line parameters.  You must provide this file in the
  // current directory if it will be needed.
  static String theImgFile = "ImgMod05Test.jpg";

  MediaTracker tracker;
  Display display = new Display();//A Canvas object
  Button replotButton = new Button("Replot");

  //Reference to the image processing object.
  ImgIntfc05 imageProcessingObject;
  //-----------------------------------------------------//

  public static void main(String[] args){
    //Get names for the image processing class and the
    // image file to be processed.  Program reads gif
    // files and jpg files and possibly some other file
    // types as well.
    if(args.length == 0){
      //Use default processing class and default image
      // file.  Class and file names were specified above.
    }else if(args.length == 2){
      theProcessingClass = args[0];
      theImgFile = args[1];
    }else{
      System.out.println("Invalid args");
      System.exit(1);
    }//end else

    //Display name of processing program and image file.
    System.out.println(
              "Processing program: " + theProcessingClass);
    System.out.println("Image file: " + theImgFile);

    //Instantiate an object of this class.
    ImgMod05 obj = new ImgMod05();
  }//end main
  //-------------------------------------------//

  public ImgMod05(){//constructor
    //Get an image from the specified image file.  Can be
    // in a different directory if the path was entered
    // with the file name on the  command line.
    rawBufferedImage = getTheImage();
  
    //Construct the display object.
    this.setTitle("Copyright 2006, Baldwin");
    this.setBackground(Color.YELLOW);
    this.add(display);
    this.add(replotButton,BorderLayout.NORTH);
    
    //Make the frame visible to make it possible to
    // get insets and the height of the button.
    setVisible(true);
    //Get and store inset data for the Frame and the height
    // of the button.
    inTop = this.getInsets().top;
    inLeft = this.getInsets().left;
    inBottom = this.getInsets().bottom;
    buttonHeight = replotButton.getSize().height;
    
    //Save a reference to this Frame object for use in
    // setting the size of the Frame later.
    displayFrame = this;

    //===================================================//
    //Anonymous inner class listener for Replot button.
    // This actionPerformed method is invoked when the user
    // clicks the Replot button.  It is also invoked at
    // startup when this program posts an ActionEvent to
    // the system event queue attributing the event to the
    // Replot button.
    replotButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Process the image.
          System.out.println("\nProcess the image");
          processedImage = 
                          imageProcessingObject.processImg(
                                         rawBufferedImage);
          System.out.println("Image processed");
          //Set the display size to accommodate the raw and
          // processed images.  In the event that the 
          // processed image won't fit in the display
          // frame, the user can manually resize the frame.
          // Set the size such that for non-rotated images,
          // a tiny amount of the background color shows
          // between the two images, to the right of the
          // larger image, and below the bottom image.
          int maxWidth = 0;
          //Get max image width.
          if(processedImage.getWidth() > 
                              rawBufferedImage.getWidth()){
            maxWidth = processedImage.getWidth();
          }else{
            maxWidth = rawBufferedImage.getWidth();
          }//end else
          int totalWidth = 2*inLeft + maxWidth + 2;

          //Get height of two images.
          int height = rawBufferedImage.getHeight() 
                              + processedImage.getHeight();
          int totalHeight = 
              inTop + inBottom + buttonHeight + height + 4;
          displayFrame.setSize(totalWidth,totalHeight);
          
          //Occasionally on an intermittant basis, without
          // the addition of the following statement, even
          // though the repaint method is called, the OS
          // doesn't make a call to the overridden paint
          // method.  As a result, the original and
          // processed images don't appear in the display
          // frame and it appears to be hung up in an
          // intermediate state.  The Sun documentation for
          // the Container class states "If a component has
          // been added to a container that has been
          // displayed, validate must be called on that
          // container to display the new component." 
          // Apparently the same thing holds true when the
          // size of the container is changed.  Inclusion
          // of the following statement seems to fix the
          // intermittant problem.
          displayFrame.validate();

          System.out.println("Call repaint");
          //Repaint the image display frame with the
          // original image at the top and the modified
          // image at the bottom.
          display.repaint();
          System.out.println("Repaint call complete");
          //Write the modified image into a JPEG file named
          // junk.jpg.
          System.out.println("Call writeJpegFile");
          writeJpegFile(processedImage);
          System.out.println(
                            "writeJpegFile call complete");
        }//end actionPerformed
      }//end ActionListener
    );//end addActionListener
    //End anonymous inner class registered on the Replot
    // button.
    //===================================================//
    
    //Continuing with the constructor code ...
    
    //Instantiate a new object of the image processing
    // class.  Note that this object is instantiated using
    // the newInstance method of the class named Class.
    // This approach does not allow for the use of a
    // parameterized constructor.
    try{
      imageProcessingObject = (ImgIntfc05)Class.forName(
                         theProcessingClass).newInstance();

       //Post a counterfit ActionEvent to the system event
       // queue and attribute it to the Replot button.
       // (See the anonymous ActionListener class that
       // registers an ActionListener object on the RePlot
       // button above.)  Posting this event causes the
       // image processing method to be invoked at startup
       // and causes the modified image to be displayed.
      Toolkit.getDefaultToolkit().getSystemEventQueue().
        postEvent(
          new ActionEvent(replotButton,
                          ActionEvent.ACTION_PERFORMED,
                          "Replot")
        );//end postEvent method

      //At this point, the image has been processed.  The
      // original image and the modified image have been
      // displayed.  From this point forward, each time the
      // user clicks the Replot button, a new image
      // processing will be instantiated, the image will be
      // processed again, and the new modified image will
      // be displayed along with the original image.

    }catch(Exception e){
      e.printStackTrace();
      System.exit(1);
    }//end catch

    //Cause the composite of the frame, the canvas, and the
    // button to become visible.
    this.setVisible(true);

    //===================================================//

    //Anonymous inner class listener to terminate
    // program.
    this.addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
    //===================================================//

  }//end ImgMod05 constructor
  //=====================================================//

  //Inner class for canvas object on which to display the
  // two images.
  class Display extends Canvas{
    //Override the paint method to display the raw image
    // and the modified image on the same Canvas object,
    // separated by a couple of rows of pixels in the
    // background color.
    public void paint(Graphics g){
      //First confirm that the image has been completely
      // loaded and that none of the image references are
      // null.
      if (tracker.statusID(1,false) ==
                                    MediaTracker.COMPLETE){
        if((rawBufferedImage != null) && 
           (processedImage != null)){
          //Draw raw image at the top.  Terminate if the
          // the pixels are changing.
          boolean success = false;
          success = g.drawImage(rawBufferedImage,0,0,this);
          if(!success){
            System.out.println("Unable to draw top image");
            System.exit(1);
          }//end if
          //Draw processed image at the bottom.
          success = g.drawImage(processedImage,0,
                    rawBufferedImage.getHeight() + 2,this);
          if(!success){
            System.out.println(
                            "Unable to draw bottom image");
            System.exit(1);
          }//end if
        }//end if
      }//end if
    }//end paint()
  }//end class myCanvas
//=======================================================//

  //Write the contents of a BufferedImage object to a JPEG
  // file named junk.jpg.
  void writeJpegFile(BufferedImage img){
    try{
      //Get a file output stream.
      FileOutputStream outStream = 
                          new FileOutputStream("junk.jpg");
      //Call the write method of the ImageIO class to write
      // the contents of the BufferedImage object to an
      // output file in JPEG format.
      ImageIO.write(img,"jpeg",outStream);
      outStream.close();
    }catch (Exception e) {
      e.printStackTrace();
    }//end catch
  }//end writeJpegFile
  //-----------------------------------------------------//
  
  //This method reads an image from a specified image file,
  // writes it into a BufferedImage object, and returns a
  // reference to the BufferedImage object.
  //The name of the image file is contained in an instance
  // variable of type String named theImgFile.
  BufferedImage getTheImage(){
    Image rawImage = Toolkit.getDefaultToolkit().
                                      getImage(theImgFile);

    //Use a MediaTracker object to block until the image is
    // loaded or ten seconds has elapsed.  Terminate and
    // display an error message if ten seconds elapse
    // without the image having been loaded.
    tracker = new MediaTracker(this);
    tracker.addImage(rawImage,1);

    try{
      if(!tracker.waitForID(1,10000)){
        System.out.println("Load error.");
        System.exit(1);
      }//end if
    }catch(InterruptedException e){
      e.printStackTrace();
      System.exit(1);
    }//end catch

    //Make certain that the file was successfully loaded.
    if((tracker.statusAll(false)
                             & MediaTracker.ERRORED
                             & MediaTracker.ABORTED) != 0){
      System.out.println("Load errored or aborted");
      System.exit(1);
    }//end if

    //Create an empty BufferedImage object.  Note that the
    // specified image type is critical to the correct
    // operation of the image processing method. The method
    // may work correctly for other image types, but has
    // been been tested only for TYPE_INT_RGB.
    BufferedImage buffImage = new BufferedImage(
                              rawImage.getWidth(this),
                              rawImage.getHeight(this),
                              BufferedImage.TYPE_INT_RGB);

    // Draw Image into BufferedImage
    Graphics g = buffImage.getGraphics();
    g.drawImage(rawImage, 0, 0, null);

    return buffImage;
  }//end getTheImage
  //-----------------------------------------------------//
}//end ImgMod05.java class
//=======================================================//

//The ProgramTest class

//The purpose of this class is to provide a simple example
// of an image processing class that is compatible with the
// use of the program named ImgMod05.  A compatible class 
// is required to implement the interface named ImgIntfc05.
// This, in turn, requires the class to define the method
// named processImg, which receives one parameter of 
// type BufferedImage and returns a reference of type
// BufferedImage.

//The method named processImg is a color inverter method.

//The method named processImg as defined in this class
// receives an incoming reference to an image as a
// parameter of type BufferedImage.  The method returns a
// reference to an image as type BufferedImage where all of
// the color values in the pixels have been inverted by
// subtracting the color values from 255.  The alpha values
// are not modified.

//The method has been demonstrated to work properly only
// for the case where the incoming BufferedImage object
// was constructed for image type
// BufferedImage.TYPE_INT_RGB.  However, it may work
// properly for other image types as well.

//Note that this class does not define a constructor.
// However, if it did define a constructor, that
// constructor would not be allowed to receive parameters.
// This is because the class named ImgMod05 instantiates an
// object of this class by invoking the newInstance method
// of the Class class passing the name of this class to the
// newInstance method as a String parameter.  That process
// does not allow for constructor parameters for the class
// being instantiated.
class ProgramTest implements ImgIntfc05{

  //The following method must be defined to implement the
  // ImgIntfc05 interface.
  //The following method must be defined to implement the
  // ImgIntfc05 interface.
  public BufferedImage processImg(BufferedImage theImage){

    //Use the LookupOp class from the Java 2D API to
    // invert all of the color values in the pixels.  The
    // alpha value is not modified.

    //Create the data for the lookup table.
    short[] lookupData = new short[256];
    for (int cnt = 0; cnt < 256; cnt++){
      lookupData[cnt] = (short)(255-cnt);
    }//end for loop
    
    //Create the lookup table
    ShortLookupTable lookupTable = 
                        new ShortLookupTable(0,lookupData);

    //Create the filter object.
    BufferedImageOp thresholdOp = 
                            new LookupOp(lookupTable,null);

    //Apply the filter to the incoming image and return
    // a reference to the resulting BufferedImage object.
    return thresholdOp.filter(theImage, null);
  }//end processImg
}//end class ProgramTest





