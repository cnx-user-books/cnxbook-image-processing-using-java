//34567890123456789012345678901234567890123456789012345678
//11/18/2008 Ready to publish.

/*Program Java356a
Copyright R.G.Baldwin 2009

The purpose of this program is to illustrate one way to 
take a photograph of a physical object and then 
superimpose it on another photograph.

A desk chair was placed in front of a bookcase. A blue 
sheet was hung on the bookcase to provide a relatively 
solid color background. A green towel was placed on the 
chair to hide the texture in the upholstry. A digital 
photograph of the chair was taken. Then a stuffed tiger 
was placed on the back of the chair and another digital 
photograph was taken.

Picture objects were instantiated from each of the 
photographs. Another Picture object was instantiated from 
an image file showing a beach scene with the same
dimensions. A fourth Picture object was instantiated with 
the same dimensions and an all-white image.

Methods of the SimplePicture class and the Pixel class 
were used in a pair of nested for loops to compare the 
color distance between corresponding pixels in the two 
photographs to within a specified tolerance. When the 
color distance between the two pixels exceeded a specified
threshold, the color of the pixel from the photograph
containing the tiger was copied to the all-white Picture 
object, replacing a white pixel. Otherwise, the color of 
the pixel from the beach image was copied to the all-white
Picture object.

The results were moderately good. However, lighting is 
critical and I didn't do anything special to control the 
lighting. As a result, a shadow of the tiger that was
barely noticeable on the blue sheet is very noticeable in 
the final product.

Note:  The idea for this program came directly from the 
book titled Introduction to Computing and Programming with
Java: A Multimedia Approach by Guzdial and Ericson. 

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/
import java.awt.Color;
public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  void run(){
    //Construct three new 341x256 Picture objects by
    // providing the names of image files as parameters
    // to the Pictue constructor.
    Picture pic1 = new Picture("ScaledBeach.jpg");
    Picture pic2 = new Picture("WithTiger.jpg");
    Picture pic3 = new Picture("WithoutTiger.jpg");
    
    //Construct an all-white 341x256 Picture object.
    Picture pic4 = new Picture(341,256);
    
    //Display all three Picture objects in the show
    // format.
    pic1.show();
    pic2.show();
    pic3.show();

    //Replace pixel colors in the all-white Picture object
    // with the colors from either the beach image or the 
    // tiger image.
    Pixel pixA;
    Pixel pixB;
    Pixel pixC;
    Pixel pixD;
    for(int row = 0;row < pic1.getHeight() - 1;row++){
      for(int col = 0;col < pic1.getWidth() - 1;col++){
        pixA = pic1.getPixel(col,row);
        pixB = pic2.getPixel(col,row);
        pixC = pic3.getPixel(col,row);
        pixD = pic4.getPixel(col,row);

        if(pixB.colorDistance(pixC.getColor()) > 50){
          //Replace white pixel with the pixel color from 
          // the tiger image.
          pixD.setColor(pixB.getColor());
        }else{
          //Replace the white pixel with pixel color from 
          // the beach image.
          pixD.setColor(pixA.getColor());
        }//end else
      }//end inner for loop
    }//end outer for loop

    //Display the final product using the show format.
    pic4.setTitle("Tiger on beach scene");
    pic4.show();
  }//end run
}//end class Runner

//34567890123456789012345678901234567890123456789012345678