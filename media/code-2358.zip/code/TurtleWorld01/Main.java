//34567890123456789012345678901234567890123456789012345678
//11/15/08 Ready to correct the right margin and publish.

/*Program TurtleWorld01
Copyright R.G.Baldwin 2009

This is an animated program that is designed to illustrate
various features of the Turtle and World classes.

The program places eight Turtle objects in a World object
known as the aquarium. One turtle is designated as the
leader and is given a red shell to make it highly visible.

An Image from an acquarium containing a starfish and some
other fish is used as a background picture for the
aquarium.

The body color and shell color of two other turtles are
set to yellow and orange to make them stand out from the
background.

The leader swims around randomly in the aquarium.

All eight turtles are initially placed in random locations
in the aquarium. However, the other seven turtles rapidly
converge on the leader and swim in formation following the
leader while attempting to avoid collisions with one
another.

Much of the time, the formation looks roughly like a
hexagon with six turtles forming the perimeter and one
turtle in the center.

Once started, the program will run until it is manually
terminated.

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/
import java.util.Random;
import java.util.Date;
import java.util.List;
import java.awt.Color;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  //Instantiate a random number generator.
  Random randGen = new Random(new Date().getTime());

  //Set the dimensions and instantiate a new world.
  int aquariumWidth = 450;
  int aquariumHeight = 338;
  World aquarium = new World(
                            aquariumWidth,aquariumHeight);

  //Get a reference to the list of turtles maintained by
  // the World object.
  List turtleList = aquarium.getTurtleList();
  //----------------------------------------------------//

  void run(){
    aquarium.setPicture(new Picture("aquarium.gif"));

    int numberTurtles = 8;

    //Place each turtle in a random location in the
    // aquarium.
    for(int cnt=0;cnt < numberTurtles;cnt++){
      int xCoor =
              Math.abs(randGen.nextInt() % aquariumWidth);
      int yCoor =
             Math.abs(randGen.nextInt() % aquariumHeight);
      new Turtle(xCoor,yCoor,aquarium);
    }//end for loop

    int angle = 0;//leader turning angle
    int leaderMove = 0;//leader move distance

    Turtle turtle = null;
    Turtle testTurtle = null;

    //First turtle in the list is the leader. Color it red
    // and get its length.
    Turtle leader = (Turtle)turtleList.get(0);
    leader.setShellColor(Color.RED);
    int turtleLength = leader.getHeight();

    //Change the shell and body colors of two of the other
    // turtles.
    turtle = (Turtle)turtleList.get(3);
    turtle.setBodyColor(Color.YELLOW);
    turtle.setShellColor(Color.ORANGE);
    turtle = (Turtle)turtleList.get(7);
    turtle.setBodyColor(Color.ORANGE);
    turtle.setShellColor(Color.YELLOW);

    while(true){//animation loop will run forever
      //Leader will move a random distance ranging from
      // half its length to 3/4 its length during each
      // animation cycle.
      leaderMove = (int)(turtleLength/2
                   + turtleLength*randGen.nextDouble()/4);
      //Leader will turn a random amount ranging from
      // -22.5 degrees to +22.5 degrees during each
      // animation cycle.
      angle = (int)(45*(randGen.nextDouble() - 0.5));

      //Process each turtle in the list during each
      // animation cycle.
      for(int cnt = 0;cnt < turtleList.size();cnt++){
        turtle = (Turtle)turtleList.get(cnt);
        turtle.penUp();//no turtle tracks allowed

        //Force the turtles to maintain some distanced
        // between them by comparing the distance from the
        // current turtle to every other turtle (other
        // than the leader) and making a correction when
        // too close.
        for(int cntr = 1;cntr < turtleList.size();cntr++){
          testTurtle = (Turtle)turtleList.get(cntr);
          //Don't process leader or self.
          if((testTurtle != turtle) && (cnt != 0)){
            int separation = (int)(turtle.getDistance(
              testTurtle.getXPos(),testTurtle.getYPos()));
              //Try to keep them separated by at least
              // twice the turtleLength center to center
              if(separation < 2*turtleLength){
                //Turn and move away from test turtle.
                turtle.turnToFace(testTurtle);
                turtle.turn(180);
                turtle.forward(turtleLength/3);
              }//end if
          }//end if
        }//end for loop on turtle separation

        if(cnt == 0){
          //This is the leader

          //Force the leader to bounce off the walls.
          int xPos = leader.getXPos();
          int yPos = leader.getYPos();

          if(xPos < turtleLength){
            leader.setHeading(90);
          }else if(xPos > aquariumWidth -turtleLength -2){
            leader.setHeading(-90);
          }//end else

          if(yPos < turtleLength){
            leader.setHeading(180);
          }else if(
                 yPos > aquariumHeight -turtleLength - 2){
            leader.setHeading(0);
          }//end else

          //Leader turns a random amount and moves a
          // random distance during each animation cycle.
          leader.turn(angle);
          leader.forward(leaderMove);
        }else{
          //This is not the leader.  Turn to face the
          // leader and move toward the leader.
          turtle.turnToFace(leader);
          int distanceToLeader = (int)(turtle.getDistance(
                      leader.getXPos(),leader.getYPos()));
          turtle.forward(distanceToLeader/10);
        }//end else

      }//end for loop processing all turtles

      //Control the animation speed.
      try{
        Thread.currentThread().sleep(100);
      }catch(InterruptedException ex){
      }//end catch
    }//end while loop

  }//end run
}//end class runner

//34567890123456789012345678901234567890123456789012345678