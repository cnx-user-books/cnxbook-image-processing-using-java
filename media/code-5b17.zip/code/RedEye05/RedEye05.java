//34567890123456789012345678901234567890123456789012345678
//02/12/09 ready to publish

/*File RedEye05 Copyright 2009 R.G.Baldwin

The purpose of this program is to demonstrate a
programming technique for correcting redeye problems in
digital photographs.

The program begins by displaying a GUI in the upper left
corner of the screen. At that point, the GUI contains a
text field for entry of the name of the image file to be
processed and some other user-input components, which are
disabled.  If the file is in the current directory, only
the file name and extension must be entered. Otherwise,
the full path and name and extension for the file must be
entered. Files of types jpg, bmp, and png are supported.

When the user enters the name of the image file into the
text field, the file is loaded into a Picture object. The
Picture object is displayed in the upper left corner of
the screen and the GUI is moved to a location immediately
below the Picture object.  At this point, the text field
is disabled and several buttons and radio buttons are
enabled.

The overall process is as follows. The user selects a
pixel in the eye containing the redeye problem by clicking
the mouse in the red area.

Then the user selects one of five radio buttons
specifying a zoom factor of 1, 2, 4, 8, or 16 and clicks a
button labeled Zoom. (A zoom factor of 16 is selected by
default at program startup.) This causes the area
surrounding the selected pixel to be enlarged by the
selected zoom factor and displayed in another window to
the right of the original picture object and the GUI. It
also causes the Zoom button and several other buttons in
the GUI to be disabled.

To correct the redeye problem in the selected eye, the
user surrounds the offending pixels in the zoomed image
with a circular lasso by dragging the mouse in the zoomed
image. Then the user clicks a button labeled Fix Redeye.

Clicking the Fix Redeye button causes an algorithm to be
executed that attempts to correct the redeye problem in
the area enclosed by the circular lasso. The algorithm
scans all of the pixels isolated by the circular lasso,
attempts to exclude any pixels that are not part of
the problem, and changes the color of the remaining pixels
to a dark gray with highlights preserved.

Clicking the mouse in the zoomed image at any time will
erase an existing lasso and undo the effects of having
clicked the Fix Redeye button.

The process can be repeated an many times as necessary
until the user is satisfied that the best fit of the
circular lasso and the offending pixels has been achieved.
Then the user clicks a button labeled Recombine Images to
cause the modified zoomed image to be reduced back to its
original size and merged back into the original image.

If the user is not happy with the results, the entire
process can be repeated by selecting the same eye again
and clicking the Zoom button. This will undo everything
back to the most recent commit operation (see below). If
the user is happy with the results for the eye currently
being processed, the user can accept the results by
clicking the Commit button and then perform the same
procedure on the other eye. Once committed, the pixels are
permanently changed in a backup image being held in memory
and the changes cannot be undone. However, at no time does
this program modify the original image file.

As explained above, the user can drag the mouse in the
zoomed image to create a circular lasso. An anchor point
is established when the user first presses the mouse
button to begin the drag operation.

The lasso can be created in any direction from the anchor
point.  The diameter of the lasso is equal to the distance
from the mouse pointer to the anchor point. The final size
and position of the lasso is established when the user
releases the mouse button and ends the drag operation.

Dragging the mouse outside the bounds of the image
causes the size of the lasso to continue to grow. However,
if the lasso extends outside the bounds of the zoomed
image, clicking the Fix Redeye button will have no effect.

The lasso remains on the screen until the user clicks the
zoomed image again with the mouse, clicks the Fix Redeye
button, clicks the Recombine Images button, or does
something else to cause the image to be repainted such as
minimizing and then restoring the zoomed image.

Clicking the Write button (when it is enabled) causes a
backup bmp file ofthe uncommitted image to be written into
the same directory from which the image file was read. The
five most recent backup files are saved. The names of the
backup files are the same as the name of the original
image file except that the characters BAKn are inserted
immediately before the extension. The character n is
replaced by a digit from 0 through 4.

The large X buttons in the upper right corner of both
image displays are disabled.  Clicking them does nothing.

The program is terminated by clicking the Quit button
(when it is enabled) or clicking the large X in the
upper right corner of the GUI at any time.

Before terminating, the program writes an output file
containing the final state of the uncommitted image in the
same format as the input file. The file is written into
the folder from which the original image file was read.
The name of the output file is the same as the name of the
input file except that the word FINAL is inserted
immediately before the extension.

The class files in Ericson's multimedia library must be
accessible to the program.

Tested using Windows Vista Home Premium Edition,
Java 1.6x, and the version of Ericson's multimedia library
contained in bookClasses10-1-07.zip.
*********************************************************/

import java.awt.Graphics;
import java.awt.Image;
import java.awt.BorderLayout;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseMotionAdapter;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;

import java.awt.image.BufferedImage;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.WindowConstants;

import java.io.File;

public class RedEye05 extends JFrame{
  //Create the components that are used to construct the
  // GUI.
  private JPanel mainPanel = new JPanel();
  private JPanel northPanel = new JPanel();
  private JPanel centerPanel = new JPanel();
  private JPanel southPanel = new JPanel();

  private JButton fixRedeyeButton =
                                new JButton("Fix Redeye");
  private JButton writeButton = new JButton("Write File");
  private JButton zoomButton = new JButton("Zoom");
  private JButton recombineButton =
                          new JButton("Recombine Images");
  private JButton quitButton = new JButton("Quit");
  private JButton commitButton = new JButton("Commit");

  private JRadioButton zoom1 = new JRadioButton("X1");
  private JRadioButton zoom2 = new JRadioButton("X2");
  private JRadioButton zoom4 = new JRadioButton("X4");
  private JRadioButton zoom8 = new JRadioButton("X8");
  private JRadioButton zoom16 =
                             new JRadioButton("X16",true);
  private JRadioButton overrideButton =
                             new JRadioButton("Override");
  private ButtonGroup buttonGroup = new ButtonGroup();

  private JTextField fileNameField =
                           new JTextField("RedEye05.jpg");

  private JLabel fileNameLabel = new JLabel("File Name:");

  //A reference to the original Picture object will be
  // stored here.
  private Picture backupPicture = null;
  //A reference to the picture that is zoomed will be
  // stored here.
  private Picture zoomBackupPicture = null;

  //A reference to a working copy of the original
  // Picture object will be stored here.
  private Picture displayPicture = null;
  //A refrence to a working copy of the zoomed picture
  // will be stored here.
  private Picture zoomDisplayPicture = null;

  //Miscellaneous working variables.
  private Graphics graphics = null;

  private Pixel pixel = null;
  private int writeCounter = 0;

  private String fileName = null;
  private String outputPath = null;
  private String extension = null;

  private int pictureWidth = 0;
  private int pictureHeight = 0;
  private int zoomPictureWidth = 0;
  private int zoomPictureHeight = 0;
  private int xMin = 0;
  private int yMin = 0;

  private int anchorX = 0;
  private int anchorY = 0;
  private int zoomAnchorX = 0;
  private int zoomAnchorY = 0;

  private int zoomDeltaX = 0;
  private int zoomDeltaY = 0;

  private int diameter = 0;
  private double angle = 0;

  private int leftInset = 0;
  private int topInset = 0;
  private int rightInset = 0;
  private int bottomInset = 0;

  private int zoomFactor = 16;

  private BufferedImage theImage = null;
  private BufferedImage zoomImage = null;

  private JFrame displayPictureFrame = null;
  private JFrame zoomPictureFrame = null;

  private Ellipse2D.Double ellipse = null;

  private Graphics2D g2d = null;

  private final double pi = Math.PI;//convenience constant
  //----------------------------------------------------//

  public static void main(String[] args){//main method
    new RedEye05();
  }//end main method
  //----------------------------------------------------//

  public RedEye05(){//constructor

    //All close operations are handled in a WindowListener
    // object.
    setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

    //Construct the GUI. Components are arranged in the
    // GUI from left to right, top to bottom in
    // approximately the order that they are used.
    mainPanel.setLayout(new BorderLayout());
    mainPanel.add(northPanel,BorderLayout.NORTH);
    mainPanel.add(centerPanel,BorderLayout.CENTER);
    mainPanel.add(southPanel,BorderLayout.SOUTH);

    //Add components to the north panel.
    northPanel.add(fileNameLabel);
    northPanel.add(fileNameField);
    northPanel.add(zoom1);
    northPanel.add(zoom2);
    northPanel.add(zoom4);
    northPanel.add(zoom8);
    northPanel.add(zoom16);
    buttonGroup.add(zoom1);
    buttonGroup.add(zoom2);
    buttonGroup.add(zoom4);
    buttonGroup.add(zoom8);
    buttonGroup.add(zoom16);
    northPanel.add(zoomButton);

    //Add components to the center panel
    centerPanel.add(overrideButton);
    centerPanel.add(fixRedeyeButton);
    centerPanel.add(recombineButton);

    //Add components to the south panel.
    southPanel.add(commitButton);
    southPanel.add(writeButton);
    southPanel.add(quitButton);

    //Disable the buttons until the user enters the file
    // name.
    zoom1.setEnabled(false);
    zoom2.setEnabled(false);
    zoom4.setEnabled(false);
    zoom8.setEnabled(false);
    zoom16.setEnabled(false);
    zoomButton.setEnabled(false);
    fixRedeyeButton.setEnabled(false);
    recombineButton.setEnabled(false);
    commitButton.setEnabled(false);
    writeButton.setEnabled(false);
    quitButton.setEnabled(false);

    //Set the size of the GUI and display it in the upper
    // left corner of the screen. It will be moved later
    // to a position immediately below the display of the
    // picture.
    getContentPane().add(mainPanel);
    pack();
    setVisible(true);

    //Request that the focus move to the text field where
    // the file name is to be entered.
    fileNameField.requestFocus();
    //--------------------------------------------------//

    //Register a listener on the text field. When the user
    // enters the file name in the text field, set
    // everything up properly so that the program will
    // function as an event-driven picture-manipulation
    // program until the user clicks the large X in the
    // upper-right of the GUI.
    fileNameField.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Disable the text field and its label to
          // prevent the user from entering anything else
          // into it and causing it to fire another event.
          fileNameField.setEnabled(false);
          fileNameLabel.setEnabled(false);

          //Get the file name from the text field and use
          // it to create a new Picture object.
          fileName = fileNameField.getText();
          backupPicture = new Picture(fileName);

          //Get information that will be used to write the
          // output files.
          String inputPath = new File(fileName).
                                        getAbsolutePath();
          int posDot = inputPath.lastIndexOf('.');
          outputPath = inputPath.substring(0,posDot);

          //Write the first copy of the output backup
          // file before any processing is done.
          backupPicture.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");

          //Get filename extension. It will be used later
          // to write the final output file.
          extension = inputPath.substring(posDot);

          //Decorate the GUI.
          setTitle("Copyright 2009, R.G.Baldwin");

          //Create the picture that will be used for
          // processing.
          //Note that the original image file is not
          // modified by this program.
          displayPicture = new Picture(backupPicture);

          //Display the picture.
          displayPicture.show();

          //Save a reference to the image. Also save the
          // width and height of the picture.
          theImage =
                (BufferedImage)(backupPicture.getImage());
          pictureWidth = backupPicture.getWidth();
          pictureHeight = backupPicture.getHeight();

          //Get and save a reference to the JFrame object
          // that contains the image.
          displayPictureFrame =
                   displayPicture.getPictureFrame().frame;

          //Get and save the insets for the JFrame object.
          leftInset =
                     displayPictureFrame.getInsets().left;
          topInset = displayPictureFrame.getInsets().top;
          rightInset =
                    displayPictureFrame.getInsets().right;
          bottomInset =
                   displayPictureFrame.getInsets().bottom;

          //Adjust the width of the GUI to match the width
          // of the display if possible. Then relocate the
          // GUI to a position immediately below the
          // display.
          //Establish the preferred size now that the
          // input file name has been entered.
          pack();
          int packedHeight = getHeight();
          int packedWidth = getWidth();
          if((pictureWidth + 7) >= packedWidth){
            //Make the width of the GUI the same as the
            // width of the display.
            setSize(pictureWidth + 7,packedHeight);
          }//Else, just leave the GUI at its current size.
          //Put the GUI in its new location immediately
          // below the display.
          setLocation(0,pictureHeight + 30);

          //Enable user input controls.
          zoom1.setEnabled(true);
          zoom2.setEnabled(true);
          zoom4.setEnabled(true);
          zoom8.setEnabled(true);
          zoom16.setEnabled(true);
          zoomButton.setEnabled(true);
          commitButton.setEnabled(true);
          writeButton.setEnabled(true);
          quitButton.setEnabled(true);

          //Disable the X-button on the display.
          displayPictureFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);
          //--------------------------------------------//

          /*
          Note that the following listener registration is
          actually inside the action listener that is
          registered on the text field. The code in the
          registration block can't be executed when the
          GUI is first constructed because a Picture
          object does not exist at that point in time.
          This code is executed after the user enters the
          image file name, the file has been read, and the
          Picture object referred to by displayPicture has
          been constructed.
          */
          displayPictureFrame.addMouseListener(
            new MouseAdapter(){
              public void mousePressed(MouseEvent e){
                //Draw a new copy of the image on the
                // display each time the user clicks the
                // image with the mouse. This creates a
                // fresh copy of the displayPicture. Note
                // however that the image being copied
                // may contain changes made earlier when
                // the user clicked the Commit button.
                graphics = displayPicture.getGraphics();
                graphics.drawImage(
                       backupPicture.getImage(),0,0,null);
                displayPicture.repaint();

                //Prepare some working variables.
                //Note that the reported coordinates for
                // a mouse press on the upper-left corner
                // of the image will not be reported
                // as 0,0 due to the top and left insets
                // of the JFrame.
                anchorX = e.getX();
                anchorY = e.getY();
                //Draw a small white cursor to mark the
                // location of the mouse press on the
                // image.
                drawCursor();
              }//end mousePressed
            }//end new MouseAdapter
          );//end addMouseListener
          //--------------------------------------------//
        //Now finish defining the action listener that is
        // registered on the text field.
        }//end actionPerformed
      }//end new ActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //The event handler on this button copies the backup
    // picture into displayPicture and then calls the zoom
    // method to produce a zoomed version of
    // displayPicture. The zoomed version makes it easier
    // to place a lass on around the offending redeye
    // pixels.
    zoomButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Get a fresh image in order to prevent the
          // current cursor from showing in the zoomed
          // version.
          //Note however that if the user previously
          // clicked the Commit button when a cursor was
          // showing in the picture, that cursor will have
          // been permanently written into the backup
          // picture.
          graphics = displayPicture.getGraphics();
          graphics.drawImage(
                       backupPicture.getImage(),0,0,null);
          displayPicture.repaint();

          //Call the zoom method to do all the hard work.
          zoom();
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //The event handler on this button calls a method that
    // changes the color of the offending redeye pixels
    // that are enclosed in a circular lasso.
    fixRedeyeButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          fixRedeye();
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //The event handler on this button restores the zoomed
    // image to the correct size and recombines it with
    // displayPicture.
    //There is probably a way to combine the two images
    // directly without having to loop, but I haven't
    // found it yet.
    recombineButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          //Return if there is no zoomDisplayPicture to
          // recombine with displayPicture.
          if(zoomDisplayPicture == null) return;

          //Enable and disable various buttons.
          zoomButton.setEnabled(true);
          commitButton.setEnabled(true);
          writeButton.setEnabled(true);
          quitButton.setEnabled(true);
          recombineButton.setEnabled(false);

          //Scale the zoomed image back down to the
          // correct size.
          zoomDisplayPicture = zoomDisplayPicture.scale(
                           1.0/zoomFactor,1.0/zoomFactor);

          //Merge the modified image into displayPicture
          for(int col = 0;col < pictureWidth - 1;col++){
            for(int row = 0;row < pictureHeight -1;row++){
              if((col >= xMin) &&
                 (col < (xMin + zoomPictureWidth)) &&
                 (row >= yMin) &&
                 (row < (yMin + zoomPictureHeight))){
                //Get access to the pixel that will be
                // modified.
                pixel = displayPicture.getPixel(col,row);
                //Modify the color of the pixel.
                pixel.setColor(
                     zoomDisplayPicture.getPixel(
                       col - xMin,row - yMin).getColor());
              }//end if
            }//end inner loop
          }//end outer loop

          //Release the resources that are held by the
          // zoomed picture and repaint displayPicture.
          zoomPictureFrame.dispose();
          displayPicture.repaint();
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //When the Commit button is clicked, the
    // displayPicture is committed for the long term by
    // copying it to the backup picture. Note that if this
    // button is clicked while a white cursor is showing
    // in displayPicture, that cursor will be committed
    // to the backup picture and cannot be removed
    // without starting all over.
    commitButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          backupPicture = new Picture(displayPicture);
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register an ActionListener on the writeButton.
    // Each time the user clicks the button, a backup bmp
    // file containing the current state of displayPicture
    // is written into the directory from which the
    // original image was read. The five most recent
    // backup filesare saved.
    //The names of the backup files are the same as the
    // name of the input file except that BAKn is
    // inserted immediately ahead of the extension
    // where n is a digit ranging from 0 to 4. The value
    // of n rolls over at 4 and starts back at 0.
    writeButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          displayPicture.write(outputPath
                       + "BAK" + writeCounter++ + ".bmp");
          //Reset the writeCounter if it exceeds 4 to
          // conserve disk space.
          if(writeCounter > 4){
            writeCounter = 0;
          }//end if
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //The behavior of the event handler on the quit button
    // is the same as the behavior of the event handler on
    // the large X in the upper right corner of the GUI
    // that is explained below.
    quitButton.addActionListener(
      new ActionListener(){
        public void actionPerformed(ActionEvent e){
          displayPicture.write(
                        outputPath + "FINAL" + extension);
          System.exit(0);
        }//end action performed
      }//end newActionListener
    );//end addActionListener
    //--------------------------------------------------//

    //Register a WindowListener that will respond when the
    // user clicks the large X in the upper-right corner
    // of the GUI. This event handler will write the final
    // state of displayPicture into an output file of the
    // same type as the original input file. The name will
    // be the same except that the word FINAL will be
    // inserted immediately ahead of the extension.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          displayPicture.write(
                        outputPath + "FINAL" + extension);
          System.exit(0);
        }//end windowClosing
      }//end new WindowAdapter
    );//end addWindowListener
    //--------------------------------------------------//


  }//end constructor
  //----------------------------------------------------//

  //This method creates a new Picture object that contains
  // a rectangular subimage of the pixels surrounding the
  // pixel selected by the user before clicking the Zoom
  // button.
  //The amount of zoom is determined by the radio button
  // that is selected. If the selected pixel is not close
  // to the edge of the image, the size of the zoomed
  // image will be 464x464 pixels. If the selected pixel
  // is close to one of the edges of the image, the zoomed
  // image will be smaller.
  private void zoom(){
    //Enable and disable various buttons.
    zoomButton.setEnabled(false);
    commitButton.setEnabled(false);
    writeButton.setEnabled(false);
    quitButton.setEnabled(false);
    recombineButton.setEnabled(true);

    //Establish the amount of zoom that will be applied.
    if(zoom1.isSelected()){
      zoomFactor = 1;
    }else if(zoom2.isSelected()){
      zoomFactor = 2;
    }else if(zoom4.isSelected()){
      zoomFactor = 4;
    }else if(zoom8.isSelected()){
      zoomFactor = 8;
    }else{
      zoomFactor = 16;
    }//end else

    //The numerator in the following fraction needs to be
    // divisible by 16 to maintain the best picture
    // quality when the image is later restored to its
    // original size.
    zoomPictureWidth = 464/zoomFactor;
    zoomPictureHeight = 464/zoomFactor;

    //Compute the coordinates for the upper-left corner
    // along with the width and height of the rectangular
    // sub image.
    xMin = anchorX - 232/zoomFactor - leftInset;

    if(xMin < 0){//Avoid negative coordinate values.
      xMin = 0;
    }//end if

    if((xMin + zoomPictureWidth) > (pictureWidth - 1)){
      zoomPictureWidth = pictureWidth - xMin - 1;
    }//end if

    yMin = anchorY - 232/zoomFactor - topInset;

    if(yMin < 0){
      yMin = 0;//Avoid negative coordinate values.
    }//end if

    if((yMin + zoomPictureHeight) > (pictureHeight - 1)){
      zoomPictureHeight = pictureHeight - yMin - 1;
    }//end if

    //Get the subimage that will be scaled up to create
    // the zoomed image.
    BufferedImage subImage = ((BufferedImage)(
                  displayPicture.getImage())).getSubimage(
                                       xMin,
                                       yMin,
                                       zoomPictureWidth,
                                       zoomPictureHeight);
    //Use the subimage to create two new Picture objects,
    // one for backup, and the other for a working
    // picture. Both are scaled up by zoomFactor. Display
    // the working picture.
    zoomBackupPicture = new Picture(subImage);
    zoomBackupPicture = zoomBackupPicture.scale(
                                   zoomFactor,zoomFactor);
    zoomDisplayPicture = new Picture(zoomBackupPicture);
    zoomDisplayPicture.show();

    //Get and save a reference to the JFrame object that
    // contains the working picture.
    zoomPictureFrame =
               zoomDisplayPicture.getPictureFrame().frame;

    //Disable the X-button on the zoom display.
    zoomPictureFrame.setDefaultCloseOperation(
                     WindowConstants.DO_NOTHING_ON_CLOSE);

    //Position the zoomed working picture at the top of
    // the screen immediately to the right of either
    // displayPicture or the GUI, whichever is wider.
    int zoomLocationX = 0;
    if((pictureWidth + leftInset + rightInset) >
                                         this.getWidth()){
      zoomLocationX =
                    pictureWidth + leftInset + rightInset;
    }else{
      zoomLocationX = this.getWidth();
    }//end else

    zoomPictureFrame.setLocation(zoomLocationX,0);

    //Get and save a reference to the object on which the
    // circular lasso will be drawn.
    g2d = (Graphics2D)(zoomPictureFrame.getGraphics());
    zoomImage =
            (BufferedImage)(zoomBackupPicture.getImage());

    //--------------------------------------------------//
    //Register a mousePressed listener and a mouseDragged
    // listener on the zoomPictureFrame. This is done here
    // because it couldn't be done before the zoomed
    // display picture was created.
    //--------------------------------------------------//

    // This mousePressed event handler creates a fresh
    // zoomed image using the zoomed backup picture and
    // establishes the anchor point for the ellipse that
    // will be drawn.
    zoomPictureFrame.addMouseListener(
      new MouseAdapter(){
        public void mousePressed(MouseEvent e){
          graphics = zoomDisplayPicture.getGraphics();
          graphics.drawImage(
                  zoomBackupPicture.getImage(),0,0,null);
          zoomDisplayPicture.repaint();

          zoomAnchorX = e.getX();
          zoomAnchorY = e.getY();
          zoomDeltaX = 0;
          zoomDeltaY = 0;

          //Enable the button that will be used to call
          // the method that modifies the colors of the
          // pixels enclosed by the lasso.
          fixRedeyeButton.setEnabled(true);

        }//end mousePressed
      }//end new MouseAdapter
    );//end addMouseListener
    //--------------------------------------------------//

    //This mouseDragged event handler will call a method
    // to draw a lasso when the mouse is dragged in the
    // zoomed image.
    zoomPictureFrame.addMouseMotionListener(
      new MouseMotionAdapter(){
        public void mouseDragged(MouseEvent e){
          drawLasso(e.getX(),e.getY());
        }//end mouseDragged
      }//end new MouseMotionAdapter
    );//end addMouseMotionListener
    //--------------------------------------------------//

  }//end zoom method
  //----------------------------------------------------//

  //This method draws a circular lasso that always
  // touches the anchor point established by the
  // mousePressed event handler.
  //This method is called each time the mouseDragged
  // event handler fires a MouseEvent.
  private void drawLasso(int x,int y){

    //The parameters x and y contain the coordinates of
    // the mouse pointer when the event was fired. Update
    // the diameter of the circular lasso.
    zoomDeltaX = x - zoomAnchorX;
    zoomDeltaY = y - zoomAnchorY;
    diameter = (int)Math.hypot(zoomDeltaX,zoomDeltaY);

    g2d.setColor(Color.GREEN);

    //Copy the entire image from the backup picture
    // stored in memory to erase any lassos drawn
    // earlier. This causes a single circular lasso to
    // appear to track the mouse position.
    g2d.drawImage(zoomImage,
                 zoomPictureFrame.getInsets().left,
                 zoomPictureFrame.getInsets().top,null);

    //Get the angle in radians that a line joining the
    // anchor point and the current mouse location makes
    // with a horizontal line going through the anchor
    // point. This is the angle that will be used in the
    // computations required to rotate the circular
    // ellipse around the anchor point while continually
    // touching the anchor point.
    angle =
       Math.atan2((double)zoomDeltaY,(double)zoomDeltaX);

    //Create and draw a circular ellipse that touches the
    // anchor point at all times.
    ellipse = new Ellipse2D.Double(
          //Compute and specify the coordinates of the
          // upper left corner of a box that will contain
          // the circular ellipse.
          zoomAnchorX-(
                  diameter/2-Math.cos(angle)*diameter/2),
          zoomAnchorY-(
                  diameter/2-Math.sin(angle)*diameter/2),
          //Specify the width and the height of the box.
          diameter,
          diameter);

    //Draw the ellipse.
    g2d.draw(ellipse);

  }//end drawLasso
  //----------------------------------------------------//

  //This method executes an algorithm that attempts
  // to exclude any pixels contained in the lasso that
  // aren't offending redeye pixels, and change the
  // color of the remaining pixels contained in the lasso
  // to gray while maintaining some of the highlights.
  // The method also smooths the edges of the lasso.
  private void fixRedeye(){
    //Protect against clicking the button before drawing
    // a lasso.
    if(ellipse == null) return;

    //Don't allow another event to be fired while this
    // method is being executed.
    fixRedeyeButton.setEnabled(false);

    //Working varibles.
    Color color = null;
    int red = 0;
    int green = 0;
    int blue = 0;

    for(int col = 0;
              col < zoomDisplayPicture.getWidth();col++){
      for(int row = 0;
             row < zoomDisplayPicture.getHeight();row++){
        //Change the color of the offending redeye pixels
        // inside the ellipse.
        //Note: It is necessary to compensate for the top
        // and left insets of the JFrame.
        if(ellipse.contains( col + leftInset,
                             row + topInset)){
          //The pixel is inside the lasso. Consider
          // changing its color.
          //Get a reference to the pixel.
          Pixel pixel =
                    zoomDisplayPicture.getPixel(col,row);
          //Test to see if the override button is
          // selected or the color of this pixel meets
          // the red eye criterion. If so, modify the
          // color. The new color is gray constructed
          // by averaging weighted versions of the
          // existing colors in order to reduce the red
          // content and also maintain the highlights.
          if((overrideButton.isSelected()) ||
                                       (isRedeye(pixel))){
            //This pixel is believed to be an offending
            // redeye pixel.
            color = pixel.getColor();
            red = color.getRed()/4;//Decrease red by 4.
            green = color.getGreen();
            blue = color.getBlue();
            //Create a gray from the average of the
            // modified red, the green, and the blue
            // color values.
            int avg = (int)((red + green + blue)/3.0);
            color = new Color(avg,avg,avg);//gray
            pixel.setColor(color);
          }//end if
        }//end if

      }//end inner loop
    }//end outer loop

    //Call a method to smooth the edges of the area
    // contained in the lasso.
    smoothEdges();

    zoomDisplayPicture.repaint();
  }//end fixRedeye method
  //----------------------------------------------------//

  //This method is called to test a pixel to determine if
  // it meets the redeye criterion. This is done by
  // identifying a 3D quasi-triangular wedge in the HSB
  // color model cone. Any pixel whose color is inside
  // the wedge is deemed to be an offending redeye pixel.
  private boolean isRedeye(Pixel pixel){
    //The following constants control the selectivity of
    // the algorithm relative to the decision as to
    // whether or not the color of an individual pixel
    // should be modified. Increasing the values towards
    // an upper limit of 1.0 makes the algorithm more
    // selective, in which case some problem pixels may
    // not have their color modified. Decreasing the
    // values can cause the program to modify the color
    // of pixels that aren't a part of the redeye
    // problem. Therefore, the values of these constants
    // are critical. Note, however, that they may not
    // work well for all digital photos, and an upgrade
    // with sliders that allow the user to specify the
    // values might be useful.
    final float hueThreshold = (float)0.95;
    final float saturationThreshold = (float)0.43;
    final float brightnessThreshold = (float)0.2;

    //Get pixel color as defined by the RGB color model.
    Color color = pixel.getColor();
    double red = (double)color.getRed();
    double green = (double)color.getGreen();
    double blue = (double)color.getBlue();

    //Get the color as defined by the HSB color model.
    float[] hsbvals = new float[3];
    Color.RGBtoHSB(
                  (int)red,(int)green,(int)blue,hsbvals);

    //For debug and test.
    /*
    System.out.println(hsbvals[0] + " " +
                       hsbvals[1] + " " +
                       hsbvals[2]);
    */
    //Test to see if the pixel color is in the wedge.
    //Recall that the hue values are cyclical so it is
    // necessary to test the hue as being close to 1.0
    // and  also as being close to 0.0;
    if(((hsbvals[0] > hueThreshold) ||
        (hsbvals[0] < (1.0 - hueThreshold))) &&
        (hsbvals[1] > saturationThreshold) &&
        (hsbvals[2] > brightnessThreshold)){
      return true;
    }//end if
    return false;
  }//end isRedeye
  //----------------------------------------------------//

  //The purpose of this method is to break up the harsh
  // outline of the circle used to change the color of
  // the pixels contained in the lasso.
  //This method averages the colors of a small group of
  // pixels at the left and right boundaries of the
  // lasso and sets the color of each pixel in the
  // group to the average color. The number of pixels in
  // the group is equal to the zoomFactor. The
  // probability is high that when the zoomed image is
  // restored to its original size, only one of these
  // pixels will be preserved.
  private void smoothEdges(){

    if(ellipse == null) return;

    //Smooth the left side of the circle.
    for(int row = 0;
             row < zoomDisplayPicture.getHeight();row++){
      for(int col = 0;
              col < zoomDisplayPicture.getWidth();col++){
        if(ellipse.contains(col + leftInset,
                            row + topInset)){
          averagePixels(col,row);
          //Break out of the inner loop and process the
          // nest row.
          col = zoomDisplayPicture.getWidth();
        }//end if
      }//end inner loop
    }//end outer loop

    //Smooth the right side of the circle. This code is
    // essentially the mirror image of the code used to
    // smooth the left side.
    for(int row = 0;
              row < zoomDisplayPicture.getHeight();row++){
      for(int col = zoomDisplayPicture.getWidth() - 1;
                                          col >= 0;col--){
        if(ellipse.contains(col + leftInset,
                            row + topInset)){
          averagePixels(col,row);
          col = -1;//Break out of inner loop.
        }//end if
      }//end inner loop
    }//end outer loop

  }//end smoothEdges
  //----------------------------------------------------//

  //This method computes the average color of a group of
  // contiguous pixels on the same row and sets the color
  // of all of the pixels in the group to the average
  // color.
  //The number of pixels in the group is equal to the
  // zoomFactor.
  private void averagePixels(int col,int row){
    //Avoid coordinate out of bounds problem.
    if((col - zoomFactor/2) < 0){return;}

    //Initialize accumulators.
    int redTotal = 0;
    int greenTotal = 0;
    int blueTotal = 0;

    //Compute the sums of the color values.
    for(int cnt = col - zoomFactor/2;
                         cnt < col + zoomFactor/2;cnt++ ){
      pixel = zoomDisplayPicture.getPixel(cnt,row);
      redTotal += pixel.getRed();
      greenTotal += pixel.getGreen();
      blueTotal += pixel.getBlue();
    }//end for loop

    //Now set the color of the pixels to the average
    // color.
    for(int cnt = col - zoomFactor/2;
                         cnt < col + zoomFactor/2;cnt++ ){
      pixel = zoomDisplayPicture.getPixel(cnt,row);
      pixel.setRed(redTotal/zoomFactor);
      pixel.setGreen(greenTotal/zoomFactor);
      pixel.setBlue(blueTotal/zoomFactor);
    }//end for loop
  }//end averagePixels
  //----------------------------------------------------//


  //This method draws a small white cursor when the user
  // clicks displayPicture with the mouse.
  private void drawCursor(){
    Graphics graphics = displayPicture.getGraphics();
    graphics.drawLine(anchorX - leftInset - 1,
                      anchorY - topInset,
                      anchorX - leftInset + 1,
                      anchorY - topInset);
    graphics.drawLine(anchorX - leftInset,
                      anchorY - topInset - 1,
                      anchorX - leftInset,
                      anchorY - topInset + 1);
    displayPicture.repaint();
  }//end drawCursor
  //----------------------------------------------------//
}//end class RedEye05



//34567890123456789012345678901234567890123456789012345678


