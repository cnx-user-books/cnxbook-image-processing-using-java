//345678901234567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=======================================================//
//Be sure to preserve < and > in html version
//05/14/06 Ready for publication.


/*File ImgMod36.java
Copyright 2006, R.G.Baldwin

There are many different ways to add watermarks to an 
image.  The purpose of this program is to illustrate the 
creation of five different types of visible watermarks:

1. A high intensity watermark in a single color 
   plane (red).
2. A watermark that is the same color as the original image
   pixels but twice as intense.
3. A watermark that is the same color as the original image
   pixels but with only half the intensity.
4. A watermark for which the alpha (transparency) value of
   the pixels is half of the original values.
5. A high intensity white watermark.

This program is designed to be driven by the image 
processing framework named ImgMod04a.  To run this 
program, enter the following at the command line.

java ImgMod04a ImgMod36 ImageFileName

where ImageFileName is the name of a .gif or .jpg file, 
including the extension.

The program displays a single frame on the screen.  The
frame contains the original image at the top and a replica 
of the original image with the watermarks added at the 
bottom.  The frame also contains a Replot button.
However, because the program does not allow the user to
enter parameters to modify the behavior of the program at
runtime, clicking the Replot button has little or no 
beneficial effect.

Each time that the program is run, or the Replot button
is clicked, the final image containing the watermarks is 
be written into a JPEG file named junk.jpg.  If a file 
having that name already exists in the current directory, 
it is overwritten.

This program contains an image processing method named 
processImg, which is executed by the program named 
ImgMod04a.  The method named processImg modifies the image 
pixels in five selected locations to add the watermarks 
described above.  Then it returns the modified image, which
is displayed by the program named ImgMod04a.

This program requires access to the following class files 
plus some inner classes that are defined inside the
following classes:

ImgIntfc04a.class
ImgMod04a.class
ImgMod36.class

Tested using J2SE 5.0 and WinXP.
**********************************************************/

class ImgMod36 implements ImgIntfc04a{
  
  //This method is required by ImgIntfc04a.  It is called
  // at the beginning of the run and each time thereafter
  // that the user clicks the Replot button on the Frame
  // contaning the images.  However, because this program
  // doesn't provide for user input, pressing the Replot
  // button is of no value.  It just displays the same
  // images again.
  public double[][][] processImg(double[][][] threeDPix){
    
    int imgRows = threeDPix.length;
    int imgCols = threeDPix[0].length;

    //Make a working copy of the 3D pixel array to avoid
    // making permanent changes to the original image data.
    double[][][] workingCopy = copy3DArray(threeDPix);
    
    //Declare a working plane.
    double[][] workingPlane;
    
    //Extract and process the alpha plane.
    workingPlane = extractPlane(workingCopy,0);
    addWatermark(workingPlane,0);
    //Insert the alpha plane back into the working array.
    insertPlane(workingCopy,workingPlane,0);

    //Extract and process the red color plane.
    workingPlane = extractPlane(workingCopy,1);
    addWatermark(workingPlane,1);
    insertPlane(workingCopy,workingPlane,1);

    //Extract and process the green color plane.
    workingPlane = extractPlane(workingCopy,2);
    addWatermark(workingPlane,2);
    insertPlane(workingCopy,workingPlane,2);

    //Extract and process the blue color plane.
    workingPlane = extractPlane(workingCopy,3);
    addWatermark(workingPlane,3);
    insertPlane(workingCopy,workingPlane,3);
    
    //The alpha plane and all three color planes have now
    // been processed.  The resusults are stored in the
    // working copy of the original pixel array.
    return workingCopy;

  }//end processImg method
  //-----------------------------------------------------//

  //The purpose of this method is to extract a color plane
  // from the double version of an image and to return it
  // as a 2D array of type double.
  public double[][] extractPlane(
                              double[][][] threeDPixDouble,
                              int plane){
    
    int numImgRows = threeDPixDouble.length;
    int numImgCols = threeDPixDouble[0].length;
    
    //Create an empty output array of the same
    // size as a single plane in the incoming array of
    // pixels.
    double[][] output =new double[numImgRows][numImgCols];

    //Copy the values from the specified plane to the
    // double array.
    for(int row = 0;row < numImgRows;row++){
      for(int col = 0;col < numImgCols;col++){
        output[row][col] =
                          threeDPixDouble[row][col][plane];
      }//end loop on col
    }//end loop on row
    return output;
  }//end extractPlane
  //-----------------------------------------------------//

  //The purpose of this method is to insert a double 2D
  // plane into the double 3D array that represents an
  // image.
  public void insertPlane(double[][][] threeDPixDouble,
                          double[][] colorPlane,
                          int plane){
    
    int numImgRows = threeDPixDouble.length;
    int numImgCols = threeDPixDouble[0].length;
    
    //Copy the values from the incoming color plane to the
    // specified plane in the 3D array.
    for(int row = 0;row < numImgRows;row++){
      for(int col = 0;col < numImgCols;col++){
        threeDPixDouble[row][col][plane] = 
                                      colorPlane[row][col];
      }//end loop on col
    }//end loop on row
  }//end insertPlane
  //-----------------------------------------------------//

  //This method copies a double version of a 3D pixel array
  // to an new pixel array of type double.
  double[][][] copy3DArray(double[][][] threeDPix){
    int imgRows = threeDPix.length;
    int imgCols = threeDPix[0].length;
    
    double[][][] new3D = new double[imgRows][imgCols][4];
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        new3D[row][col][0] = threeDPix[row][col][0];
        new3D[row][col][1] = threeDPix[row][col][1];
        new3D[row][col][2] = threeDPix[row][col][2];
        new3D[row][col][3] = threeDPix[row][col][3];
      }//end inner loop
    }//end outer loop
    return new3D;
  }//end copy3DArray
  //-----------------------------------------------------//

  //The purpose of this method is to add watermarks to
  // a 2D array of pixel data. There are many ways to
  // modify the pixel data to add watermarks.  This
  // method illustrates five of those ways.
  void addWatermark(double[][] plane,int color){
    int imgRows = plane.length;
    int imgCols = plane[0].length;
    
    //Create an array containing the basic watermark. The
    // watermark consists of the characters H2O described
    // by values of 1 and 0.
    int[][] watermark = new int[][]{
      {1,1,0,0,0,1,1, 0, 0,1,1,1,1,1,0, 0, 0,0,1,1,1,0,0},
      {1,1,0,0,0,1,1, 0, 1,1,1,1,1,1,1, 0, 0,1,1,1,1,1,0},
      {1,1,1,1,1,1,1, 0, 1,0,0,0,0,1,1, 0, 1,1,0,0,0,1,1},
      {1,1,1,1,1,1,1, 0, 0,0,1,1,1,1,0, 0, 1,1,0,0,0,1,1},
      {1,1,0,0,0,1,1, 0, 0,1,1,1,1,0,0, 0, 1,1,0,0,0,1,1},
      {1,1,0,0,0,1,1, 0, 1,1,0,0,0,0,0, 0, 1,1,0,0,0,1,1},
      {1,1,0,0,0,1,1, 0, 1,1,1,1,1,1,1, 0, 0,1,1,1,1,1,0},
      {1,1,0,0,0,1,1, 0, 1,1,1,1,1,1,1, 0, 0,0,1,1,1,0,0},
    };//end array
    
    int wmRows = watermark.length;
    int wmCols = watermark[0].length;
  
    for(int row = 0;row < wmRows;row++){
      for(int col = 0;col < wmCols;col++){
        if(watermark[row][col] == 1){//Ignore 0 values.
          
          //Place a high intensity watermark only in the
          // red color plane of the image.  Place it in the
          // upper left.
          if(color == 1){//Modify red plane only.
            plane[row+10][col+10] = 255.0;
          }//end if
          
          //Place a watermark in the upper right area. 
          // Make the the color of the watermark be the
          // same as the color of the image but twice as
          // intense.
          if(color != 0){//Don't modify the alpha plane.
            plane[row+10][imgCols-wmCols-10+col] =
                  plane[row+10][imgCols-wmCols-10+col]*2.0;
            plane[row+10][imgCols-wmCols-10+col] = 
               clamp(plane[row+10][imgCols-wmCols-10+col]);
          }//end if
         
          //Place a watermark in the center of the image. 
          // Make the intensity of each color to be half of
          // the original intensity.
          if(color != 0){//Don't modify alpha plane.
            plane[imgRows-(imgRows/2+wmRows/2)+ row]
                       [imgCols-(imgCols/2+wmCols/2)+col] =
                  plane[imgRows-(imgRows/2+wmRows/2)+row]
                    [imgCols-(imgCols/2+wmCols/2)+col]*0.5;
          }//end if
          
          //Place a watermark in the lower left.  Make the
          // transparency of each pixel to be half of its
          // original value.
          if(color == 0){//Modify alpha plane only.
            plane[imgRows-wmRows-10+row][col+10] = 
                  plane[imgRows-wmRows-10+row][col+10]/2.0;
          }//end if


          //Place a high intensity white watermark in the
          // bottom-right.
          if(color != 0){//Don't modify the alpha plane.
            plane[imgRows-wmRows-10+row]
                           [imgCols-wmCols-10+col] = 255.0;
          }//end if
          
        }//end if on watermark pixel value
      }//end inner loop on wmCols
    }//end outer loop on wmRows

  }//end addWatermark
  //-----------------------------------------------------//
  
  //The purpose of this method is to clamp the incoming
  // value to guarantee that it falls in the range from 0
  // to 255 inclusive.
  double clamp(double data){
    if(data > 255.0){
      return 255.0;
    }else if(data < 0.0){
      return 0.0;
    }else{
      return data;
    }//end else
  }//end clamp
  //-----------------------------------------------------//
}//end class ImgMod36