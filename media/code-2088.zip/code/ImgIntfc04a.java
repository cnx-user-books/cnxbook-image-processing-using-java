//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version.
//=======================================================//

/*File ImgIntfc04a.java
Copyright 2006, R.G.Baldwin

This is a modification to the interface named ImgIntfc04 
that eliminates the use of a second image-processing 
method. Otherwise, it is identical to the interface named 
ImgIntfc04.

The purpose of this interface is to declare the method 
required by image processing classes that are 
compatible with the program named ImgMod04a.java.

Tested using J2SE 5.0 under WinXP
**********************************************************/

interface ImgIntfc04a{
  double[][][] processImg(double[][][] input);
}//end ImgIntfc04a
//=======================================================//
