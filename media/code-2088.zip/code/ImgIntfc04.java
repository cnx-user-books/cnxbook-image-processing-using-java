//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version.
//=======================================================//
//04/30/06 ready to publish

/*File ImgIntfc04.java
Copyright 2006, R.G.Baldwin

The purpose of this interface is to declare the two
methods required by image processing classes that are 
compatible with the program named ImgMod04.java.

Note that this interface was modified relative to the 
interface named ImgIntfc02 to deal only with image pixel 
data as type double instead of type int.

Tested using J2SE 5.0 under WinXP
**********************************************************/

interface ImgIntfc04{
  ImgIntfc04Method01Output processImg01(
                                       double[][][] input);
                       
  double[][][] processImg02(double[][][] input);
}//end ImgIntfc04
//=======================================================//

//This class makes it possible for the method named
// processImg01 to return two references to 3D array object
// of type double.
class ImgIntfc04Method01Output{
  public double[][][] outputA;
  public double[][][] outputB;
  
  //Constructor
  public ImgIntfc04Method01Output(double[][][] outputA,
                                  double[][][] outputB){
    this.outputA = outputA;
    this.outputB = outputB;
  }//end constructor
}//end class ImgIntfc04Method01Output
//=======================================================//