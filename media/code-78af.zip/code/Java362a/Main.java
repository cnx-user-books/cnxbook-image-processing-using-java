//34567890123456789012345678901234567890123456789012345678
//11/30/2008 Ready to publish.

/*Program Java362a
Copyright R.G.Baldwin 2009

The purpose of this program is to support an explanation 
of the PictureExplorer class.

A Picture object having dimensions of 450x345 pixels is 
created. The the show method and the explore method are 
called on the object to produce two different screen 
displays of the picture.

The explore method simply creates a new object of the
PictureExplorer class.

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/

public class Main{
  public static void main(String[] args){
    //Construct a new 460x345 Picture object.
    Picture pix1 = new Picture("ScaledBeach460x345.jpg");
    pix1.show();//display the picture in the show format
    //Display the picture again in the explore format.
    pix1.explore();
  }//end main method
}//end class Main

//34567890123456789012345678901234567890123456789012345678