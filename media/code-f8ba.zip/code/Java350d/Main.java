//34567890123456789012345678901234567890123456789012345678
//11/12/08 Ready to publish
/*********************************************************
Program Java350c
Copyright R.G.Baldwin, 2009

This is an edge-detection program.

The program displays an image of a butterfly on a World 
object.  Then it traverses each horizontal row of pixels 
on the image, computing the color-distance between the 
color of the current pixel and the color of the pixel 
immediately to its right.  If the color-distance value is
greater than a specified threshold, the color of the 
left-most pixel in the pair is changed to black.  
Otherwise, it is changed to white.

The result is a picture resembling a pencil drawing of the
butterfly. Increasing the threashold value decreases the 
number of black pixels in the output.

Tested under Win XP using the Ericson multimedia library.
*********************************************************/
import java.awt.*;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main
}//end class Main
//======================================================//

class Runner{
  void run(){
    //Clipping threshold for edge detection.
//    int threshold = 18;
    int threshold = 54;
    
    //Create and display a Picture object using an image 
    // file in the current directory.
    Picture picture = new Picture("butterfly1.jpg");
    picture.show();
    
    //Create a new World object and assign the above 
    // Picture object to the World picture. Note that the
    // size of the world was set to be slightly smaller
    // than the size of the image, which is 422x497.
    int width = 420;
    int height = 493;
    World mars = new World(width,height);
    mars.setPicture(picture);

    //Loop and process each horizontal rows of pixels
    // to produce the edge-detected output.
    for(int row = 0;row < height;row++){
      edgeDetector(picture,row,width,threshold);
    }//end outer for loop
    
    //Force a repaint
    mars.setVisible(false);
    mars.setVisible(true);

  }//end run method
  //----------------------------------------------------//
  
  //This method computes the color-distances between each
  // pair of adjacent pixels on a specified row of a 
  // specified Picture object. If the value is greater 
  // than a specified threshold, the color of the 
  // left-most pixel in the pair is changed to black.
  // Otherwise, it is changed to white.
  void edgeDetector(
         Picture picture,int row,int width,int threshold){
    Pixel pix1;
    Pixel pix2;
    for(int cnt = 0;cnt < width-1;cnt++){
      //Get two adjacent pixels in the specified row.
      pix1 = picture.getPixel(cnt,row);
      pix2 = picture.getPixel(cnt + 1,row);
      //Get and save the color distance between the two
      // pixels.
      double distance = 
                      pix1.colorDistance(pix2.getColor());
      
      //Compare the color distance to the threshold and 
      // change pixel color accordingly.
      if(distance > threshold){
        pix1.setColor(Color.BLACK);
//        pix1.setColor(Color.RED);
//        pix1.setColor(Color.CYAN);
      }else{
        pix1.setColor(Color.WHITE);
/*
        //Invert colors below threshold
        int red = pix1.getRed();
        int green = pix1.getGreen();
        int blue = pix1.getBlue();
        pix1.setColor(new Color(255-red,255-green,255-blue));
*/
      }//end else
      
    }//end for loop
  }//end edgeDetector
  
}//end class Runner

//34567890123456789012345678901234567890123456789012345678