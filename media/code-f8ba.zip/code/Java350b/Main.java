//34567890123456789012345678901234567890123456789012345678
//Ready to publish: 11/12/08
/*********************************************************
Program Java350b
Copyright R.G.Baldwin, 2009

The purpose of this program is to plot and display the 
values resulting from computing the color-distances
between white pixels and black pixel.

The program also illustrates the usefulness of a Turtle 
object for plotting wiggly-line data.

Four groups of black pixels are placed in a white picture.
The first group is a single black pixel on a horizontal 
row of pixels.  The second group consists of two adjacent 
black pixels on a horizontal row of pixels.  The third 
group consists of three adjacent black pixels, and the 
fourth group consists of four adjacent black pixels.

The color-distance between adjacent pixels is computed, 
plotted, and displayed for each row of pixels containing 
black pixels.

The color distance between a white pixel and a black pixel
is 441.67.

More specifically, the program traverses four specific 
rows of pixels on the image, computing the color distance 
between the color of the current pixel and the color of 
the pixel immediately to its right.  The distance values 
are saved in an array of type double.  Then the program 
uses a turtle to plot the distance values as a wiggly 
line across the image with the baseline of the plot being 
one pixel above the row of pixels for which the distance 
values were computed.

The peaks in the wiggly line correspond to locations on 
the row of pixels where there are abrupt changes in the 
color values.

Tested under Win XP using the Ericson multimedia library.
*********************************************************/
import java.awt.*;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main
}//end class Main
//======================================================//

class Runner{
  void run(){
    
    //Create a new World object containing a default white
    // Picture object.
    int width = 420;
    int height = 493;
    World mars = new World(width,height);
    
    //Get a reference to the all-white picture that is 
    // contained in the World object by default.
    Picture picture = mars.getPicture();
    
    //Create a new Turtle object and place it in the 
    // default location at the center of the world. Make 
    // the turtle invisible and set its pen color to RED.
    Turtle joe = new Turtle(mars);
    joe.setVisible(false);
    joe.setPenColor(Color.RED);

    //Create an array for storage of the color-distance 
    // data.
    double[] distance = new double[width];
    
    //Loop and process four horizontal rows of pixels.
    for(int row = height/4,num = 1;row < height;
                                   row += height/4,num++){
      
      //Place adjacent black pixels at the center of each 
      // row with the number of pixels ranging from 1 on 
      // the first row to 4 on the last row.
      Pixel pix = null;
      for(int cntr = 0;cntr < num;cntr++){
        pix = picture.getPixel(cntr + width/2,row);
        pix.setColor(Color.BLACK);
      }//end for loop
      
      //Populate the array with the color-distances 
      // between adjacent pixels for the specified row.
      getColorDistance(picture,row,distance);
    
      //Baseline for wiggly line plot.
      int baseline = row-1;
      
      //Move the turtle to the right edge of the World
      // one pixel above the value of the row. Don't leave
      // a turtle track in the process.
      joe.setPenDown(false);
      joe.moveTo(width,baseline);
      joe.setPenDown(true);
      
      //Draw a baseline by moving turtle to the left side
      // of the world.
      joe.moveTo(0,baseline);
      
      //Draw the wiggly line. Change the sign of the
      // distance values to cause positive values to
      // peak upward on the screen.  Scale the distance
      // values down by a factor of 4. This should result
      // in a peak value of 110 pixels
      for(int cnt = 0;cnt < distance.length;cnt++){
        joe.moveTo(cnt+1,baseline-(int)(distance[cnt]/4));
      }//end inner for loop
    
    }//end outer for loop

  }//end run method
  //----------------------------------------------------//
  
  //This method populates an array of type double with the
  // color distances between adjacent pixels on a
  // specified row of a specified Picture object.
  void getColorDistance(
               Picture picture,int row,double[] distance){
    Pixel pix1;
    Pixel pix2;
    for(int cnt = 0;cnt < distance.length-1;cnt++){
      //Get two adjacent pixels in the specified row.
      pix1 = picture.getPixel(cnt,row);
      pix2 = picture.getPixel(cnt + 1,row);
      //Get and save the color distance between the two
      // pixels.
      distance[cnt] = pix1.colorDistance(pix2.getColor());
    }//end for loop
  }//end getColorDistance
  
}//end class Runner

//34567890123456789012345678901234567890123456789012345678