//34567890123456789012345678901234567890123456789012345678

/*********************************************************
Program Java350a
Copyright R.G.Baldwin, 2009
This program creates and displays a 3D color cube that 
displays various combinations of red, green, and blue on 
the top, the front, and the right-most side of the cube.

The purpose of the program is to provide a platform for 
discussing the concept of the distance between two colors
as points in 3D space.  The positive red axis is toward 
the right.  The positive green axis is up, and the 
positive blue axis is toward the viewer.  The type of 
projection that was used is a Cavalier projection with the
angle phi equal to 45 degrees.  

See http://local.wasp.uwa.edu.au/~pbourke/geometry
/classification/ for more information on  projection 
types.

Tested under Win XP using the Ericson multimedia library.
*********************************************************/
import java.awt.*;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main
}//end class Main
//======================================================//

class Runner{
  final double sin45 = 0.7071067811865476;
  final double cos45 = 0.7071067811865476;
  final int width = 460;
  final int height = 460;
  final int originX = (int)(0.42*width);
  final int originY = (int)(0.59*height);
  World mars = null;
  //----------------------------------------------------//
  
  //The purpose of each of the following two methods is to
  // project a point in 3D space onto a 2D surface for 
  // display using a Cavalier projection with the angle 
  // phi equal to 45 degrees. This method returns the 
  // 2D x-coordinate where the point is to be plotted.
  int p3dX(int red,int green,int blue){
    return (int)(red-blue*sin45);
  }//end p3Dx
  //----------------------------------------------------//
  
  //This method returns the 2D y-coordinate where the 
  // point is to be plotted.
  int p3dY(int red,int green,int blue){
    //Reverse the sign to account for the fact that
    // positive y-coordinates go down the screen
    return -(int)(green-blue*cos45);
  }//end p3dY
  //----------------------------------------------------//
  
  void run(){
    //Create a new World object.
    mars = new World(width,height);
    
    //Place a new turtle on the right edge of the World 
    // and make it invisible.
    Turtle joe = new Turtle(width,originY,mars);
    joe.setVisible(false);
    
    //Draw colored axes and black lines that outline the 
    // cube.
    drawLines(joe);
   
    //Paint the top of the cube. Begin by getting a 
    // reference to the Picture object that belongs to the
    // world by default.
    Picture picture = mars.getPicture();
    
    Pixel pixel = null;//a working variable
    
    for(int blu = 0;blu < 256;blu++){
      for(int rd = 0;rd < 256;rd++){
        //Hold the green coordinate constate.
        int grn = 255;
        pixel = picture.getPixel(p3dX(rd,grn,blu)+originX,
                                p3dY(rd,grn,blu)+originY);
        pixel.setColor(new Color(rd,grn,blu));
      }//end for loop
    }//end outer loop
    
    //Paint the front surface of the cube
    for(int grn = 0;grn < 256;grn++){
      for(int rd = 0;rd < 256;rd++){
        int blu = 255;//hold the blue coordinate constant.
        pixel = picture.getPixel(p3dX(rd,grn,blu)+originX,
                                p3dY(rd,grn,blu)+originY);
        pixel.setColor(new Color(rd,grn,blu));
      }//end for loop
    }//end outer loop
    
    //Paint the right-most surface of the cube
    for(int grn = 0;grn < 256;grn++){
      for(int blu = 0;blu < 256;blu++){
        int rd = 255;//hold the red coordinate constant
        pixel = picture.getPixel(p3dX(rd,grn,blu)+originX,
                                p3dY(rd,grn,blu)+originY);
        pixel.setColor(new Color(rd,grn,blu));
      }//end for loop
    }//end outer loop
    
    //Force the world to repaint itself.
    mars.setVisible(false);
    mars.setVisible(true);
  }//end run
  //----------------------------------------------------//
  
  //The purpose of this method is to draw colored axes 
  // that represent the 3D space and black lines that 
  // outline the cube. This is accomplished with turtle 
  // tracks.  Note that because of the sequence in which 
  // the world repaints itself, with the historical turtle
  // tracks being drawn last, these lines will be drawn on
  // top of the colored pixels that color the sides of the
  // cube. This makes it look like the sides of the cube 
  // are transparent. I put this code in a separate method
  // simply to provide better organization for the 
  // program.
  void drawLines(Turtle joe){
    //Draw red x-axis by moving the turtle from the right
    // edge to the origin of the 3D world.
    joe.setPenWidth(2);//Draw the colored axes wide.
    joe.setPenColor(Color.RED);
    joe.moveTo(p3dX(0,0,0)+originX,p3dY(0,0,0)+originY);
    
    //Draw green y-axis by moving the turtle to near the
    // top edge of the 3D world and then return to the
    // origin.
    joe.setPenColor(Color.GREEN);
    joe.moveTo(p3dX(0,265,0)+originX,
               p3dY(0,265,0)+originY);
    joe.moveTo(p3dX(0,0,0)+originX,
               p3dY(0,0,0)+originY);
    
    //Draw blue axis and return turtle to the origin of
    // the 3D world.
    joe.setPenColor(Color.BLUE);
    joe.moveTo(p3dX(0,0,265)+originX,
               p3dY(0,0,265)+originY);
    joe.moveTo(p3dX(0,0,0)+originX,
               p3dY(0,0,0)+originY);
    
    joe.setPenWidth(1);//Draw narrow black lines.
    joe.setPenColor(Color.BLACK);
    
    //Draw four lines that outline the base of a cube. The
    // size of the cube is 256 pixels on each side.
    joe.moveTo(p3dX(0,0,255)+originX,
               p3dY(0,0,255)+originY);
    joe.moveTo(p3dX(255,0,255)+originX,
               p3dY(255,0,255)+originY);
    joe.moveTo(p3dX(255,0,0)+originX,
               p3dY(255,0,0)+originY);
    joe.moveTo(p3dX(0,0,0)+originX,
               p3dY(0,0,0)+originY);
    
    //Move up and draw four lines that outline the top of
    // the cube.
    joe.moveTo(p3dX(0,255,0)+originX,
               p3dY(0,255,0)+originY);
    joe.moveTo(p3dX(0,255,255)+originX,
               p3dY(0,255,255)+originY);
    joe.moveTo(p3dX(255,255,255)+originX,
               p3dY(255,255,255)+originY);
    joe.moveTo(p3dX(255,255,0)+originX,
               p3dY(255,255,0)+originY);
    joe.moveTo(p3dX(0,255,0)+originX,
               p3dY(0,255,0)+originY);
    
    //Draw three vertical lines at the corners.
    joe.moveTo(p3dX(0,255,255)+originX,
               p3dY(0,255,255)+originY);
    joe.moveTo(p3dX(0,0,255)+originX,
               p3dY(0,0,255)+originY);
    
    joe.moveTo(p3dX(255,0,255)+originX,
               p3dY(255,0,255)+originY);
    joe.moveTo(p3dX(255,255,255)+originX,
               p3dY(255,255,255)+originY);
    
    joe.moveTo(p3dX(255,255,0)+originX,
               p3dY(255,255,0)+originY);
    joe.moveTo(p3dX(255,0,0)+originX,
               p3dY(255,0,0)+originY);
  
  }//end drawLines
  
}//end class Runner

//34567890123456789012345678901234567890123456789012345678