//34567890123456789012345678901234567890123456789012345678
//Ready to publish: 11/12/08
/*********************************************************
Program Java350c
Copyright R.G.Baldwin, 2009

The purpose of this program is to provide a platform for 
explaining the behavior of edge-detection programs.

The program displays an image of a butterfly on a World 
object.  Then it traverses four specific horizontal rows 
of pixels on the image, computing the color distance 
between the color of the current pixel and the color of 
the pixel immediately to its right.  The distance values 
are saved in an array of type double.  Then the program 
uses a turtle to plot the distance values as a wiggly line
across the image with the baseline of the plot being one 
pixel above the row of pixels for which the distance 
values were computed.

The peaks in the wiggly line correspond to locations on 
the row of pixels where there are abrupt changes in the 
color values. The color-distance values are plotted to the
same scale as the values plotted in the program named 
Java350b.  Therefore, those values, which show the maximum
distance between a white pixel and a black pixel, can be 
used to visually calibrate the color distances associated 
with color changes in the butterfly image.

This technique is useful for doing edge detection.

Tested under Win XP using the Ericson multimedia library.
*********************************************************/
import java.awt.*;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main
}//end class Main
//======================================================//

class Runner{
  void run(){
    //Create a Picture object using an image file in the
    // current directory.
    Picture picture = new Picture("butterfly1.jpg");
    
    //Create a new World object and assign the above 
    // Picture object to the World picture. Note that the 
    // size of the world was matched to the size of the 
    // image.
    int width = 420;
    int height = 493;
    World mars = new World(width,height);
    mars.setPicture(picture);
    
    //Create a new Turtle object and place it in the 
    // default location at the center of the world. Make 
    // the turtle invisible and set its pen color to 
    // RED.
    Turtle joe = new Turtle(mars);
    joe.setVisible(false);
    joe.setPenColor(Color.RED);

    //Create an array for storage of the color-distance 
    // data.
    double[] distance = new double[width];
    
    //Loop and process four horizontal rows of pixels.
    for(int row = height/4;row < height;row += height/4){
      
      //Populate the array with the color-distances 
      // between adjacent pixels for the specified row.
      getColorDistance(picture,row,distance);
    
      //Baseline for wiggly line plot.
      int baseline = row-1;
      
      //Move the turtle to the right edge of the World
      // one pixel above the value of the row. Don't leave
      // a turtle track in the process.
      joe.setPenDown(false);
      joe.moveTo(width,baseline);
      joe.setPenDown(true);
      
      //Draw a baseline by moving the turtle to the left 
      // side of the world.
      joe.moveTo(0,baseline);
      
      //Draw the wiggly line. Change the sign of the
      // distance values to cause positive values to
      // peak upward on the screen.  Scale the distance
      // values down by a factor of 4.
      for(int cnt = 0;cnt < distance.length-1;cnt++){
        joe.moveTo(cnt+1,baseline-(int)(distance[cnt]/4));
      }//end inner for loop
    
    }//end outer for loop

  }//end run method
  //----------------------------------------------------//
  
  //This method populates an array of type double with the
  // color distances between adjacent pixels on a
  // specified row of a specified Picture object.
  void getColorDistance(
               Picture picture,int row,double[] distance){
    Pixel pix1;
    Pixel pix2;
    for(int cnt = 0;cnt < distance.length-1;cnt++){
      //Get two adjacent pixels in the specified row.
      pix1 = picture.getPixel(cnt,row);
      pix2 = picture.getPixel(cnt + 1,row);
      //Get and save the color distance between the two
      // pixels.
      distance[cnt] = pix1.colorDistance(pix2.getColor());
    }//end for loop
  }//end getColorDistance
  
}//end class Runner

//34567890123456789012345678901234567890123456789012345678