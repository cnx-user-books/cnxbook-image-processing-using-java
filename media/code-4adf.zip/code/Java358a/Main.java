//34567890123456789012345678901234567890123456789012345678
//11/25/08 Ready to publish.

/*Program Java358a
Copyright R.G.Baldwin 2009

The purpose of this program is to illustrate the use of
the following methods of the Picture class:

Picture scale(double xFactor, double yFactor)
Rectangle2D getTransformEnclosingRect(
                                    AffineTransform trans)
void copyPicture(SimplePicture sourcePicture)

In addition, the program illustrates the following
constructor for the Picture class:

SimplePicture(SimplePicture copyPicture)

The program defines two methods named rotatePicture and
translatePicture that are patterned after the scale method
of the picture class. Descriptions of the two methods are
provided with comments at the beginning of the method.

The program begins by creating and showing a Picture
object based on a specified image file in the current
directory.

Then the program illustrates the use of the scale method,
the rotatePicture method, and the translatePicture
method in that order. The Picture object returned from
each of these methods is displayed.

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  void run(){
    //Construct a new 341x256 Picture object by providing
    // the name of an image file as a parameter to the
    // Picture constructor. Note that the image file is
    // located in the current directory.
    Picture pixA = new Picture("ScaledBeach.jpg");
    pixA.setTitle("pixA");
    pixA.show();

    //Call the scale method on pixA to create a new
    // Picture object that contains a scaled version of
    // pixA, scaled by 0.5 in both dimensions. Show the
    // new scaled picture.
    Picture pixB = pixA.scale(0.5,0.5);
    pixB.setTitle("pixB");
    pixB.show();

    //Create a new Picture object that is a copy of pixA.
    Picture pixC = new Picture(
                        pixA.getWidth(),pixA.getHeight());
    pixC.copyPicture(pixA);
    //Call the rotatePicture method to create and return a
    // new Picture object that contains the image from
    // pixC rotated by 30-degrees clockwise around its
    // center and translated to the center of the new
    // Picture object.
    //The size of the new Picture object is such that each
    // corner of the rotated picture touches the edge of
    // the new Picture just inside the border of the
    // JFrame.
    pixC = rotatePicture(pixC,30.0);
    pixC.setTitle("pixC");
    pixC.show();

    //Call the translatePicture method to create and
    // return a new Picture object that contains the
    // image from pixA translated by 20 pixels in the
    // x-dimension and 30 pixels in the y-dimension.
    // The size of the new Picture object is such that
    // there is white space above and to the left of the
    // translated image where the amount of whitespace
    // equals the space that was vacated by translating
    // the image to the right and down.
    Picture pixD = translatePicture(pixA,20,30);
    pixD.setTitle("pixD");
    pixD.show();

  }//end run method
  //----------------------------------------------------//

  //This method accepts a reference to a Picture object
  // along with a rotation angle in degrees. It creates
  // and returns a new Picture object that is of the
  // correct size to contain and display the incoming
  // picture after it has been rotated around its center
  // by the specified rotation angle and translated to the
  // center of the new Picture object.
  public Picture rotatePicture(Picture pix,double angle){

    //Set up the rotation transform
    AffineTransform rotateTransform =
                                    new AffineTransform();
    rotateTransform.rotate(Math.toRadians(angle),
                           pix.getWidth()/2,
                           pix.getHeight()/2);

    //Get the required dimensions of a rectangle that will
    // contain the rotated image.
    Rectangle2D rectangle2D =
           pix.getTransformEnclosingRect(rotateTransform);
    int resultWidth = (int)(rectangle2D.getWidth());
    int resultHeight = (int)(rectangle2D.getHeight());

    //Set up the translation transform that will translate
    // the rotated image to the center of the new Picture
    // object.
    AffineTransform translateTransform =
                                    new AffineTransform();
    translateTransform.translate(
                      (resultWidth - pix.getWidth())/2,
                      (resultHeight - pix.getHeight())/2);

    //Concatenate the two transforms so that the image
    // will first be rotated around its center and then
    // translated to the center of the new Picture object.
    translateTransform.concatenate(rotateTransform);
    //Create a new Picture object to contain the results
    // of the transformation.
    Picture result = new Picture(
                                resultWidth,resultHeight);

    //Get the graphics context of the new Picture object,
    // apply the transform to the incoming picture and
    // draw the transformed picture on the new Picture
    // object.
    Graphics2D g2 = (Graphics2D)result.getGraphics();
    g2.drawImage(pix.getImage(),translateTransform,null);

    return result;
  }//end rotatePicture
  //----------------------------------------------------//

  //The following method accepts a reference to a Picture
  // object along with positive x and y translation
  // values. It creates and returns a new Picture object
  // that contains a translated version of the original
  // image with whitespace to the left of and/or above the
  // translated image. If either translation value is
  // negative, the method simply returns a reference to a
  // copy of the original picture.
  public Picture translatePicture(
                         Picture pix,double tx,double ty){
    if((tx < 0.0) || (ty < 0.0)){
      //Negative translation values are not supported.
      // Simply return a reference to a copy of the
      // incoming picture. Note that this constructor
      // creates a new picture by copying the image from
      // an existing picture.
      return new Picture(pix);
    }//end if

    //Set up the tranform
    AffineTransform translateTransform =
                                    new AffineTransform();
    translateTransform.translate(tx,ty);

    //Compute the size of a rectangle that is of
    // sufficient size to contain and display the
    // translated image.
    int pixWidth = pix.getWidth() + (int)tx;
    int pixHeight = pix.getHeight() + (int)ty;

    //Create a new picture object that is the correct
    // size.
    Picture result = new Picture(pixWidth,pixHeight);

    //Get the graphics2D object to draw on the result.
    Graphics2D g2 = (Graphics2D)result.getGraphics();

    //Draw the translated image from pix onto the new
    // Picture object, applying the transform in the
    // process.
    g2.drawImage(pix.getImage(),translateTransform,null);

    return result;
  }//end translatePicture
  //----------------------------------------------------//

}//end class Runner

//34567890123456789012345678901234567890123456789012345678