//34567890123456789012345678901234567890123456789012345678
//Be sure to preserve < and > in html version
//======================================================//


//07/05/07 Ready to publish.


/*File ImgMod42.java
Copyright 2007, R.G.Baldwin

The purpose of this class is to illustrate the use of the 
ConvolveOp filter class of the Java 2D API.

See general comments in the class named ImgMod038 in the
lesson named "Using the Java 2D LookupOp Filter Class to 
Process Images".

This class is compatible with the use of the driver 
program named ImgMod05.

The driver program named ImgMod05 displays the original 
and the modified image.  It also writes the modified image
into an output file in JPEG format.  The name of the 
output file is junk.jpg and it is written into the current
directory.

Image processing programs such as this one may provide a 
GUI for data input making it possible for the user to 
modify the behavior of the image processing method each 
time the Replot button is clicked.  Such a GUI is provided
for this program.

Enter the following at the command line to run this 
program:

java ImgMod05 ImgMod42 ImageFileName

If the program is unable to load the image file within ten
seconds, it will abort with an error message.

This program convolves a user-specified image with a 
user-specified two-dimensional convolution filter having 
up to 81 filter coefficients, nine along each dimension.

A 9x9 convolution filter is used to filter the image each 
time the Replot button is clicked.  The filter is 
initialized with a value of 1.0 at the center and values 
of 0.0 in all other locations.  The user specifies the 
convolution filter coefficient values by changing the 
individual filter values. It is not necessary for the user
to change all 81 filter values.  Filter coefficients
having a value of 0.0 contribute nothing to the output.

The program creates a GUI for user iput containing:
User instructions
Two radio buttons used to select the type of treatment 
 given to the edge of the image during the convolution 
 process.
Text fields used to specify the values of a 9x9 
 convolution filter.

The convolution filter values are initialized so as to 
simply pass the input image through to the output 
without modification..

It is unclear in the documentation what happens to the 
color value if the value resulting from the convolution
process falls outside the range from 0 to 255.  However, 
observation of the results suggests that those values are 
clipped at 0 and 255.

Tested using J2SE 5.0 under WinXP.
*********************************************************/

import java.awt.image.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ImgMod42 extends Frame implements ImgIntfc05{
  
  //Components used to construct the main panel.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel mainPanel = new Panel();//main control panel
  
  //A pair of radio buttons used to specify the treatment
  // of the pixels at the edge of the image.
  CheckboxGroup radioButtonGroup = new CheckboxGroup();
  Checkbox edgeNoOp = new Checkbox(
     "Copy Edge Pixels Unmodified",radioButtonGroup,true);
  Checkbox edgeZeroFill = new Checkbox(
          "Zero-Fill Edge Pixels",radioButtonGroup,false);

  //An array of TextField objects for specifying
  // matrix/convolution filter values.  Normally, I would
  // refer to the data entered into these TextField
  // objects simply as the filter.  However, in order to
  // distiguish between the convolution filter, and the
  // filter method of the ConvolveOp class, in most cases,
  // I will refer to the data as a matrix.
  TextField[][] matrixField = new TextField[9][9];

  //The following Label is used to notify of data entry
  // errors.
  String okMessage = "No data entry errors detected.";
  Label errorMsg = new Label(okMessage);
  //----------------------------------------------------//
  
  //This is the primary constructor.  It calls another
  // method to construct the main panel so as to separate
  // the construction of the GUI into easily
  // understandable units.
  ImgMod42(){//constructor
  
    constructMainPanel();
    add(mainPanel);

    setTitle("Copyright 2007, R.G.Baldwin");
    setBounds(555,0,470,400);
    setVisible(true);

    //Define a WindowListener to terminate the program.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(1);
        }//end windowClosing
      }//end windowAdapter
    );//end addWindowListener
  }//end constructor
  //----------------------------------------------------//
  
  //This method constructs the main panel containing all
  // of the controls.  This method is called from the
  // primary constructor..
  void constructMainPanel(){
    mainPanel.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the panel.
    // This text appears in a disabled text area at the
    // top of the panel.
    String text ="CONVOLUTION\n"
      + "Enter convolution filter values into the text "
      + "fields and click the Replot button.\n\n"
      + "It is not necessary to enter a value into every "
      + "text field.\n\n"
      + "The filter must have at least one non-zero "
      + "value.  Otherwise, a single filter value will "
      + "be automatically set to 0.01, preventing an "
      + "Exception, but causing the output image to be "
      + "very dark";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.  Therefore, it will always fill the
    // available horizontal space.
    TextArea textArea = new TextArea(text,7,1,
                                TextArea.SCROLLBARS_NONE);
    mainPanel.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);
    
    //Create the panel that contains the radio buttons
    // and the text fields into which the user enters
    // convolution coefficient values.
    Panel controlPanel = new Panel();
    controlPanel.setLayout(new BorderLayout());
    
    //Create and populate the sub-panel that contains
    // the radio buttons. Populate it with check boxes
    // that behave like radio buttons.
    Panel radioButtonPanel = new Panel();
    radioButtonPanel.add(edgeNoOp);
    radioButtonPanel.add(edgeZeroFill);

    //Create the sub-panel that contains the text fields.
    Panel textFieldPanel = new Panel();
    textFieldPanel.setLayout(new GridLayout(9,9));

    //Populate and initialize the array of TextField
    // objects for the convolution filter, with all zero
    // values and add them to their panel. matrixField
    // is a reference to a 9x9 array object tree
    // populated with TextField objects. textFieldPanel
    // is a Panel object with a 9x9 grid layout.
    for(int row = 0;row < matrixField.length;row++){
      for(int col = 0;col < matrixField[0].length;col++){
        matrixField[row][col] = new TextField("0.0",6);
        textFieldPanel.add(matrixField[row][col]);
      }//end inner loop
    }//end outer loop
    
    //Initialize one TextField object so as to create a
    // filter that simply copies the input image to the
    // output.
    matrixField[4][4].setText("1.0");
    
    //Populate the control panel.
    controlPanel.add(radioButtonPanel,BorderLayout.NORTH);
    controlPanel.add(textFieldPanel,BorderLayout.CENTER);

    //Finish populating the main panel.
    mainPanel.add(controlPanel,BorderLayout.CENTER);
    
    //Add the errorMsg label.
    mainPanel.add(errorMsg,BorderLayout.SOUTH);
    errorMsg.setBackground(Color.GREEN);
  }//end constructMainPanel
  //----------------------------------------------------//

  //This method processes the image according to the
  // filter values provided by the user.
  //The method uses the ConvolveOp filter class to
  // process the image.  The method is called from within
  // the method named processImg, which is the primary
  // image processing method in this program.
  BufferedImage processMainPanel(BufferedImage theImage){
    
    //Reset the error message to the default.
    errorMsg.setText(okMessage);
    errorMsg.setBackground(Color.GREEN);

    //Now convert the matrix/convolution filter into a
    // one-dimensional array. This is the required format
    // for input to the constructor for the Kernel class,
    // which is  used to pass the convolution
    // coefficients into the filtering process.    
    //Test for all zero values and values that can't be
    // converted to numeric format in the process of
    // converting to a one-dimensional array. If either
    // condition is detected, create a set of
    // convolution coefficients having a single very small
    // value.
    boolean zeroTest = true;
    float[] matrix = new float[
              matrixField.length * matrixField[0].length];
    int matrixCnt = 0;
    try{
      for(int row = 0;row < matrixField.length;row++){
        for(int col = 0;col < matrixField[0].length;
                                       col++,matrixCnt++){
          matrix[matrixCnt] = Float.parseFloat(
                         matrixField[row][col].getText());
          if(matrix[matrixCnt] != 0.0f){
            zeroTest = false;
          }//end if
        }//end col loop
      }//end row loop
    }catch(java.lang.NumberFormatException e){
      //Bad input data for the convolution filter. Cause
      // the output image to be very dark so that it will
      // be obvious to the user that there is a problem.
      // Also cause the label containing the error message
      // to turn from green to red.
      matrixCnt = 0;
      for(int row = 0;row < matrixField.length;row++){
        for(int col = 0;col < matrixField[0].length;
                                       col++,matrixCnt++){
          matrix[matrixCnt] = 0.0f;
        }//end col loop
      }//end row loop
      //Set one filter coefficient to a non-zero, very
      // small value.
      matrix[0] = 0.01f;
      errorMsg.setText(
            "Bad input data for the convolution filter.");
      errorMsg.setBackground(Color.RED);
    }//end catch
    
    //If all filter values are 0.0f, cause one value to
    // be a very small non-zero value and display an
    // error message. This will prevent the program from
    // throwing an exception when it tries to perform a
    // convolution operation using a convolution filter
    // having all zero values.
    if(zeroTest){
      matrix[0] = 0.1f;
      errorMsg.setText(
            "Bad input data for the convolution filter.");
      errorMsg.setBackground(Color.RED);
    }//end if
    
    //Use the state of the radio buttons to set the manner
    // in which the edge of the image will be treated
    // during the convolution process.
    int edgeTreatment;
    if(edgeZeroFill.getState() == true){
      edgeTreatment = ConvolveOp.EDGE_ZERO_FILL;
    }else{//edgeNoOp must have been selected
      edgeTreatment = ConvolveOp.EDGE_NO_OP;
    }//end else
    
    //Create the filter object. Create the Kernel object
    // as an anonymous object in the parameter list for
    // the ConvolveOp constructor.
    ConvolveOp filterObj = new ConvolveOp(
                         new Kernel(matrixField.length,
                                    matrixField[0].length,
                                    matrix),
                         edgeTreatment,
                         null);
    //Apply the filter and return the filtered image
    return filterObj.filter(theImage,null);

  }//end processMainPanel
  //----------------------------------------------------//

  //The following method must be defined to implement the
  // ImgIntfc05 interface.  It is called by the driver
  // program named ImgMod05.
  public BufferedImage processImg(BufferedImage theImage){
    BufferedImage outputImage = 
                               processMainPanel(theImage);
    return outputImage;
  }//end processImg
}//end class ImgMod42


