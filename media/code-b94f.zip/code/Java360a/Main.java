//34567890123456789012345678901234567890123456789012345678
//11/25/08 Ready to publish.

/*Program Java360a
Copyright R.G.Baldwin 2009

The purpose of this program is to illustrate the use of
the following methods of the Picture class:

boolean loadPictureAndShowIt(String fileName)
Picture getPictureWithWidth(int width)
void drawString(String text,int xPos,int yPos)
void addMessage(String message, int xPos, int yPos)
Picture getPictureWithHeight(int height)
Pixel[] getPixels()

An attempt was also made to illustrate the following 
methods to write Picture objects into image files. 
However, the results were very unreliable. Sometimes the 
program was able to write the file and sometimes it 
wasn't. Sometimes when the file was written, it would 
contain the image and sometimes it would be empty.

boolean write(String fileName)
void writeOrFail(String fileName)throws IOException

This program completes the illustrations of the methods of
the Picture class with the exception of the explore 
method. The explore method will be explained in a future 
lesson that is dedicated to that method alone.

The program begins by calling the loadPictureAndShowIt 
method to load and show a picture of a rose. The title 
shown in the JFrame object is "None"

Then the program reads an image file to create a picture 
of a butterfly, which is much  larger than the picture of
the rose.

Then the program calls the getPictureWithWidth method to 
create a new Picture object containing the butterfly image
with the width being set to match the width of the picture
of the rose. Note that the aspect ratio of the butterfly 
picture is preserved.

Then the program calls the drawString method to draw a 
white text string on the picture of the butterfly. The 
drawString method calls the addMessage method to actually
draw the text on the image. The color white is fixed and 
cannot be changed without modifying the method.

Then the program calls the getPictureWithHeight method 
twice to create pictures of the rose and the butterfly 
with the same height. Again, the original aspect ratio of
each image is preserved.

Then the program calls the Baldwin method named 
translatePicture to copy the picture of the rose into the
right side of a new Picture object. It calls the 
copyPicture method to copy the picture of the butterfly 
into the left side of the same picture. The pictures used
as input to this operation are the pictures with the same
height. This produces a new Picture object containing
side-by-side images of the butterfly and the rose.

Then the program uses the getPixels method to create a 
new picture of the butterfly and the rose side-by-side 
with the value of the red color component reduced by a 
factor of two. This is a very useful approach when you 
want to perform the same operation on every pixel in a 
Picture object.

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.geom.AffineTransform;

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  void run(){

    //The following code will load and show the rose with
    // a title of "None"
    Picture pixA = new Picture(1,1);
    pixA.loadPictureAndShowIt("rose.jpg");
    
    //Create a picture of a butterfly, which is much
    // larger than the picture of the rose.
    Picture pixB = new Picture("butterfly1.jpg");
    pixB.setTitle("pixB");
    pixB.show();
    
    //Create a new Picture object containing the butterfly
    // image. The width of the new picture is set to match
    // the width of the picture of the rose. Note that the
    // aspect ratio is preserved.
    Picture pixC = 
                pixB.getPictureWithWidth(pixA.getWidth());
    pixC.setTitle("pixC");
    
    //Draw white text on the picture of the butterfly.
    pixC.drawString("Same width as rose.",20,20);
    pixC.show();
    
    //Create pictures of the rose and the butterfly with 
    // the same height and their original aspect ratios.
    Picture pixD = pixA.getPictureWithHeight(200);
    Picture pixE = pixB.getPictureWithHeight(200);
    
    //Copy the picture of the rose into the right side of
    // a new picture.
    Picture pixF = 
                 translatePicture(pixD,pixE.getWidth(),0);
    
    //Copy the picture of the butterfly into the left side
    // of the same picture. This results in a Picture 
    // object containing side-by-side images of the 
    // butterfly and the rose, both with the same height.
    pixF.copyPicture(pixE);
    pixF.setTitle("pixF");
    pixF.show();
    
    //Create and show a new picture of the butterfly and 
    // the rose side-by-side and reduce the value of the 
    // red color component by a factor of two. The 
    // getPixels method is very useful when you want to 
    // perform the same operation on every pixel in a 
    // picture.
    Picture pixG = new Picture(pixF);
    pixG.setTitle("pixG");
    Pixel[] pixels = pixG.getPixels();
    int red = 0;
    for(int cnt = 0;cnt < pixels.length;cnt++){
      red = pixels[cnt].getRed();
      pixels[cnt].setRed((int)(red*0.5));
    }//end for loop
    pixG.show();

  }//end run method
  //----------------------------------------------------//

  //The following method accepts a reference to a Picture
  // object along with positive x and y translation
  // values. It creates and returns a new Picture object
  // that contains a translated version of the original
  // image with whitespace to the left of and/or above the
  // translated image. If either translation value is
  // negative, the method simply returns a reference to a
  // copy of the original picture.
  public Picture translatePicture(
                         Picture pix,double tx,double ty){
    if((tx < 0.0) || (ty < 0.0)){
      //Negative translation values are not supported.
      // Simply return a reference to a copy of the
      // incoming picture. Note that this constructor
      // creates a new picture by copying the image from
      // an existing picture.
      return new Picture(pix);
    }//end if

    //Set up the tranform
    AffineTransform translateTransform =
                                    new AffineTransform();
    translateTransform.translate(tx,ty);

    //Compute the size of a rectangle that is of
    // sufficient size to contain and display the
    // translated image.
    int pixWidth = pix.getWidth() + (int)tx;
    int pixHeight = pix.getHeight() + (int)ty;

    //Create a new picture object that is the correct
    // size.
    Picture result = new Picture(pixWidth,pixHeight);

    //Get the graphics2D object to draw on the result.
    Graphics2D g2 = (Graphics2D)result.getGraphics();

    //Draw the translated image from pix onto the new
    // Picture object, applying the transform in the
    // process.
    g2.drawImage(pix.getImage(),translateTransform,null);

    return result;
  }//end translatePicture
  //----------------------------------------------------//

}//end class Runner

//34567890123456789012345678901234567890123456789012345678