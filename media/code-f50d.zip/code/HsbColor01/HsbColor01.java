//34567890123456789012345678901234567890123456789012345678
//01/26/09 Needs margin correction. Otherwise is OK.

/*File HsbColor01 Copyright 2009 R.G.Baldwin

The purpose of this program is to demonstrate the HSB
color model. See the comments at the beginning of the
method named handleSliders for a more complete description
of the program.

This program requires access to Ericson's multimedia
library.

The program is terminated by clicking the large X in the
upper-right corner of the GUI.

Tested using Windows Vista Home Premium Edition,
Java 1.6x, and the version of Ericson's multimedia library
contained in bookClasses10-1-07.zip.
*********************************************************/
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.WindowConstants;
import javax.swing.JLabel;
import javax.swing.JTextField;

import java.awt.Graphics;
import java.awt.Color;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;

import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;

public class HsbColor01 extends JFrame{
  //The following constants are used to configure the
  // JSlider components as well as the text on the JSlider
  // and JLabel components.

  //Change the following int values to change the limits
  // and initial positions of the sliders.
  private final int hueSliderMin = 0;//minimum
  private final int hueSliderMax = 360;//maximum
  private final int hueSliderInit = 0;//initial value

  private final int satSliderMin = 0;
  private final int satSliderMax = 100;
  //Set to following value 99 to cause the saturation
  // circle to initially be inside the radius.
  private final int satSliderInit = 99;

  private final int brightSliderMin = 0;
  private final int brightSliderMax = 100;
  private final int brightSliderInit = 100;

  //Change the following int values to change the tick
  // spacing on the sliders.
  private final int hueSliderMajorTickSpacing = 60;
  private final int hueSliderMinorTickSpacing = 15;
  private final int satSliderMajorTickSpacing = 10;
  private final int satSliderMinorTickSpacing = 5;
  private final int brightSliderMajorTickSpacing = 10;
  private final int brightSliderMinorTickSpacing = 5;

  //Change these string values to change the labels
  // displayed to the left of the sliders.
  private final String hueSliderLabel = "Hue in Degrees";
  private final String satSliderLabel =
                                     "Percent Saturation";
  private final String brightSliderLabel =
                                     "Percent Brightness";
  //----------------------------------------------------//

  //The following components are used to build up the GUI.
  private final JPanel mainPanel = new JPanel();
  private final JPanel northPanel = new JPanel();
  private final JPanel radioButtonPanel = new JPanel();

  private final JPanel hueSliderPanel = new JPanel();
  private final JPanel satSliderPanel = new JPanel();
  private final JPanel brightSliderPanel = new JPanel();

  //Change the int values at the beginning of the program
  // to configure these sliders.
  private final JSlider hueSlider =
     new JSlider(hueSliderMin,hueSliderMax,hueSliderInit);
  private final JSlider satSlider =
     new JSlider(satSliderMin,satSliderMax,satSliderInit);
  private final JSlider brightSlider = new JSlider(
        brightSliderMin,brightSliderMax,brightSliderInit);

  private final ButtonGroup buttonGroup =
                                        new ButtonGroup();
  private final JRadioButton coneButton =
                            new JRadioButton("Cone",true);
  private final JRadioButton cylinderButton =
                             new JRadioButton("Cylinder");

  //The hue, saturation, brightness, and RGB color values
  // will be displayed in the following text fields.
  private final JTextField hueField = new JTextField(3);
  private final JTextField satField = new JTextField(3);
  private final JTextField brightField =
                                        new JTextField(3);
  private final JTextField hexField = new JTextField(6);

  //This program draws either a cone or a cylinder that
  // displays HSB colors. Define the size of the Picture
  // object on which the cone or the cylinder is
  // displayed.
  private int pictureWidth = 400;
  private int pictureHeight = 400;
  private int halfWidth = pictureWidth/2;
  private int halfHeight = pictureHeight/2;

  //Instantiate a blank white Picture object that is used
  // to erase the current drawing on the display each time
  // a slider fires an event.
  private Picture picture =
                  new Picture(pictureWidth,pictureHeight);

  //A second Picture object is actually used to draw the
  // slice through the cone or the cylinder. A reference
  // to that object will be stored here.
  private Picture display =
                  new Picture(pictureWidth,pictureHeight);

  //Miscellaneous working variables.
  private Graphics graphics = null;
  private Pixel pixel = null;
  private Color color = null;
  private  double hue = 0;
  private double sat = 0;
  private double bright = 0;
  private double x = 0;
  private double y = 0;
  private double radius = 0;
  private float hueAngle = 0;
  private float satVal = 0;
  private Ellipse2D.Double ellipse = null;
  private int tempInt = 0;
  //----------------------------------------------------//

  public static void main(String[] args){
    new HsbColor01();
  }//end main method
  //----------------------------------------------------//

  public HsbColor01(){//constructor
    //Put decorations on the sliders. Change the constants
    // at the beginning of the program to control major
    // and minor tick spacing.
    hueSlider.setMajorTickSpacing(
                               hueSliderMajorTickSpacing);
    hueSlider.setMinorTickSpacing(
                               hueSliderMinorTickSpacing);
    hueSlider.setPaintTicks(true);
    hueSlider.setPaintLabels(true);

    satSlider.setMajorTickSpacing(
                               satSliderMajorTickSpacing);
    satSlider.setMinorTickSpacing(
                               satSliderMinorTickSpacing);
    satSlider.setPaintTicks(true);
    satSlider.setPaintLabels(true);

    brightSlider.setMajorTickSpacing(
                            brightSliderMajorTickSpacing);
    brightSlider.setMinorTickSpacing(
                            brightSliderMinorTickSpacing);
    brightSlider.setPaintTicks(true);
    brightSlider.setPaintLabels(true);

    //Construct the GUI working generally from the top
    // down.
    mainPanel.setLayout(new BorderLayout());

    mainPanel.add(northPanel,BorderLayout.NORTH);
    mainPanel.add(radioButtonPanel,BorderLayout.CENTER);

    northPanel.setLayout(new BorderLayout());

    //Add sliders.
    northPanel.add(hueSliderPanel,BorderLayout.NORTH);
    northPanel.add(satSliderPanel,BorderLayout.CENTER);
    northPanel.add(brightSliderPanel,BorderLayout.SOUTH);

    hueSliderPanel.setLayout(
                        new FlowLayout(FlowLayout.RIGHT));
    hueSliderPanel.add(new JLabel(hueSliderLabel));
    hueSliderPanel.add(hueSlider);
    hueSliderPanel.add(hueField);
    hueField.setEditable(false);//make it read only

    satSliderPanel.setLayout(
                        new FlowLayout(FlowLayout.RIGHT));
    satSliderPanel.add(new JLabel(satSliderLabel));
    satSliderPanel.add(satSlider);
    satSliderPanel.add(satField);
    satField.setEditable(false);

    brightSliderPanel.setLayout(
                        new FlowLayout(FlowLayout.RIGHT));
    brightSliderPanel.add(new JLabel(brightSliderLabel));
    brightSliderPanel.add(brightSlider);
    brightSliderPanel.add(brightField);
    brightField.setEditable(false);

    //Add radio buttons.
    radioButtonPanel.add(coneButton);
    radioButtonPanel.add(cylinderButton);
    //Make the radio buttons mutually exclusive.
    buttonGroup.add(coneButton);
    buttonGroup.add(cylinderButton);

    //Add a text field to display hex color value
    radioButtonPanel.add(hexField);
    hexField.setEditable(false);

    getContentPane().add(mainPanel);
    //Call the pack method to get the height right on the
    // GUI.
    pack();
    //Set the width of the GUI to match the width of the
    // color wheel display.
    setSize(pictureWidth + 7,this.getHeight());

    //Decorate the GUI.
    setTitle("Copyright 2009, R.G.Baldwin");

    //Position the GUI immediately below the color wheel
    // display.
    setLocation(0,pictureHeight + 30);

    //Terminate the program when the user clicks the large
    // X in the upper-right corner of the GUI.
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    //Cause the color wheel image to be created on the
    // display.
    handleSliders();

    //Display the GUI and the color wheel.
    setVisible(true);
    display.show();
    //--------------------------------------------------//

    //Register a ChangeListener object on the hueSlider.
    // Each time the hueSlider fires a ChangeEvent, this
    // event handler erases the current image and calls a
    // method named handleSliders to create and process a
    // new image.
    hueSlider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          //Erase the current display.
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          //Create and process a new display.
          handleSliders();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//
    //Register a ChangeListener object on the satSlider.
    //Behavior is the same as the hueSlider.
    satSlider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          handleSliders();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//
    //Register a ChangeListener object on the
    // brightSlider.
    //Behavior is the same as the hueSlider.
    brightSlider.addChangeListener(
      new ChangeListener(){
        public void stateChanged(ChangeEvent e){
          graphics = display.getGraphics();
          graphics.drawImage(picture.getImage(),0,0,null);
          handleSliders();
        }//end stateChanged
      }//end new ChangeListener
    );//end addChangeListener
    //--------------------------------------------------//

  }//end constructor
  //----------------------------------------------------//

  /*
  This method processes three sliders, two radio buttons,
  four text fields, a filled oval, and a large display of
  a color wheel.

  The radio buttons allow the HSB color model to be
  displayed either as a cone or as a cylinder. In either
  case, one slider labeled Hue in Degrees, which is
  graduated in degrees from 0 to 360 specifies a value for
  hue between zero and 360 degrees inclusive. Because it
  is difficult to read an exact value from the slider, the
  current value of the slider in degrees is also displayed
  in a text field to the right of the slider. The value in
  degrees is converted to a value from 0 to 1.0 for
  computational purposes.

  A second slider labeled Percent Saturation, which is
  graduated from 0 to 100 specifies a value for saturation
  from 0 to 100-percent or 1.0. The current percentage
  value of the slider is displayed in a text field to the
  right of the slider.

  A third slider labeled Percentage Brightness, which is
  graduated from 0 to 100 specifies a value for brightness
  from 0 to 100-percent or 1.0. The percentage value is
  displayed in a text field to the right of the slider.

  The color wheel that is displayed represents a
  horizontal slice through the cone or the cylinder with
  the location of the slice being specified by the value
  of the brightness slider. A value of 0 produces a
  horizontal slice at the very bottom, which for the cone
  display is simply a dot. A value of 100 produces a
  horizontal slice at the very top. In effect, this is the
  top surface of the cone or the cylinder. Generally, as
  the slider approaches 0, the display becomes darker, and
  for the cone display format, becomes smaller in
  diameter.

  Moving the hue slider causes a radial line, similar to
  the big hand on a clock to be displayed to show a value
  for hue in degrees. The line is in the 3:00 o'clock
  position for a hue of red at the 0 and 360-degree
  positions at the ends of the track.

  Moving the saturation slider causes a circle to be
  displayed inside of and concentric with the color wheel.
  It is the same size as the wheel when the slider is at
  the 100 end of the track. The diameter of the circle
  reduces to zero and the circle disappears when the
  slider approaches the 0 end of the track.

  The intersection of the horizontal plane defined by the
  value of the brightness slider, the radial line defined
  by the value of the hue slider, and the circle defined
  by the value of the saturation slider defines a
  specific color. That color is displayed in a filled oval
  in the upper-left corner of the display and is also
  displayed in hexadecimal format in a text field at the
  bottom of the GUI.

  A pair of radio buttons labeled Cone and Cylinder allows
  the user to select either the cone display format or the
  cylinder display format.

  The method is synchronized to eliminate the possiblilty
  that it may be called on two threads concurrently.

  All of the working variables in this method were
  declared as instancr variables in an attempt to make the
  method as responsive as possible.
  */
  private synchronized void handleSliders(){
    //Get the hue, saturation, and brightness values from
    // the sliders, display them in the text fields, and
    // convert them to floating point values ranging from
    // 0 to 1.0.
    tempInt = hueSlider.getValue();
    hueField.setText("" + tempInt);
    hue = tempInt/360.0;

    tempInt = satSlider.getValue();
    satField.setText("" + tempInt);
    sat = tempInt/100.0;

    tempInt = brightSlider.getValue();
    brightField.setText("" + tempInt);
    bright = tempInt/100.0;

    //Decide between cone and cylinder display formats.
    if(coneButton.isSelected()){
      //Use the following for a cone.
      radius = halfWidth * bright;
    }else{
      //Use the following for a cylinder.
      radius = halfWidth;
    }//end else

    //Construct a circle object with the same radius as
    // the wheel. It will be used to avoid processing any
    // pixels that are outside the wheel.
    ellipse = new Ellipse2D.Double(halfWidth-radius,
                                   halfHeight-radius,
                                   2*radius,2*radius);

    //Process every pixel in the wheel.
    for(int row = 0;row < pictureWidth;row++){
      for(int col = 0;col < pictureHeight;col++){
        if(ellipse.contains(col,row)){
          //Only process those pixels that are inside the
          // ellipse.
          //Compute values for x and y relative to the
          // center.
          x = col - halfWidth;
          y = row - halfHeight;
          if(x != 0){
            //Must avoid division by 0.
            hueAngle = (float)(Math.atan(y/x));
          }else{
            //x is equal to zero
            if(y >= 0){
              hueAngle = (float)(Math.PI/2);
            }else{
              hueAngle = (float)(2 * Math.PI - Math.PI/2);
            }//end else
          }//end else

          //Now get the angle into the correct quadrant.
          if((x < 0) && (y <= 0)){
            hueAngle = (float)(Math.PI + hueAngle);
          }else if((x > 0) && (y < 0)){
            hueAngle = (float)(2 * Math.PI + hueAngle);
          }else if((x < 0) && (y > 0)){
            hueAngle = (float)(Math.PI + hueAngle);
          }//end else

          if(radius != 0){
            //Get the length of a line from the center to
            // the pixel as the square root of the sum of
            // the squares. Must avoid division by 0.
            // Must also scale by radius to support the
            // varying diameter of the color wheel for the
            // cone display format.
            satVal = (float)(Math.sqrt(
                               (x/radius) * (x/radius) +
                               (y/radius) * (y/radius)));
          }else{
            //The radius is equal to 0. This is the
            // very bottom of the cone.
            satVal = (float)(0.0);
          }//end else

          //Up to this point, the angle has been expressed
          // in radians. Convert it to degrees.
          hueAngle = (float)(Math.toDegrees(hueAngle));

          //Convert the color to an RGB color that can be
          // used to set the color of a pixel. Note that
          // this method requires parameters of type float
          // and not type double.
          color = new Color(Color.HSBtoRGB(
                                    (float)(hueAngle/360),
                                    satVal,
                                    (float)bright));

          //Set the color of the pixel.
          pixel = display.getPixel(col,row);
          pixel.setColor(color);

        }//end if
/*
        }else{
          //This pixel is outside the wheel.
//          color = Color.WHITE;
        }//end else
*/
        //Set the color of the pixel.
//        pixel = display.getPixel(col,row);
//        pixel.setColor(color);

      }//end inner loop
    }//end outer loop

    //The wheel has been drawn with the correct colors for
    // the horizontal slice through the cone or the
    // cylinder based on the value of the Brightness
    // slider.
    //Now superimpose a white radial line and a white
    // circle on the wheel with their positions, radius,
    // etc., based on the values of the Hue and Saturation
    // sliders.
    graphics = display.getGraphics();

    //Get the coordinates of the intersection of the
    // radial hue line indicated by hueSlider and the
    // saturation circle indicated by satSlider.
    int xLoc = (int)(halfWidth +
                       (radius*satSlider.getValue()/100) *
                                Math.cos(Math.toRadians(
                                  hueSlider.getValue())));
    int yLoc = (int)(halfHeight +
                       (radius*satSlider.getValue()/100) *
                                Math.sin(Math.toRadians(
                                  hueSlider.getValue())));

    //Get the color of the pixel at the intersection.
    // Note, the line and the circle haven't been drawn
    // yet. Otherwise, the color of the pixel would be
    // white.
    if((xLoc < pictureWidth) && (yLoc < pictureHeight)){
      color = display.getPixel(xLoc,yLoc).getColor();
    }//end if

    //Display the value of the color in hex format in a
    // text field.
    hexField.setText(Integer.toHexString(color.getRGB()).
                              toUpperCase().substring(2));
    //Draw a round color swatch in the upper-left corner
    // that matches the pixel color at the intersection.
    graphics.setColor(color);
    graphics.fillOval(5,5,40,40);

    //Now draw the white radial hue line and the white
    // saturation circle.
    graphics.setColor(Color.WHITE);

    //Draw a white circle at the saturation value
    // indicated by satSlider.
    graphics.drawOval(
        (int)(halfWidth-radius*satSlider.getValue()/100),
        (int)(halfHeight-radius*satSlider.getValue()/100),
        (int)(2*radius*satSlider.getValue()/100),
        (int)(2*radius*satSlider.getValue()/100));

    //Draw a radial line at the hue angle indicated by
    // hueSlider.
    graphics.drawLine(
                halfWidth,
                halfHeight,
                halfWidth + (int)(radius * Math.cos(
                  Math.toRadians(hueSlider.getValue()))),
                halfHeight + (int)(radius * Math.sin(
                  Math.toRadians(hueSlider.getValue()))));

    //Autograph the painting.
    display.addMessage("Dick Baldwin",150,50);

    //Repaint the display.
    display.repaint();

  }//end handleSliders
  //----------------------------------------------------//

}//end class HsbColor01

//34567890123456789012345678901234567890123456789012345678


