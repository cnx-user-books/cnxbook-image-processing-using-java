//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//
//Ready for publication, 10/30/04
//Recommend
// publishing with images produced by filtering
// ImgMod03.gif, as in:
// goImage ImgMod02 ImgMod24 ImgMod03.gif
// Also create images using ImgMaker01 and
// ImgMaker02.  Process them to show the effect
// of the smoothing
// filters on a white square and a white impulse.
// This is an alternative to ImgMod12. This
// alternative, provides
// a possibly more efficient approach to
// convolution for a 9-point smoothing filter
// that turns into a Gaussian filter when
// multiple convolutions are performed in
// succession.

/*File ImgMod24.java.java
Copyright 2004, R.G.Baldwin

This program allows for multiple successive
convolutions using a fixed 9x9 flat convolution
filter.  The result approaches a Gaussian
filter as more successive convolutions are
performed.

This program normalizes the output so that the
largest color value in the output always matches
the largest color value in the input.  This may
or may not be desirable depending on the
circumstances.

This program is designed to be driven by the
program named ImgMod02.  Enter the following at
the command line to run this program.

java ImgMod02 ImgMod24 ImageFileName

This program illustrates the use of area
(two-dimensional) convolution filtering to
smooth or blur an image.  In particular, it
illustrates the process of multiple successive
convolutions, which causes the convolution
operation to approach the convolution of the
image with a Gaussian filter.

The program displays two frames on the screen.
The large frame on the left shows the original
image at the top and the filtered image at the
bottom.  It also has a button labeled Replot at
the very bottom.

The small frame on the right contains a TextField
for user input.  When the program starts running,
this TextField displays the the value 1.  The
value in the text field specifies the number of
successive convolutions that are to be performed
on the image using a flat 9x9 convolution
filter.

To specify the number of convolutions, type an
integer value into the TextField and click the
Replot button.  This will cause the process to
start over and cause the filter to be applied the
specified number of times before the new results
are displayed.

This is a low-pass filter that suppresses high
frequency changes in color values.  It adds
all of the pixel values for each color within the
area covered by the filter.  Then it moves to the
next registration point and adds the pixel
values then contained in the area.  When the
convolution operation is complete, all of the
color values in the output are scaled so that the
peak color value in the output matches the peak
color value in the input.

Each pixel, except those in the outer edges of
the image, is used as a registration point.  The
pixels around the outer edges are not used as
registration points because that would cause the
area to extend outside the valid pixel values.

The visual effect of applying this filter is to
cause the image to go increasingly out of focus
as the number of convolutions is increased.  The
effect is most obvious with images that have
well-defined lines such as characters.

The transparency or alpha value of each pixel is
preserved.  If you don't see what you expect to
see when you run this program with a particular
image, it may be because your image contains
transparent areas.  This will be evidenced by the
yellow background color of the canvas showing
through the image.

Tested using SDK 1.4.2 and WinXP
************************************************/
import java.awt.*;

class ImgMod24 extends Frame implements
                                      ImgIntfc02{

  int numberConvolutions;
  String inputData;//Obtained via the TextField
  TextField input;//User input field

  ImgMod24(){//constructor
    setLayout(new FlowLayout());

    Label instructions = new Label(
               "Number of convolutions/replot.");
    add(instructions);

    input = new TextField("1",5);
    add(input);

    setTitle("Copyright 2004, Baldwin");
    setBounds(400,0,200,100);
    setVisible(true);
  }//end constructor
  //-------------------------------------------//

  //This method is required by ImgIntfc02.  This
  // method applies the convolution filter
  // to the incoming 3D array of pixel data and
  // returns a normalizxed filtered 3D array of
  // pixel data.  The output array is normalized
  // such that that the peak output color value
  // matches the peak input color value.
  public int[][][] processImg(
                            int[][][] threeDPix,
                            int imgRows,
                            int imgCols){

    System.out.println("\nWidth = " + imgCols);
    System.out.println("Height = " + imgRows);

    //Get numberConvolutions value from the
    // TextField
    numberConvolutions = Integer.parseInt(
                                input.getText());

    //Make a working copy of the 3D array to
    // avoid making permanent changes to the
    // original image data.  Get and save the
    // maximum value along the way.
    int inputPeak = 0;
    int colorValue = 0;
    int[][][] working3D =
                    new int[imgRows][imgCols][4];
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        working3D[row][col][0] =
                          threeDPix[row][col][0];
        colorValue = threeDPix[row][col][1];
        working3D[row][col][1] = colorValue;
        if(colorValue > inputPeak){
          inputPeak = colorValue;
        }//end if

        colorValue = threeDPix[row][col][2];
        working3D[row][col][2] = colorValue;
        if(colorValue > inputPeak){
          inputPeak = colorValue;
        }//end if

        colorValue = threeDPix[row][col][3];
        working3D[row][col][3] = colorValue;
        if(colorValue > inputPeak){
          inputPeak = colorValue;
        }//end if

      }//end inner loop
    }//end outer loop
    System.out.println(
                     "inputPeak = " + inputPeak);

    //Create an empty output array of the same
    // size as the incoming array.
    int[][][] output =
                    new int[imgRows][imgCols][4];

    //Copy all alpha values from input to output.
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        output[row][col][0] =
                          working3D[row][col][0];
      }//end inner loop
    }//end outer loop

    //Perform the convolution one or more times
    // in succession
    for(int cnt = 0;
                 cnt < numberConvolutions;cnt++){

      //Use nested for loops to treat each pixel
      // (other than those along the edges of the
      // image) as registration points and to
      // perform the two-dimensional convolution
      // using a shift-sum-scale approach. Note
      // that this algorithm is somewhat
      // different and probably more efficient
      // than the algorithm used in the program
      // named ImgMod12.  However, it is also
      // less flexible in terms of the shapes
      // of the convolution filters that can be
      // used.
      try{
        //Iterate on each pixel as a registration
        // point.
        for(int row = 0 + 1;row < imgRows - 2;
                                          row++){
          for(int col = 0 + 1;
                        col < imgCols - 2;col++){

            int redSum =
                 working3D[row - 1][col - 1][1] +
                 working3D[row - 1][col - 0][1] +
                 working3D[row - 1][col + 1][1] +
                 working3D[row - 0][col - 1][1] +
                 working3D[row - 0][col - 0][1] +
                 working3D[row - 0][col + 1][1] +
                 working3D[row + 1][col - 1][1] +
                 working3D[row + 1][col - 0][1] +
                 working3D[row + 1][col + 1][1];

            int greenSum =
                 working3D[row - 1][col - 1][2] +
                 working3D[row - 1][col - 0][2] +
                 working3D[row - 1][col + 1][2] +
                 working3D[row - 0][col - 1][2] +
                 working3D[row - 0][col - 0][2] +
                 working3D[row - 0][col + 1][2] +
                 working3D[row + 1][col - 1][2] +
                 working3D[row + 1][col - 0][2] +
                 working3D[row + 1][col + 1][2];


            int blueSum =
                 working3D[row - 1][col - 1][3] +
                 working3D[row - 1][col - 0][3] +
                 working3D[row - 1][col + 1][3] +
                 working3D[row - 0][col - 1][3] +
                 working3D[row - 0][col - 0][3] +
                 working3D[row - 0][col + 1][3] +
                 working3D[row + 1][col - 1][3] +
                 working3D[row + 1][col - 0][3] +
                 working3D[row + 1][col + 1][3];

            //Store the convolution output values
            // in the output array.
            output[row][col][1] = redSum;
            output[row][col][2] = greenSum;
            output[row][col][3] = blueSum;

          }//end for loop on col
        }//end for loop on row

      }catch(Exception e){
        e.printStackTrace();
      }//end catch

      //Normalize output peak value to match
      // input peak value.
      //First get output peak value
      int outputPeak = 0;
      for(int row = 0;row < imgRows;row++){
        for(int col = 0;col < imgCols;col++){
          if(output[row][col][1] > outputPeak){
            outputPeak = output[row][col][1];
          }//end if
          if(output[row][col][2] > outputPeak){
            outputPeak = output[row][col][2];
          }//end if
          if(output[row][col][3] > outputPeak){
            outputPeak = output[row][col][3];
          }//end if
        }//end inner loop
      }//end outer loop
      //System.out.println(
      //           "outputPeak = " + outputPeak);

      //Normalize to peak value
      double outputScale =
                  ((double)inputPeak)/outputPeak;
      for(int row = 0;row < imgRows;row++){
        for(int col = 0;col < imgCols;col++){
          output[row][col][1] =
             (int)(output[row][col][1]*
                                    outputScale);
          output[row][col][2] =
             (int)(output[row][col][2]*
                                    outputScale);
          output[row][col][3] =
             (int)(output[row][col][3]*
                                    outputScale);
        }//end inner loop
      }//end outer loop

      //Copy output into input to prepare for
      // another convolution (no need to copy
      //alpha)
      for(int row = 0;row < imgRows;row++){
        for(int col = 0;col < imgCols;col++){
          working3D[row][col][1] =
                            output[row][col][1];
          working3D[row][col][2] =
                            output[row][col][2];
          working3D[row][col][3] =
                            output[row][col][3];
        }//end inner loop
      }//end outer loop
    }//end for loop on numberConvolutions

    System.out.println("Processing Done");
    //Return a reference to the array containing
    // the filtered pixels.
    return output;

  }//end processImg method
  //-------------------------------------------//

}//end class ImgMod24