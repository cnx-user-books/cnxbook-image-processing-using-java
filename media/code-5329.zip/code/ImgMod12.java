//34567890123456789012345678901234567890123456789
//Note: this is wide format for small fonts.
//=============================================//
//Ready for publication, 10/30/04. Recommend
// publishing with images produced by filtering
// ImgMod03.gif, as in:
// goImage ImgMod02 ImgMod12 ImgMod03.gif
// Also create an image using ImgMaker01 and
// process it to show the effect of the smoothing
// filters on a grey square.

/*File ImgMod12.java
Copyright 2004, R.G.Baldwin

This program is designed to be driven by the
program named ImgMod02.  Enter the following at
the command line to run this program.

java ImgMod02 ImgMod12 ImageFileName

This program illustrates the use of area
(two-dimensional) convolution filtering to blur
an image.

The program displays two frames on the screen.
The large frame on the left shows the original
image at the top and the filtered image at the
bottom.  It also has a button labeled Replot at
the very bottom.

The small frame on the right contains a TextField
for user input.  When the program starts running,
this TextField displays the size of the default
convolution area in pixels.

To modify the convolution area, type a number
into the TextField and click the Replot button.
The new filter will be applied to the image and
the filtered image will be displayed.

The program supports non-square convolution area
values of 1, 2, 3, 4, 6, and 8 pixels.  (The
shape of the convolution area is shown as a grid
of X characters on the screen.)

Area values of 0, 5, and 7 are not supported.

In addition, the program supports all area values
that are perfect squares begining with an area
value of 4 pixels.  However, for area values
greater than 9, the  value entered by the user is
automatically rounded to the nearest perfect
square before processing takes plae.  For
example, if the user enters 10, the actual area
used for convolution will be a square with 3
pixels on each side.  If the user enters 15, the
area used for convolution will be a square with 4
pixels on each side.

The convolution operator is a box with each
coefficient having a value of 1.  (See
discussion of normalization later.)

This is a low-pass filter that suppresses high
frequency changes in color values.  It adds
all of the pixel values for each color within the
area covered by the filter.  Then it moves to the
next registration point and adds the pixel
values then contained in the area.

Every pixel, except those in the outer edges of
the image is used as a registration point.  The
pixels around the outer edges are not used as
registration points because that would cause the
area to extend outside the valid pixel values.

Once the convolution process is finished, the
output data is normalized such that the peak
color value in the output matches the peak color
value in the input.  This may, or may not be
appropriate depending on the circumstances.
However, it does preserve the dynamic range of
the display.

The visual effect of applying this filter is to
cause the image to go increasingly out of focus
as the size of the area is increased.  The effect
is most obvious with images that have well
defined lines such as characters.

The transparency or alpha value of each pixel is
preserved.  If you don't see what you expect to
see when you run this program with a particular
image, it may be because your image contains
transparent areas.  This will be evidenced by the
yellow background color of the canvas showing
through the image.

Tested using SDK 1.4.2 and WinXP
************************************************/
import java.awt.*;

class ImgMod12 extends Frame implements
                                      ImgIntfc02{

  int area;//The area value in pixels
  String inputData;//Obtained via the TextField
  TextField input;//User input field

  ImgMod12(){//constructor
    setLayout(new FlowLayout());

    Label instructions = new Label(
               "Type an area value and replot.");
    add(instructions);

    input = new TextField("2",5);
    add(input);

    setTitle("Copyright 2004, Baldwin");
    setBounds(400,0,200,100);
    setVisible(true);
  }//end constructor
  //-------------------------------------------//

  //This method is required by ImgIntfc02.  This
  // method applies the convolution filter
  // to the incoming 3D array of pixel data and
  // returns a filtered 3D array of pixel data.
  public int[][][] processImg(
                            int[][][] threeDPix,
                            int imgRows,
                            int imgCols){

    System.out.println("\nWidth = " + imgCols);
    System.out.println("Height = " + imgRows);

    //Get area value from the TextField
    area = Integer.parseInt(input.getText());

    //Create an empty output array of the same
    // size as the incoming array.
    int[][][] output =
                    new int[imgRows][imgCols][4];

    //Make a working copy of the 3D array to
    // avoid making permanent changes to the
    // original image data.  Get and save the
    // maximum value along the way.
    int inputPeak = 0;
    int colorValue = 0;
    int[][][] working3D =
                    new int[imgRows][imgCols][4];
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        working3D[row][col][0] =
                          threeDPix[row][col][0];
        colorValue = threeDPix[row][col][1];
        working3D[row][col][1] = colorValue;
        if(colorValue > inputPeak){
          inputPeak = colorValue;
        }//end if

        colorValue = threeDPix[row][col][2];
        working3D[row][col][2] = colorValue;
        if(colorValue > inputPeak){
          inputPeak = colorValue;
        }//end if

        colorValue = threeDPix[row][col][3];
        working3D[row][col][3] = colorValue;
        if(colorValue > inputPeak){
          inputPeak = colorValue;
        }//end if

      }//end inner loop
    }//end outer loop
    System.out.println(
                     "inputPeak = " + inputPeak);

    //Copy all alpha values from input to output.
    for(int row = 0;row < imgRows;row++){
      for(int col = 0;col < imgCols;col++){
        output[row][col][0] =
                          working3D[row][col][0];
      }//end inner loop
    }//end outer loop

    //The following three variables are used to
    // accumulate the products of the pixel color
    // values and the convolution filter
    // coefficients.
    int redSum = 0;
    int greenSum = 0;
    int blueSum = 0;

    //The following variables are used for
    // control purposes while performing the
    // sum of products operation using for loops.
    int rowNo = 0;
    int colNo = 0;
    int row = 0;
    int col = 0;
    int firstRow = 0;
    int lastRow = 0;
    int firstCol = 0;
    int lastCol = 0;
    int minusRow = 0;
    int plusRow = 0;
    int minusCol = 0;
    int plusCol = 0;

    //The following switch statement is used to
    // set the control variables listed above for
    // area values of 1, 2, 3, 4, 6, and 8 on
    // an individual area basis.
    //Area values of 5 and 7 are not supported.
    //Area values of 9 and greater default to
    // the nearest perfect square, such as 9, 16,
    // 25, 36, etc.
    switch(area){
      case 0:
        System.out.println(
                   "Area value 0 not supported");
        break;
      case 1://A single pixel reproduces image
        firstRow = 0;
        lastRow = imgRows;
        firstCol = 0;
        lastCol = imgCols;
        minusRow = 0;
        plusRow = 0;
        minusCol = 0;
        plusCol = 0;
      break;
      case 2://Two pixels in a row
        firstRow = 0;
        lastRow = imgRows;
        firstCol = 1;
        lastCol = imgCols;
        minusRow = 0;
        plusRow = 0;
        minusCol = 1;
        plusCol = 0;
      break;
      case 3://Three pixels in a row
        firstRow = 0;
        lastRow = imgRows;
        firstCol = 1;
        lastCol = imgCols - 1;
        minusRow = 0;
        plusRow = 0;
        minusCol = 1;
        plusCol = 1;
      break;
      case 4://Four pixels in a square
        firstRow = 1;
        lastRow = imgRows;
        firstCol = 1;
        lastCol = imgCols;
        minusRow = 1;
        plusRow = 0;
        minusCol = 1;
        plusCol = 0;
      break;
      case 5:
        System.out.println(
                   "Area value 5 not supported");
      break;
      case 6://Two rows of 3 pixels
        firstRow = 1;
        lastRow = imgRows;
        firstCol = 1;
        lastCol = imgCols - 1;
        minusRow = 1;
        plusRow = 0;
        minusCol = 1;
        plusCol = 1;
      break;
      case 7:
        System.out.println(
                   "Area value 7 not supported");
      break;
      case 8://Two rows of 4
        firstRow = 1;
        lastRow = imgRows;
        firstCol = 2;
        lastCol = imgCols - 1;
        minusRow = 1;
        plusRow = 0;
        minusCol = 2;
        plusCol = 1;
      break;
      //Default to nearest perfect square for
      // area values greater than 8.
      default:
        //Get the side of the square area,
        // rounded to the nearest square.
        double dSide = Math.sqrt(area);
        int side = (int)Math.round(dSide);

        //Set the area value to the nearest
        // perfect square.  This is necessary
        // because it is used to scale the
        // accumulated values later.
        area = side*side;

        //Because a square area with an even
        // number of pixels on a side doesn't
        // have a pixel at the center, it must
        // be treated differently from a square
        // area with an odd number of pixels on a
        // side.  For the even case, the area
        // above and to the left of the
        // registration point is slightly greater
        // than the area below and to the right.
        if(side%2 == 0){//side is even
          firstRow = side/2;
          lastRow = imgRows - side/2 + 1;
          firstCol = side/2;
          lastCol = imgCols - side/2 + 1;
          minusRow = side/2;
          plusRow = side/2 - 1;
          minusCol = side/2;
          plusCol = side/2 -1;
        }else{//side is odd
          firstRow = side/2;
          lastRow = imgRows - side/2;
          firstCol = side/2;
          lastCol = imgCols - side/2;
          minusRow = side/2;
          plusRow = side/2;
          minusCol = side/2;
          plusCol = side/2;
        }//end else
    }//end switch statement

    //Use nested for loops to treat each pixel
    // (other than those along the edges of the
    // image) as registration points and to
    // perform the two-dimensional convolution.
    try{
      //First iterate on each pixel as a
      // registration point.
      for(row = firstRow;row < lastRow;row++){
        for(col = firstCol;col < lastCol;col++){

          //Now use the registration point as a
          // base and iterate on the pixels
          // contained within the area covered by
          // the convolution filter.  Display a
          // grid of X characters on the screen
          // showing the shape of the area
          // covered by the convolution filter.
          // Display the grid only once while
          // processing the first registration
          // point.
          for(rowNo = row - minusRow;
                 rowNo <= row + plusRow;rowNo++){

            //Start a new line in the grid of X
            // characters.
            if((row == firstRow)
                           && (col == firstCol)){
              System.out.println();
            }//end if

            for(colNo = col - minusCol;
                 colNo <= col + plusCol;colNo++){

              //Display the next X in the grid of
              // X characters.
              if((row == firstRow)
                           && (col == firstCol)){
                System.out.print("X");
              }//end if

              //Accumulate the pixel values
              // multiplied by the coefficient
              // values in the convolution
              // filter.  Note that all
              // coefficients have a value of 1.
              // The accumulated value will later
              // be divided by the area, causing
              // the effective values of the
              // coefficients to be the
              // reciprocal of the area.
              redSum +=
                      working3D[rowNo][colNo][1];
              greenSum +=
                      working3D[rowNo][colNo][2];
              blueSum +=
                      working3D[rowNo][colNo][3];
            }//end for loop on y
          }//end for loop on x

          //Store the accumlator values in the
          // output array.
          output[row][col][1] = redSum;
          output[row][col][2] = greenSum;
          output[row][col][3] = blueSum;

          //Clear the accumulators in preparation
          // for processing the next registration
          // point.
          redSum = 0;
          greenSum = 0;
          blueSum = 0;

        }//end for loop on col
      }//end for loop on row

    }catch(Exception e){
      e.printStackTrace();
    }//end catch

    //Normalize output peak value to match
    // input peak value.
    //First get output peak value
    int outputPeak = 0;
    for(row = 0;row < imgRows;row++){
      for(col = 0;col < imgCols;col++){
        if(output[row][col][1] > outputPeak){
          outputPeak = output[row][col][1];
        }//end if
        if(output[row][col][2] > outputPeak){
          outputPeak = output[row][col][2];
        }//end if
        if(output[row][col][3] > outputPeak){
          outputPeak = output[row][col][3];
        }//end if
      }//end inner loop
    }//end outer loop

    //Normalize to peak value
    double outputScale =
                ((double)inputPeak)/outputPeak;
    for(row = 0;row < imgRows;row++){
      for(col = 0;col < imgCols;col++){
        output[row][col][1] =
           (int)(output[row][col][1]*
                                  outputScale);
        output[row][col][2] =
           (int)(output[row][col][2]*
                                  outputScale);
        output[row][col][3] =
           (int)(output[row][col][3]*
                                  outputScale);
      }//end inner loop
    }//end outer loop

    //Return a reference to the array containing
    // the filtered pixels.
    return output;

  }//end processImg method
  //-------------------------------------------//

}//end class ImgMod12