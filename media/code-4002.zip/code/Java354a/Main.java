//34567890123456789012345678901234567890123456789012345678
//11/18/2008 Ready to publish.

/*Program Java354a
Copyright R.G.Baldwin 2009

The purpose of this program is to illustrate the use of
several of the methods that are declared in the
DigitalPicture interface as implemented in the Picture
class.

One Picture object is constructed by using a Picture
constructor that accepts the name of an image file as a
parameter and uses the image from that file as the
image in the Picture object. The picture is displayed by
calling the show method on the Picture object.

In this case, the title is automatically set to the name
of the image file.

A second Picture object is constructed by using a Picture
constructor that accepts the dimensions of the Picture
object only and constructs a Picture object with a default
all-white image. The size of the Picture object that is
constructed is only 1x1.

Then the load method that takes the name of an image file
is called to load the image from an image file into the
small Picture object. The size of the picture object
changes to accommodate the size of the image.

In this case, the default title is "None". The setTitle
and getFileName methods are used to set the title for the
picture. Then the explore method is called to display the
Picture object with its new image and title.

Note that if you call the show method on a picture,
modify the picture, and call the show method on the
picture again, only one copy of the picture is displayed
and the results may not be what you expect to see.
However, displaying the picture in the explore format,
modifying it, and then displaying it again in the show
format seems to work OK.

A pair of nested for loops is used in conjunction with the
getBasicPixel and setBasicPixel methods to copy the right
half of the image in the first Picture object into the
left half of the second Picture object, leaving the right
half of the second Picture object undisturbed.

Then the show method is called on the modified second
picture object to display it.

Note that both image files are in the current directory.

Along the way, the program calls methods dealing with the
file name and the title and eventually prints that
information on the system console.

The following methods from the DigitalPicture interface
are used in this program.
* String getFileName()
* String getTitle()
* void setTitle(String title)
* int getWidth()
* int getHeight()
* int getBasicPixel(int x, int y)
* void setBasicPixel(int x, int y, int rgb)
* boolean load(String fileName)
* void show()

The following methods that are declared in the
DigitalPicture interface are not used in this program.
* Image getImage()
* BufferedImage getBufferedImage()
* Pixel getPixel(int x, int y)
* void load(Image image)

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/

public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  void run(){
    //Construct a new 341x256 Picture object providing the
    // name of an image file as a parameter.
    Picture pix1 = new Picture("ScaledAquarium.gif");
//    Picture pix1 = new Picture("xyz.gif");
    pix1.show();//display the picture in the show format

    //Create a new small Picture object with a default
    // all-white image. It must be at least 1x1 or a
    // runtime error will occur.
    Picture pix2 = new Picture(1,1);

    //Load a 341x256 image from a jpg file into the small
    // Picture object. Note that the size of the Picture
    // object increases or decreases to accommodate the
    // size of the image.
    pix2.load("ScaledBeach.jpg");

    //Set the title of the picture.
    pix2.setTitle("pix2: " + pix2.getFileName());

    //Note that if you call the show method on a picture,
    // modify the picture, and call the show method on the
    // picture again, only one copy of the picture is
    // displayed and the results may not be what you
    // expect to see. However, displaying the picture in
    // the explore format, modifying it, and then
    // displaying it again in the show format seems to
    // work OK.
    pix2.explore();

    //Use the getBasicPixel and setBasicPixel methods to
    // copy the right half of the image from pix1 into the
    // left half of pix2, leaving the right half of pix2
    // undisturbed.
    for(int row = 0;row < pix1.getHeight();row++){
      for(int col = 0;col < pix2.getWidth()/2;col++){
        pix2.setBasicPixel(col,row,pix1.getBasicPixel(
                            col + pix1.getWidth()/2,row));
      }//end inner for loop
    }//end outer for loop
    //Display the final result.
    pix2.show();

    //Display some text on the system console.
    System.out.println(pix1);
    System.out.println("pix1 Filename: "
                                    + pix1.getFileName());
    System.out.println(pix2);
    System.out.println("pix2 FileName: "
                                    + pix2.getFileName());
    System.out.println("pix1 Title: " + pix1.getTitle());
    System.out.println("pix2 Title: " + pix2.getTitle());

  }//end run
}//end class Runner

//34567890123456789012345678901234567890123456789012345678