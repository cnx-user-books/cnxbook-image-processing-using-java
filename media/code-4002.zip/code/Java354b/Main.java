//34567890123456789012345678901234567890123456789012345678
//11/18/08 Ready to publish.

/*Program Java354b
Copyright R.G.Baldwin 2009

The purpose of this program is to illustrate the use of
several of the methods that are declared in the
DigitalPicture interface as implemented in the Picture
class.

The earlier program named Java354a illustrated the use of
all but the following four methods that are declared in
the DigitalPicture interface
* Image getImage()
* BufferedImage getBufferedImage()
* void load(Image image)
* Pixel getPixel(int x, int y)

This program creates and displays four Picture objects
using the first three methods in the above list, leaving
only the following method to be illustrated in another
program.
* Pixel getPixel(int x, int y)

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/
import java.awt.*;
public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  void run(){
    //Construct a new 341x256 Picture object by providing
    // the name of an image file as a parameter to the
    // Picture constructor.
    Picture pix1 = new Picture("ScaledAquarium.gif");
    pix1.setTitle("pix1");
    pix1.show();

    //Construct another new 341x256 Picture object by
    // providing the name of an image file as a parameter
    // to the Picture constructor.
    Picture pix2 = new Picture("ScaledBeach.jpg");
    pix2.setTitle("pix2");
    pix2.show();

    //Construct a third new 341x256 Picture object by
    // extracting the BufferedImage object from pix1 and
    // passing it as a parameter to the constructor for
    // the Picture constructor.
    Picture pix3 = new Picture(pix1.getBufferedImage());
    pix3.setTitle("pix3");
    pix3.show();

    //Construct a fourth new 341x256 Picture object by
    // starting with an all-white Picture object and
    // loading an image extracted from pix2.
    Image image = pix2.getImage();

    //Note that unlike the load method that takes a file
    // name as a parameter, this version of the load
    // method does not automatically set the size of the
    // Picture object to match the size of the image.
    //Get the size of the image and pass those dimensions
    // to the constructor for the Picture object.
    Picture pix4 = new Picture(image.getWidth(null),
                               image.getHeight(null));
    //Now load the image into the Picture object and
    // display the picture.
    pix4.load(image);
    pix4.setTitle("pix4");
    pix4.show();

  }//end run
}//end class Runner

//34567890123456789012345678901234567890123456789012345678