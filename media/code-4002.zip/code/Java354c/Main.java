//34567890123456789012345678901234567890123456789012345678
//11/18/08 Ready to correct the right margin and publish.

/*Program Java354c
Copyright R.G.Baldwin 2009

The programs named Java354a and Java354b illustrated all
of the methods declared in the DigitalPicture interface
other than the getPixel method.

The purpose of this program is to illustrate the use of
the getPixel method as implemented in the Picture class,
and to compare its use with the getBasicPixel and
setBasicPixel methods.

This program begins by creating two Picture objects
containing the same image. Then the program modifies the
green component for each row of one picture using the
getBasicPixel and setBasicPixel methods. This approach
requires a programming knowledge of bit manipulations.

Then the program does the same thing to the other picture
using the getPixel method and methods of the Pixel class.
This illustrates the reduction in complexity achieved
by using the getPixel method in place of the getBasicPixel
method.

Both approaches require three statements inside a pair of
nested for loops, but the three statements involving bit
manipulations are much more complex. Both processes
produce the same visual result.

With regard to the modification of the green color
component in the two pictures, the green color component
is scaled by zero for every pixel in the first row and is
scaled by 1.0 for every pixel in the bottom row with the
scale factors between the first and last row being
proportional to the row number. This results in an image
with a purple tinge at the top and the correct colors at
the bottom.

Tested using Windows Vista Premium Home edition and
Ericson's multimedia library.
*********************************************************/
import java.awt.Image;
public class Main{
  public static void main(String[] args){
    new Runner().run();
  }//end main method
}//end class Main
//------------------------------------------------------//

class Runner{
  void run(){
    //Construct a new 341x256 Picture object by providing
    // the name of an image file as a parameter to the
    // Picture constructor.
    Picture pic1 = new Picture("ScaledBeach.jpg");
    pic1.setTitle("pic1");
    pic1.explore();

    //Construct another new 341x256 Picture object by
    // providing the name of an image file as a parameter
    // to the Picture constructor.
    Picture pic2 = new Picture("ScaledBeach.jpg");
    pic2.setTitle("pic2");
    pic2.explore();

    //Modify the green component for each row separately
    // using the getBasicPixel and setBasicPixel methods.
    // This approach requires a programming knowledge of
    // bit manipulations.
    //Do the same thing using the getPixel method to
    // illustrate the reduction in complexity achieved
    // by using the getPixel method.
    //Both approaches require three statements inside a
    // pair of nested for loops, but the three statements
    // involving bit manipulations are much more complex.
    //Note that both Picture objects contain the same
    // image and both processes produce the same visual
    // output.

    //The green color component is scaled by zero for
    // every pixel in the first row and is scaled by
    // 1.0 for every pixel in the bottom row with the
    // scale factors between the first and last row being
    // proportional to the row number. This results in an
    // image with a purple tinge at the top and the
    // correct colors at the bottom.

    //Declare some working constants and variables.
    final int maskA = 0x0000FF00;//green only
    final int maskB = 0xFFFF00FF;//all but green
    int pixA = 0;
    int greenByte = 0;



    for(int row = 0;row < pic1.getHeight();row++){
      for(int col = 0;col < pic1.getWidth();col++){
        //Working at the bit level, scale the green byte
        // by 0.0 in the first row and 1.0 in the last row
        // with proportional scaling in between.
        pixA = pic1.getBasicPixel(col,row);
        greenByte =
             (int)(((pixA & maskA) >> 8)* row/255.0) << 8;
        pic1.setBasicPixel(
                      col,row,(pixA & maskB) | greenByte);
      }//end inner for loop
    }//end outer for loop
    pic1.show();

    //Do the same thing to the other picture working at
    // the Pixel level.
    Pixel pixB = null;
    int greenValue = 0;
    for(int row = 0;row < pic2.getHeight();row++){
      for(int col = 0;col < pic2.getWidth();col++){
        //Working at the Pixel level, do the same thing.
        pixB = pic2.getPixel(col,row);
        greenValue = (int)(pixB.getGreen() * row/255.0);
        pixB.setGreen(greenValue);
      }//end inner for loop
    }//end outer for loop
    pic2.show();

  }//end run
}//end class Runner

//34567890123456789012345678901234567890123456789012345678