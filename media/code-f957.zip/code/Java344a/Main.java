//34567890123456789012345678901234567890123456789012345678
/*
 *Java344a
 * The purpose of this program is to illustrate the use
 * of several different methods of the Turtle class.
 *
 * Also illustrates dropping pictures at the current
 * position and orientation of the turtle.
 *
 * Moves a Turtle object around on a World and drops
 * several copies of a small Picture along the way.
 */
import java.awt.Color;
public class Main{
  public static void main(String[] args){
    //Following statement eliminates necessity to manually
    // establish location of media files. Modify this to
    // point to the mediasources folder on your machine.
//Disable following statement to cause the program to
// search for the image files in the current directory.
//    FileChooser.setMediaPath("M:/Ericson/mediasources/");

    //Instantiate an object of a small picture of a turtle
    // with a white background.
    Picture p2 = new Picture("turtle.jpg");

    //Note that the Turtle object is different from the
    // image of the turtle in the Picture object.
    World mars = new World(400,500);
    Turtle joe = new Turtle(300,400,mars);
    joe.setShellColor(Color.RED);
    joe.setPenColor(Color.BLUE);
    joe.setPenWidth(2);
    joe.drop(p2);//Draw a small picture
try{
Thread.currentThread().sleep(5000);
}catch(InterruptedException e){}
    joe.forward(90);
    joe.drop(p2);
try{
Thread.currentThread().sleep(5000);
}catch(InterruptedException e){}
    joe.turn(-30);
try{
Thread.currentThread().sleep(5000);
}catch(InterruptedException e){}
    joe.forward();
    joe.drop(p2);
try{
Thread.currentThread().sleep(5000);
}catch(InterruptedException e){}
    joe.turn(-30);
try{
Thread.currentThread().sleep(5000);
}catch(InterruptedException e){}
    joe.forward();
    joe.drop(p2);
  }//end main

}//end class
//34567890123456789012345678901234567890123456789012345678