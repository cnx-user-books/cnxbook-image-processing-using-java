//34567890123456789012345678901234567890123456789012345678
import java.awt.*;
import javax.swing.JFrame;

/**
 *StartupTest02
 * The purpose of this program is to test such items as
 * the classpath, the media path, etc.
 *
 * 10/09/08 Compiles and runs OK on my laptop computer.
 *
 *Copies an image of a small turtle to an image of a
 * butterfly.
 *
 * Uses an object of the Graphics class to do the copy.
 *
 * Based on a program by Barbara Ericson that is:
 * Copyright Georgia Institute of Technology 2004-2005
 */
public class Main extends SimplePicture{
  ///////////////////// constructors /////////////////////
  //This constructor accepts the name of an image file
  // as a parameter.
  public Main(String fileName){
    //Let the parent class handle this fileName
    super(fileName);
  }//end constructor

  ////////////////////// methods /////////////////////////
  public void copy(Main source, int x, int y){
    //Get the graphics object
    Graphics g = this.getGraphics();

    //Copy the image
    g.drawImage(source.getImage(),x,y,null);
  }//end copy

  public static void main(String[] args){
    //Following statement eliminates necessity to manually
    // establish location of media files. Modify this to
    // point to the mediasources folder on your machine.
//Disable following statement to cause the program to
// search for the image files in the current directory.
//    FileChooser.setMediaPath("M:/Ericson/mediasources/");
    
    //Instantiate two objects of this class, each of 
    // which encapsulates an image.
    Main p1 = new Main("butterfly1.jpg");
    Main p2 = new Main("turtle.jpg");
    
    //Copy the turtle onto the butterfly and display using
    // the show format.
    p1.copy(p2,175,255);
    p1.show();

    //Cause program to terminate when the show window is
    // closed
    JFrame frame = p1.getPictureFrame().frame;
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  }//end main

}//end class
//34567890123456789012345678901234567890123456789012345678