//345678901234567890123456789012345678901234567890123456789
//Be sure to preserve < and > in html version
//=======================================================//

//06/23/06 Ready to publish

/*File ImgMod41.java
Copyright 2006, R.G.Baldwin

The purpose of this class is to illustrate the use of the 
BandCombineOp image-filtering class of the Java 2D API.

See general comments in the class named ImgMod038.

This class is compatible with the use of the framework
program named ImgMod05.

The framework program named ImgMod05 displays the original
and the modified images.  It also writes the modified image
into an output file in JPEG format.  The name of the output
file is junk.jpg and it is written into the current 
directory.

Image processing programs such as this one may provide a 
GUI for data input making it possible for the user to 
modify the behavior of the image processing method each 
time the Replot button is clicked.  Such a GUI is provided
for this program.

Enter the following at the command line to run this 
program:

java ImgMod05 ImgMod41 ImageFileName

If the program is unable to load the image file within ten
seconds, it will abort with an error message.

This program creates a GUI containing:

User instructions
Text fields used to specify the upper-left corner, the
 width, and the heighth of a rectangle.
Text fields used to specify the values in a 3x4 processing
 matrix having three rows and four columns.

Unlike some of the other image-filtering classes in the 
Java 2D API that can operate either directly on 
BufferedImage objects or on Raster objects, the 
BandCombineOp filter can only operate on Raster objects.   

The rectangle is used to extract a rectangular Raster 
object from the original image.

The rectangle values are initialized so that the rectangle 
is the same size as the image and overlays the entire 
image.  In other words, the rectangle contains the complete
image.

The matrix values are initialized so as to simply pass the 
input image through to the output without modification..

The red, green, and blue values of each pixel are treated 
as a column matrix.  A 1 is appended onto the end of the 
column matrix producing a set of four-element column 
matrices that represents each pixel in the input Raster 
object.

Each pixel in the output Raster is produced by multiplying 
the 3x4 processing matrix by the 4x1 column matrix that 
represents the corresponding pixel in the input Raster.

This makes it possible to cause the intensity of each color
in each pixel of the output Raster to be a function of the 
intensities of all three colors of the corresponding pixel 
in the input Raster, plus a constant that is equal to the 
rightmost value in the corresponding row of the processing 
matrix.

It is unclear in the documentation what happens to the 
output color value if the value resulting from the matrix
multiplication falls outside the range from 0 to 255.  
However, observation of the results suggests that rather 
than clipping the value to be within the range from 0 to 
255, the value is allowed to become corrupt.Therefore, care
must be exercised to avoid such overflow when setting the 
multiplicative values in the processing matrix.

Tested using J2SE 5.0 under WinXP.
**********************************************************/

import java.awt.image.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class ImgMod41 extends Frame implements ImgIntfc05{
  
  //Components used to construct the main panel.
  // Components that require local access only are defined
  // locally.  Others are defined here as instance
  // variables.
  Panel mainPanel = new Panel();//main control panel
  
  //Text fields for specifying the Rectangle object values.
  TextField rectXcoorField = new TextField("0");
  TextField rectYcoorField = new TextField("0");
  TextField rectWidthField = new TextField("0");
  TextField rectHeightField = new TextField("0");
  
  //Text fields for specifying the matrix values.
  //Top row
  TextField matrix00Field = new TextField("1.0");
  TextField matrix01Field = new TextField("0.0");
  TextField matrix02Field = new TextField("0.0");
  TextField matrix03Field = new TextField("0.0");

  //Middle row  
  TextField matrix10Field = new TextField("0.0");
  TextField matrix11Field = new TextField("1.0");
  TextField matrix12Field = new TextField("0.0");
  TextField matrix13Field = new TextField("0.0");
  
  //Bottom row
  TextField matrix20Field = new TextField("0.0");
  TextField matrix21Field = new TextField("0.0");
  TextField matrix22Field = new TextField("1.0");
  TextField matrix23Field = new TextField("0.0");
  
  //The following Label is used to notify of data entry
  // errors.
  String okMessage = "No data entry errors detected.";
  Label errorMsg = new Label(okMessage);

  //-----------------------------------------------------//
  
  //This is the primary constructor.  It calls another
  // method to construct the main panel so as to separate
  // the construction of the GUI into easily
  // understandable units.
  ImgMod41(){//constructor
  
    constructMainPanel();
    add(mainPanel);

    setTitle("Copyright 2006, R.G.Baldwin");
    setBounds(555,0,470,600);
    setVisible(true);

    //Define a WindowListener to terminate the program.
    addWindowListener(
      new WindowAdapter(){
        public void windowClosing(WindowEvent e){
          System.exit(1);
        }//end windowClosing
      }//end windowAdapter
    );//end addWindowListener
  }//end constructor
  //-----------------------------------------------------//
  
  //This method constructs the main panel containing all of
  // the controls.  This method is called from the primary
  // constructor..
  void constructMainPanel(){
    mainPanel.setLayout(new BorderLayout());
    
    //Create and add the instructional text to the panel.
    // This text appears in a disabled text area at the
    // top of the panel.
    String text ="COMBINING COLOR BAND DATA\n"
      + "This program illustrates the use of the "
      + "BandCombineOp filter class of the Java 2D "
      + "API.\n\n"
      + "Specify the coordinates of the upper-left corner "
      + "along with the width and the height of a "
      + "rectangle that either exactly overlays or fits "
      + "inside of the original image.  This rectangle is "
      + "used to extract a rectangular Raster with a "
      + "corresponding location and size from the "
      + "image.\n\n"
      + "Specify the twelve values in a 3x4 processing "
      + "matrix and then click the Replot button to "
      + "process the image.\n\n"
      + "The initial width and height values match the "
      + "size of the image.  Set the width value to 0 and "
      + "click the Replot button to recover the width and "
      + "height of the image.\n\n"
      + "The red, green, and blue values from each input "
      + "pixel plus a value of 1 is used to construct a "
      + "1x4 column matrix that represents each input "
      + "pixel.\n\n"
      + "Each output pixel is produced by multiplying the "
      + "1x4 column matrix representing each input pixel "
      + "by the 3x4 processing matrix.\n\n"
      + "Apparently output color values greater than 255 "
      + "or less than 0 simply result in corrupt values "
      + "in the output.";
      
    //Note:  The number of columns specified for the
    // following TextArea is immaterial because the
    // TextArea object is placed in the NORTH location of
    // a BorderLayout.
    TextArea textArea = new TextArea(text,22,1,
                                 TextArea.SCROLLBARS_NONE);
    mainPanel.add(textArea,BorderLayout.NORTH);
    textArea.setEnabled(false);

    //Construct the control panel and add it to the Center
    // of the main panel.
    Panel controlPanel = new Panel();
    controlPanel.setLayout(new GridLayout(8,4));
    
    //Add a row of labels
    controlPanel.add(new Label("RECTANGLE"));
    controlPanel.add(new Label(""));
    controlPanel.add(new Label(""));
    controlPanel.add(new Label(""));
    
    //Add another row of labels
    controlPanel.add(new Label("X-Coordinate"));
    controlPanel.add(new Label("Y-Coordinate"));
    controlPanel.add(new Label("Width"));
    controlPanel.add(new Label("Height"));
    
    //Add the text fields for the rectangle
    controlPanel.add(rectXcoorField);
    controlPanel.add(rectYcoorField);
    controlPanel.add(rectWidthField);
    controlPanel.add(rectHeightField);
    
    //Add another row of labels
    controlPanel.add(new Label("MATRIX"));
    controlPanel.add(new Label(""));
    controlPanel.add(new Label(""));
    controlPanel.add(new Label(""));
    
    //Add another row of labels
    controlPanel.add(new Label("Red multiplier"));
    controlPanel.add(new Label("Green multiplier"));
    controlPanel.add(new Label("Blue multiplier"));
    controlPanel.add(new Label("Additive constant"));
    
    //Add top row of matix text fields
    controlPanel.add(matrix00Field);
    controlPanel.add(matrix01Field);
    controlPanel.add(matrix02Field);
    controlPanel.add(matrix03Field);
    
    //Add middle row of matrix text fields
    controlPanel.add(matrix10Field);
    controlPanel.add(matrix11Field);
    controlPanel.add(matrix12Field);
    controlPanel.add(matrix13Field);
    
    //Add bottom row of matrix text fields
    controlPanel.add(matrix20Field);
    controlPanel.add(matrix21Field);
    controlPanel.add(matrix22Field);
    controlPanel.add(matrix23Field);

    mainPanel.add(controlPanel,BorderLayout.CENTER);
    
    //Add the errorMsg
    mainPanel.add(errorMsg,BorderLayout.SOUTH);
    errorMsg.setBackground(Color.GREEN);
  }//end constructMainPanel
  //-----------------------------------------------------//

  //This method processes the image according to the
  // rectangle and matrix values provided by the user.
  //This method uses the BandCombineOp image-filtering
  // class to process the image.  The method is called from
  // within the method named processImg, which is the
  // primary image processing method in this program.  The
  // method named processImg is called by the framework
  // program named ImgMod05.
  BufferedImage processMainPanel(BufferedImage theImage){
    
    //Reset the error message to the default.
    errorMsg.setText(okMessage);
    errorMsg.setBackground(Color.GREEN);
    
    //Initialize the contents of the text fields that
    // specify the rectangle so as to include the entire
    // image within the rectangle.  This initialization is
    // performed only if either the width or height text
    // fields contain a 0, which is the case at startup.
    // These values can later be modified by the user.
    // Also, the user can enter a 0 for the width and
    // click Replot to get back to the original image size.
    if((rectWidthField.getText().equals("0")) 
               || (rectHeightField.getText().equals("0"))){
      rectWidthField.setText("" +theImage.getWidth());
      rectHeightField.setText("" + theImage.getHeight());
    }//end if
    
    //Get the contents of the rectangle fields.
    int rectXcoor,rectYcoor,rectWidth,rectHeight;
    try{
      rectXcoor = 
                Integer.parseInt(rectXcoorField.getText());
      rectYcoor = 
                Integer.parseInt(rectYcoorField.getText());
      rectWidth = 
                Integer.parseInt(rectWidthField.getText());
      rectHeight = 
               Integer.parseInt(rectHeightField.getText());
    }catch(java.lang.NumberFormatException e){
      //Bad data in the rectangle fields.  Process a 1x1
      // rectangle so that it will be obvious to the user
      // that there is a problem.
      rectXcoor = rectYcoor = rectWidth = rectHeight = 1;
      errorMsg.setText(
                      "Bad input data for the rectangle.");
      errorMsg.setBackground(Color.RED);
    }//end catch
    
    int imageWidth = theImage.getWidth();
    int imageHeight = theImage.getHeight();
    
    //Code to confirm that the rectangle falls inside the
    // image.
    if((rectXcoor < 0)|| 
       (rectYcoor < 0)|| 
       ((rectXcoor + rectWidth) > imageWidth)|| 
       ((rectYcoor + rectHeight) > imageHeight))
    {
      //The rectangle falls outside the image.  Process a
      // 1x1 rectangle so that it will be obvious to the
      // user that there is a problem.
      rectXcoor = rectYcoor = rectWidth = rectHeight = 1;
      errorMsg.setText(
                 "The rectangle falls outside the image.");
      errorMsg.setBackground(Color.RED);
    }//end if

    //Get the data from the text fields for the matrix.
    float matrix00,matrix01,matrix02,matrix03,matrix10,
          matrix11,matrix12,matrix13,matrix20,matrix21,
          matrix22,matrix23;
    try{
      matrix00 = Float.parseFloat(matrix00Field.getText());
      matrix01 = Float.parseFloat(matrix01Field.getText());
      matrix02 = Float.parseFloat(matrix02Field.getText());
      matrix03 = Float.parseFloat(matrix03Field.getText());
      matrix10 = Float.parseFloat(matrix10Field.getText());
      matrix11 = Float.parseFloat(matrix11Field.getText());
      matrix12 = Float.parseFloat(matrix12Field.getText());
      matrix13 = Float.parseFloat(matrix13Field.getText());
      matrix20 = Float.parseFloat(matrix20Field.getText());
      matrix21 = Float.parseFloat(matrix21Field.getText());
      matrix22 = Float.parseFloat(matrix22Field.getText());
      matrix23 = Float.parseFloat(matrix23Field.getText());
    }catch(java.lang.NumberFormatException e){
      //Bad input data for the matrix.  Cause the output
      // image to be black so that it will be obvious to
      // the user that there is a problem.
      matrix00 = matrix01 = matrix02 = matrix03 = 
      matrix10 = matrix11 = matrix12 = matrix13 = 
      matrix20 = matrix21 = matrix22 = matrix23 = 0.0f;
      errorMsg.setText("Bad input data for the matrix.");
      errorMsg.setBackground(Color.RED);
    }//end catch
    
    //Now populate the matrix
    float[][] matrix = 
                    {{matrix00,matrix01,matrix02,matrix03},
                     {matrix10,matrix11,matrix12,matrix13},
                     {matrix20,matrix21,matrix22,matrix23}
                    };
                    
    //Note:  Unlike some of the other filters in the Java
    // 2D API that can operate either directly on 
    // BufferedImage objects or on Raster objects, the
    // BandCombineOp filter can only operate on Raster
    // objects.
    
    //Get the Raster object that contains the image data
    // inside the specified Rectangle object.
    Raster inputRaster = theImage.getData(new Rectangle(
                rectXcoor,rectYcoor,rectWidth,rectHeight));
    
    //Create the filter object.  The second parameter
    // allows for specification of rendering hints.
    BandCombineOp filterObj = 
                            new BandCombineOp(matrix,null);
    
    //Create a zeroed destination Raster with the correct
    // size and number of bands.
    WritableRaster destinationRaster = 
         filterObj.createCompatibleDestRaster(inputRaster);
    
    //Apply the filter
    filterObj.filter(inputRaster,destinationRaster);
    
    //Convert the destination raster to a BufferedImag and
    // return it.  The first parameter causes the
    // ColorModel for the output image to be the same as
    // the ColorModel for the input image.  The third
    // parameter indicates that the color values have not
    // been premultiplied by the alpha values.  The fourth
    // parameter allows for the inclusion of some
    // properties in a HashTable object.
    return new BufferedImage(theImage.getColorModel(),
                             destinationRaster,
                             false,
                             null);

  }//end processMainPanel
  //-----------------------------------------------------//

  //The following method must be defined to implement the
  // ImgIntfc05 interface.  It is called by the framework
  // program named ImgMod05.
  public BufferedImage processImg(BufferedImage theImage){
    
    BufferedImage outputImage = processMainPanel(theImage);

    return outputImage;
  }//end processImg
}//end class ImgMod41


